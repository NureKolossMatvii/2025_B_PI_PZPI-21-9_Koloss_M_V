import { getProject, getProjects } from "../http/projectApi";
import { IProject } from "../interfaces/Models/IProject";

export class ProjectService {
  async getAll(): Promise<IProject[]> {
    try {
      const data = await getProjects();
      return data;
    } catch (error) {
      throw error;
    }
  }

  async get(id: string): Promise<IProject> {
    try {
        const data = await getProject(id);
        return data;
    } catch (error) {
        throw error;
    }
  }
}
