import uuid from "react-uuid";
import { getProject } from "../http/projectApi";
import { saveUmlDiagram } from "../http/umlApi";
import { IUMLDiagramSaveDto } from "../interfaces/Dto/IUMLDiagramSaveDto";
import { UMLTableConnectionDto } from "../interfaces/Dto/UMLTableConnectionDto";
import { UMLTableDto } from "../interfaces/Dto/UMLTableDto";
import { UMLDiagram } from "../interfaces/Models/UMLDiagram";
import { UMLTable } from "../interfaces/Models/UMLTable";
import { UMLTableColumn } from "../interfaces/Models/UMLTableColumn";
import { UMLTableConnection } from "../interfaces/Models/UMLTableConnection";

export class DiagramService {
  async get(id: string): Promise<UMLDiagram> {
    try {
      const data = await getProject(id);
      const responseDiagram = data.diagram;
      const diagram: UMLDiagram = {
        ...responseDiagram?.diagram,
        tables: responseDiagram?.tables.map((table: UMLTable) => ({
          ...table,
          columns: table.columns,
        })),
        connections: responseDiagram?.connections
      };

      return diagram;
    } catch (error) {
      throw error;
    }
  }

  async save(diagram: UMLDiagram, projectId: string): Promise<void> {
    try {
      const newDiagram: IUMLDiagramSaveDto = {
        ...diagram,
        projectId: projectId,
        connections: diagram.connections as UMLTableConnectionDto[],
        tables: diagram.tables.map((table) => ({
          ...table,
          columns: table.columns as UMLTableColumn[],
        })) as UMLTableDto[],
      };

      await saveUmlDiagram(newDiagram);
    } catch (error) {
      throw error;
    }
  }
}
