import React, { useState, useEffect, useContext } from "react";
import { useForm } from "react-hook-form";
import { useParams } from "react-router-dom";
import { DiagramContext } from "../../..";
import { useDiagram } from "../../../hooks/useDiagram";
import { UMLDiagram } from "../../../interfaces/Models/UMLDiagram";
import { projectCreationSteps } from "../../../types/ProjectCreationStep";
import { Steps } from "../../../Project/components/Steps/Steps";
import { TableList } from "../TableList/TableList";
import { UmlView } from "../UmlView/UmlView";
import cl from "./UmlCreator.module.css";

interface IProps {
  disabled?:boolean;
}

export const UmlCreator = ({disabled}:IProps) => {
  const { fetchDiagram } = useContext(DiagramContext)!;
  const { projectId } = useParams();

  useEffect(() => {
    if (projectId) {
      fetchDiagram(projectId);
    }
  }, [projectId]);

  return (
    <div className={cl.wrapper}>
      <TableList disabled={disabled}></TableList>
      <UmlView disabled={disabled}></UmlView>
    </div>
  );
};
