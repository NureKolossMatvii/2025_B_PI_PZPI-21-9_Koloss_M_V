import React, {
  LegacyRef,
  RefObject,
  useContext,
  useEffect,
  useRef,
  useState,
} from "react";
import { ContextMenuContext, DiagramContext } from "../../../..";
import { useDimension } from "../../../../hooks/useDimension";
import { usePosition } from "../../../../hooks/usePosition";
import { IDimension } from "../../../../interfaces/IDimension";
import { IPosition } from "../../../../interfaces/IPosition";
import { UMLTable } from "../../../../interfaces/Models/UMLTable";
import { columnDataTypes } from "../../../../types/UMLColumnDataType";
import cl from "./DiagramTable.module.css";
import contextStyle from "../../../../components/UI/ContextMenu/ContextMenu.module.css";
import { iconKeyDark } from "../../../assets";
import { iconCopy, iconCut, iconCutDark, iconDelete, iconDeleteDark, iconDuplicate, iconDuplicateDark } from "../../../../assets";

interface IProps {
  table: UMLTable;
  areaDemension?: IDimension | null;
  disabled?: boolean;
  activeTable?: UMLTable | undefined;
  setActiveTable?: (table: UMLTable | undefined) => void
}

export const DiagramTable = ({ table, areaDemension, disabled, activeTable, setActiveTable}: IProps) => {
  const { changeTablePosition, updateTableDimensions, copyTableToClipboard, deleteTable, cloneTableFromClipboard } = useContext(DiagramContext)!;
  const { showMenu, hideMenu } = useContext(ContextMenuContext)!;
  const tableRef = useRef<HTMLDivElement>(null);
  const {
    handleMouseDown,
    handleMouseMove,
    handleMouseUp,
    setAreaDemension,
    position,
  } = usePosition({
    elementPosition: { x: table?.position?.x, y: table?.position?.y },
    onMove: () => changeTablePosition(table?.tableId, position),
    elementRef: tableRef
  });

  useEffect(() => {
    if (areaDemension) {
      setAreaDemension(areaDemension);
    }
  }, [areaDemension]);

  useEffect(() => {
    if (tableRef?.current) {
      updateTableDimensions(table.tableId, {width: tableRef.current?.offsetWidth, height: tableRef.current?.offsetHeight})
    }
  }, [tableRef.current?.offsetHeight])

  const copyTable = () => {
    hideMenu()
    copyTableToClipboard(table.tableId)
  }

  const removeTable = () => {
    hideMenu();
    deleteTable(table.tableId)
  }

  const duplicateTable = () => {
    cloneTableFromClipboard(table);
    hideMenu();
  }

  const cutTable = () => {
    copyTableToClipboard(table.tableId)
    removeTable();
  }

  const handleClickOutside = (event: any) => {
   if (!disabled && setActiveTable) {
    if (tableRef.current && !tableRef.current.contains(event.target)) {
      if (table.tableId === activeTable?.tableId) {
        setActiveTable(undefined);
      }
    } else {
      if (table.tableId !== activeTable?.tableId) {
        setActiveTable(table);
      }
    }
   }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [activeTable]);

  const contextMenuChildren = () => {
    return (
      <>
          <div className={contextStyle.item} onClick={copyTable}>
              <div className={contextStyle.icon}><img src={iconDuplicateDark} alt="" /></div>
            <div>Copy table</div>
          </div>
          <div className={contextStyle.item} onClick={duplicateTable}>
              <div className={contextStyle.icon}><img src={iconDuplicateDark} alt="" /></div>
            <div>Duplicate table</div>
          </div>
          {table.operations.removeEnabled &&
          <div className={contextStyle.item} onClick={cutTable}>
          <div className={contextStyle.icon}><img src={iconCutDark} alt="" /></div>
          <div>Cut table</div>
      </div>
          }
          {table.operations.removeEnabled &&
          <div className={contextStyle.item} onClick={removeTable}>
          <div className={contextStyle.icon}><img src={iconDeleteDark} alt="" /></div>
          <div>Delete table</div>
      </div>
          }
      </>
    );
  };

  return (
    <div
      className={cl.container}
      ref={tableRef}
      style={{ top: position.y, left: position.x }}
      onMouseDown={disabled ? undefined : handleMouseDown}
      onMouseMove={disabled ? undefined : handleMouseMove}
      onMouseUp={disabled ? undefined : handleMouseUp}
      onContextMenu={disabled ? undefined : (e: any) => showMenu(e, contextMenuChildren())}
      >
        {activeTable?.tableId === table.tableId && <div className={cl.focus}></div>}
      <header className={cl.header}>
        <div className={cl.color}></div>
        <div className={cl.title}>
          <span>{table.name}</span>
        </div>
      </header>
      <div className={cl.content}>
        <div className={cl.items}>
          {table.columns.map((column) => (
            <div className={cl.item} key={column.tableColumnId}>
              <div className={cl.name}>
                <div className={cl.key}>{column.isPrimaryKey && <img src={iconKeyDark} alt="" />}</div>
                <span>{column.name}</span>
              </div>
              <div className={cl.type}>
                <span>{columnDataTypes[column.dataType]}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
