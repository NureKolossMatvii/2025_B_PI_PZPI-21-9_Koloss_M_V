import { useContext, useState } from "react";
import { Arrow } from "../../../components/UI/Arrow/Arrow";
import { MenuButton } from "../../../components/UI/MenuButton/MenuButton";
import { UMLTable } from "../../../interfaces/Models/UMLTable";
import { TableItemInfo } from "../TableItemInfo/TableItemInfo";
import cl from "./TableListItem.module.css";
import { DefaultInput } from "../../../components/UI/Input/DefaultInput";
import contextStyle from "../../../components/UI/ContextMenu/ContextMenu.module.css";
import { ContextMenuContext, DiagramContext } from "../../..";
import { Button } from "../../../components/UI/Button/Button";
import { iconAdd, iconAddDark, iconDelete, iconDeleteDark, iconDuplicate, iconDuplicateDark, iconEdit, iconEditDark } from "../../../assets";

interface IProps {
  table: UMLTable;
  isOpen: boolean;
  toggleTable: (tableId: string) => void;
  disabled?:boolean;
}

export const TableListItem = ({ table, isOpen, toggleTable, disabled}: IProps) => {
  const [nameEditionOpen, setNameEditionOpen] = useState<boolean>(false);
  const [tableName, setTableName] = useState<string>(table.name);
  const { addColumn, deleteTable, editTableName, cloneTableFromClipboard} = useContext(DiagramContext)!;
  const { showMenu, hideMenu } = useContext(ContextMenuContext)!;

  const toggleNameEdition = () => {
    setNameEditionOpen(!nameEditionOpen);
    editTableName(table.tableId, tableName);
    hideMenu();
  };

  const handleDeleteTable = () => {
    deleteTable(table.tableId);
    hideMenu();
  };

  const handleAddColumn = () => {
    addColumn(table.tableId);
    hideMenu();
  };

  const duplicateTable = () => {
    cloneTableFromClipboard(table);
    hideMenu();
  }

  const contextMenuChildren = () => {
    return (
      <>
        {table.operations.nameChangeEnabled && (
          <div className={contextStyle.item} onClick={toggleNameEdition}>
          <div className={contextStyle.icon}><img src={iconEditDark} alt="" /></div>
            <div>Edit table name</div>
          </div>
        )}
        {table.operations.columnCreationAvailable && (
          <div className={contextStyle.item} onClick={handleAddColumn}>
            <div className={contextStyle.icon}><img src={iconAddDark} alt="" /></div>
            <div>Add column</div>
          </div>
        )}
        <div className={contextStyle.item} onClick={duplicateTable}>
            <div className={contextStyle.icon}><img src={iconDuplicateDark} alt="" /></div>
          <div>Duplicate table</div>
        </div>
        {table.operations.removeEnabled && (
          <div className={contextStyle.item} onClick={handleDeleteTable}>
            <div className={contextStyle.icon}><img src={iconDeleteDark} alt="" /></div>
            <div>Delete table</div>
          </div>
        )}
      </>
    );
  };

  return (
    <div>
      <li
        className={cl.item}
        onClick={() => toggleTable(table.tableId)}
        onContextMenu={disabled ? undefined : (e: any) => showMenu(e, contextMenuChildren())}
      >
        <div className={cl.itemContent}>
          <div className={cl.block}>
            <div className={cl.color}></div>
            <Arrow size={15} active={isOpen} />
            {nameEditionOpen ? (
              <div
                className={cl.editionName}
                onClick={(e: any) => e.stopPropagation()}
              >
                <DefaultInput
                  inputType="text"
                  value={table.name}
                  onEnter={toggleNameEdition}
                  setValue={(val) => setTableName(val)}
                ></DefaultInput>
                <Button type="button" onClick={toggleNameEdition}>
                  Save
                </Button>
              </div>
            ) : (
              <div className={cl.title} onDoubleClick={disabled ? undefined : toggleNameEdition}>{table.name}</div>
            )}
          </div>
          <div className={cl.block}>
            <MenuButton
              size={15}
              onClick={(e: any) => !disabled && showMenu(e, contextMenuChildren())}
            ></MenuButton>
          </div>
        </div>
      </li>
      <div className={[cl.data, isOpen && cl.active].join(" ")}>
        <TableItemInfo disabled={disabled} columns={table.columns} table={table}></TableItemInfo>
      </div>
    </div>
  );
};
