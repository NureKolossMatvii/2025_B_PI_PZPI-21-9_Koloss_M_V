import React, {
  createRef,
  useContext,
  useEffect,
  useRef,
  useState,
  MutableRefObject,
  ReactElement,
} from "react";
import uuid from "react-uuid";
import { ContextMenuContext, DiagramContext, ProjectContext } from "../../..";
import { Button } from "../../../components/UI/Button/Button";
import { CustomSelect } from "../../../components/UI/CustomSelect/CustomSelect";
import { Modal } from "../../../components/UI/Modal/Modal";
import { useDimension } from "../../../hooks/useDimension";
import { UMLTableConnectionDto } from "../../../interfaces/Dto/UMLTableConnectionDto";
import { IDimension } from "../../../interfaces/IDimension";
import { UMLTableConnection } from "../../../interfaces/Models/UMLTableConnection";
import { DiagramConnections } from "../DiagramConnections/DiagramConnections";
import { DiagramLine } from "../UI/DiagramLine/DiagramLine";
import { DiagramTable } from "../UI/DiagramTable/DiagramTable";
import cl from "./UmlView.module.css";
import { ISelect } from "../../../interfaces/ISelect";
import { сonnectionType } from "../../../types/UMLConnectionType";
import { DefaultInput } from "../../../components/UI/Input/DefaultInput";
import { UMLTable } from "../../../interfaces/Models/UMLTable";
import { Loader } from "../../../components/Loader/Loader";
import { moveProjectToNextStep } from "../../../http/projectApi";
import { MoveToNextStepModal } from "../../../components/MoveToNextStepModal/MoveToNextStepModal";
import { ErrorsModel } from "../../../hooks/useDiagram";
import contextStyle from "../../../components/UI/ContextMenu/ContextMenu.module.css";
import { iconCopy, iconCopyDark, iconDiagram, iconDiagramDark, iconTableList, iconTableListDark } from "../../../assets";
import { UmlArea } from "../UmlArea/UmlArea";
import { downloadComponentAsImage } from "../../../utils/downloadComponentAsImage";
import { UmlImageEditor } from "../UmlImageEditor/UmlImageEditor";
import ReactFlowTables from "../ReactFlowTables/ReactFlowTables";
import DownloadButton from "../ReactFlowTables/DownloadButton";
import { ReactFlowProvider } from "reactflow";

interface IProps {
  disabled?:boolean
}

export const UmlView = ({disabled}:IProps) => {
  const { diagram, saveDiagram, setDiagram, deleteConnection, checkErrors, cloneTableFromClipboard, addNewConnection} = useContext(DiagramContext)!;
  const { project, fetchProject } = useContext(ProjectContext)!;
  const { clipboard } = useContext(DiagramContext)!;
  const areaRef = useRef<HTMLDivElement>(null);
  const [validationErrors, setValidationErrors] = useState<ErrorsModel>({success: true, messages: []})
  const { showMenu, hideMenu } = useContext(ContextMenuContext)!;

  const [connectionsModal, setConnectionsModal] = useState<boolean>(false);
  const [nextStepModal, setNextStepModal] = useState<boolean>(false);
  const [connections, setConnections] = useState<UMLTableConnection[]>([]);
  const [loading, setLoading] = useState<boolean>(false);

  const handleSave = async () => {
    if (project) {
      setLoading(true)
      await saveDiagram(project.projectConfigurationId).finally(() => setLoading(false));
    }
  };

  const onConnectionsModalClose = () => {
    setConnectionsModal(false);
  };

  const onConnectionsModalOpen = () => {
    setConnectionsModal(true);
  };

  useEffect(() => {
    setConnections([])
  }, [connectionsModal])

  const createNewConnection = () => {
   if (diagram?.tables[0]) {
    const newConnection: UMLTableConnection = {
      tableConnectionId: uuid(),
      leftTableId: diagram?.tables[0].tableId,
      rightTableId: diagram?.tables[0].tableId,
      foreignKeyColumnId: "",
      connectionType: 0,
    };

    setConnections([...connections, newConnection]);
   }
  };

  const handleChangeConnection = (newConnection: UMLTableConnection) => {
    setConnections(
      connections.map((connection) => {
        if (connection.tableConnectionId === newConnection.tableConnectionId) {
          return newConnection;
        }

        return connection;
      })
    );
  };

  const handleSaveConnections = () => {
    connections.map((connection) => {
      addNewConnection(connection.leftTableId, connection.rightTableId)
    })
  };

  const tableSelect = (): ISelect[] => {
    if (diagram?.tables) {
      const selectItems: ISelect[] = diagram?.tables?.map(
        (table) => ({
          value: table.tableId,
          label: table.name,
        })
      );

      return selectItems;
    }

    return [{ value: "0", label: "0" }];
  };

  const handleOpenNextStepModal = () => {
    const tableErrors = checkErrors.validateTables()
    const columnErrors = checkErrors.validateColumns();
    const connectionsErrors = checkErrors.validateConnections();
    setValidationErrors({
      success: tableErrors.success && columnErrors.success && connectionsErrors.success,
      messages: tableErrors.messages.concat(columnErrors.messages).concat(connectionsErrors.messages)
    })
    setNextStepModal(true);
  };

  const handleCloseNextStepModal = () => setNextStepModal(false);

  const fetchProjectData = async () => {
    if (project) {
      setLoading(true);
      await fetchProject(project?.projectConfigurationId).finally(() => setLoading(false));
    }
  }

  const moveToNextStep = async () => {
    if (project) {
      const move = async () => {
        setLoading(true);
        await moveProjectToNextStep(project.projectConfigurationId)
        .then(() => fetchProjectData())
        .finally(() => setLoading(false));
      }

      await handleSave().then(() => move())
    }
  };

  const pasteTable = () => {
    hideMenu();
    cloneTableFromClipboard();
  }

  const copyDiagram = () => {
    hideMenu();
    clipboard.copyDiagram();
  }

  const pasteDiagram = () => {
    hideMenu();
    clipboard.pasteDiagram();
  }

  const contextMenuChildren = () => {
    return (
      <>
          {!disabled &&
          <>
          <div className={contextStyle.item} onClick={pasteTable}>
            <div className={contextStyle.icon}><img src={iconTableListDark} alt="" /></div>
            <div>Paste table from clipboard</div>
          </div>
          <div className={contextStyle.item} onClick={pasteDiagram}>
              <div className={contextStyle.icon}><img src={iconDiagramDark} alt="" /></div>
            <div>Paste diagram</div>
          </div>
          </>
          }
          <div className={contextStyle.item} onClick={copyDiagram}>
              <div className={contextStyle.icon}><img src={iconCopyDark} alt="" /></div>
            <div>Copy diagram</div>
          </div>
      </>
    );
  };

  const renderUmlArea = ():ReactElement => {
    return (
      <UmlArea diagram={diagram} disabled={disabled} onContextMenu={(e: any) => showMenu(e, contextMenuChildren())} areaRef={areaRef}></UmlArea>
    )
  }

  return (
  <ReactFlowProvider>
   <Loader loading={loading}/>
    <div className={cl.container}>
      <Modal
        title="Connection settings"
        show={connectionsModal}
        onClose={onConnectionsModalClose}
      >
        <Button type="button" onClick={createNewConnection}>
          Create new connection
        </Button>
        <div className={cl.connections}>
          {diagram?.connections?.map((connection) => (
            <div key={connection.tableConnectionId} className={cl.connection}>
              <CustomSelect
                disabled
                value={connection.leftTableId}
                onChange={(id) =>
                  handleChangeConnection({ ...connection, leftTableId: id })
                }
                items={tableSelect()}
              ></CustomSelect>
              <div style={{textWrap: "nowrap"}}>has many</div>
              <CustomSelect
                disabled
                value={connection.rightTableId}
                onChange={(id) =>
                  handleChangeConnection({ ...connection, rightTableId: id })
                }
                items={tableSelect()}
              ></CustomSelect>
              <Button
                onClick={() => deleteConnection(connection.tableConnectionId)}
                type="button"
              >
                Delete
              </Button>
            </div>
          ))}
          {connections?.map((connection) => (
            <div key={connection.tableConnectionId} className={cl.connection}>
              <CustomSelect
                value={connection.leftTableId}
                onChange={(id) =>
                  handleChangeConnection({ ...connection, leftTableId: id })
                }
                items={tableSelect()}
              ></CustomSelect>
              <div style={{textWrap: "nowrap"}}>has many</div>
              <CustomSelect
                value={connection.rightTableId}
                onChange={(id) =>
                  handleChangeConnection({ ...connection, rightTableId: id })
                }
                items={tableSelect()}
              ></CustomSelect>
            </div>
          ))}
          {connections.length > 0 && <Button onClick={handleSaveConnections} type="button">Save</Button>}
        </div>
      </Modal>
      <MoveToNextStepModal show={nextStepModal} onClose={handleCloseNextStepModal} move={moveToNextStep} disabled={!validationErrors.success}>
        {!validationErrors.success ? 
        <>
          <div className={contextStyle.errorTitle}>There are some errors in your UML diagram. To move to the next step you need to solve problems</div>
          <div className={contextStyle.errorDescription}>Errors:</div>
          <div className={contextStyle.errors}>
            {validationErrors.messages.map((error) => 
              <div className={contextStyle.error}>{error}</div>
            )}
          </div>
        </>
        :
        undefined
        }
      </MoveToNextStepModal>
      <header className={cl.header}>
        <div className={cl.headerContent}>
          <div className={cl.block}>
            <div className={cl.controls}>
                <div className={cl.projectName}>{project?.name}</div>
              <div className={cl.saveButton}>
                <Button type="button" disabled={disabled} onClick={onConnectionsModalOpen}>
                  Connection settings
                </Button>
              </div>
              <div className={cl.saveButton}>
                <Button type="button" disabled={disabled} onClick={handleSave}>
                  Save diagram
                </Button>
              </div>
              <div className={cl.saveButton}>
                <DownloadButton />
              </div>
            </div>
          </div>
          <div className={cl.block}>
          <div className={cl.saveButton}>
                <Button type="button" disabled={disabled} onClick={handleOpenNextStepModal}>
                  Move to next step
                </Button>
              </div>
          </div>
        </div>
      </header>
      {diagram && <ReactFlowTables disabled={disabled} tables={diagram.tables} connections={diagram.connections} onContextMenu={(e: any) => showMenu(e, contextMenuChildren())}></ReactFlowTables>}
      {/* {renderUmlArea()} */}
    </div>
   </ReactFlowProvider>
  );
};
