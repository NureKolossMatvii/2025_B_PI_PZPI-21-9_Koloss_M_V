import React, { useContext } from "react";
import { CustomSelect } from "../../../components/UI/CustomSelect/CustomSelect";
import { DefaultInput } from "../../../components/UI/Input/DefaultInput";
import { MenuButton } from "../../../components/UI/MenuButton/MenuButton";
import { UMLTableColumn } from "../../../interfaces/Models/UMLTableColumn";
import cl from './TableColumn.module.css';
import contextStyle from "../../../components/UI/ContextMenu/ContextMenu.module.css";
import { ContextMenuContext, DiagramContext } from "../../..";
import { ISelect } from "../../../interfaces/ISelect";
import { columnDataTypes } from "../../../types/UMLColumnDataType";
import { UMLTable } from "../../../interfaces/Models/UMLTable";
import { iconKeyWhite, iconLabel, iconKeyYellow, iconKeyDark, iconLabelDark } from '../../assets';
import { iconDelete, iconDeleteDark } from "../../../assets";

interface IProps {
    column: UMLTableColumn,
    table: UMLTable
    disabled?:boolean
}

export const TableColumn = ({ column, table, disabled }: IProps) => {
    const { showMenu, hideMenu } = useContext(ContextMenuContext)!;
    const { editColumn, deleteColumn, editColumnLabel, renderColumnName} = useContext(DiagramContext)!;

    const editColumnName = (column: UMLTableColumn, value: string) => {
        const columnName = value !== "" ? value : renderColumnName(table.tableId)
        editColumn({ ...column, name: columnName });
      };
    
      const editColumnType = (column: UMLTableColumn, value: string) => {
        editColumn({ ...column, dataType: parseInt(value) });
      };
    
      const handleDeleteColumn = (columnId: string) => {
        deleteColumn(columnId);
        hideMenu();
      };
    
      const handleSetLabel = (columnId: string) => {
        editColumnLabel(table.tableId, columnId);
        hideMenu();
      }

      
        const selectItems: ISelect[] = columnDataTypes.map((type, index) => ({
            value: index.toString(),
            label: type,
        }));

    const contextMenuChildren = (column: UMLTableColumn) => {
        return (
          <>
            {column.operations.removeEnabled && (
              <div
                className={contextStyle.item}
                onClick={() => handleDeleteColumn(column.tableColumnId)}
              >
              <div className={contextStyle.icon}><img src={iconDeleteDark} alt="" /></div>
                <div>Delete column</div>
              </div>
            )}
            {column.operations.restrictionChangeAvailable && (
                <div
                className={contextStyle.item}
                onClick={() => handleSetLabel(column.tableColumnId)}
              >
                <div className={contextStyle.icon}><img src={iconLabelDark} alt="" /></div>
                <div>Set label</div>
              </div>
            )}
          </>
        );
      };

  return (
    <>
        <div className={cl.info}>
            {column.isPrimaryKey && <div className={cl.icon}><img src={iconKeyDark} alt="" /></div>}
            {column.isForeignKey && <div className={cl.icon}><img src={iconKeyYellow} alt="" /></div>}
            {table.labelColumnTableId === column.tableColumnId && (
            <div className={cl.icon}><img src={iconLabelDark} alt="" /></div>
            )}
        </div>
          <div>
            <DefaultInput
                value={column.name}
                disabled={!column.operations.nameChangeEnabled || disabled}
                setValue={(val) => editColumnName(column, val)}
                inputType="text"
            ></DefaultInput>
          </div>
          <div>
                <CustomSelect
                disabled={!column.operations.dataTypeChangeAvailable || disabled}
                items={selectItems}
                value={column.dataType}
                onChange={(value: string) => editColumnType(column, value)}
                ></CustomSelect>
          </div>
        <MenuButton
          size={15}
          onClick={(e: any) => !disabled && showMenu(e, contextMenuChildren(column))}
        ></MenuButton>
    </>
  );
};
