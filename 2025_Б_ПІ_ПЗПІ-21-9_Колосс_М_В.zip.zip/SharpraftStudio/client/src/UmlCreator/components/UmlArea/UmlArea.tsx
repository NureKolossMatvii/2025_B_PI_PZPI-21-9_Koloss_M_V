import React, { RefObject, useState, useEffect, useContext } from 'react'
import { DiagramContext } from '../../..';
import { useDimension } from '../../../hooks/useDimension';
import { UMLDiagram } from '../../../interfaces/Models/UMLDiagram';
import { UMLTable } from '../../../interfaces/Models/UMLTable';
import { DiagramConnections } from '../DiagramConnections/DiagramConnections';
import { DiagramTable } from '../UI/DiagramTable/DiagramTable';
import cl from './UmlArea.module.css';

interface IProps {
    diagram?: UMLDiagram | undefined
    disabled?: boolean
    areaRef?: RefObject<HTMLDivElement>
    onContextMenu?: (e: any) => void;
  }

export const UmlArea = ({areaRef, onContextMenu, diagram, disabled = false }: IProps) => {
    const { dimensions } = useDimension({ elementRef: areaRef })
    const { cloneTableFromClipboard, copyTableToClipboard, deleteTable} = useContext(DiagramContext)!;
    const [activeTable, setActiveTable] = useState<UMLTable | undefined>()

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            if (event.ctrlKey && event.code === 'KeyC' && activeTable) {
                event.preventDefault();
                copyTableToClipboard(activeTable.tableId)
            } else if (event.ctrlKey && event.code === 'KeyV') {
                event.preventDefault();
                cloneTableFromClipboard(activeTable);
            } else if (event.ctrlKey && event.code === 'KeyX' && activeTable) {
                event.preventDefault();
                copyTableToClipboard(activeTable.tableId)
                deleteTable(activeTable.tableId);
                setActiveTable(undefined)
            } else if (event.code === 'Delete' && activeTable) {
                event.preventDefault();
                deleteTable(activeTable.tableId);
                setActiveTable(undefined)
            }
        };
        
        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [activeTable]);

  return (
    <div className={cl.area} ref={areaRef} onContextMenu={disabled ? undefined : onContextMenu}>
        <DiagramConnections></DiagramConnections>
        {diagram?.tables?.map((table) => (
          <DiagramTable
            activeTable={activeTable}
            setActiveTable={setActiveTable}
            disabled={disabled}
            areaDemension={dimensions}
            table={table}
            key={table.tableId}
          />
        ))}
      </div>
  )
}
