import React, { useState, useRef } from 'react'
import ReactCrop, { type Crop } from 'react-image-crop'
import 'react-image-crop/dist/ReactCrop.css'
import { Button } from '../../../components/UI/Button/Button'

interface IProps {
    imageBlob: string
}

export const UmlImageEditor = ({ imageBlob }: IProps) => {
    const [crop, setCrop] = useState<Crop>({
      unit: '%',
      x: 25,
      y: 25,
      width: 50,
      height: 50,
    });
  
    const [doneImage, setDoneImage] = useState<string>();
    const imageRef = useRef<HTMLImageElement | null>(null);
  
    const handleCropComplete = () => {
      if (!imageRef.current || !crop.width || !crop.height) {
        return;
      }
  
      const canvas = document.createElement('canvas');
      const scaleX = imageRef.current.naturalWidth / imageRef.current.width;
      const scaleY = imageRef.current.naturalHeight / imageRef.current.height;
  
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
  
      canvas.width = crop.width * scaleX;
      canvas.height = crop.height * scaleY;
  
      ctx.drawImage(
        imageRef.current,
        crop.x * scaleX,
        crop.y * scaleY,
        crop.width * scaleX,
        crop.height * scaleY,
        0,
        0,
        canvas.width,
        canvas.height
      );
  
      const dataUrl = canvas.toDataURL('image/jpeg');
      setDoneImage(dataUrl);
    };

    const handleDownload = () => {
      if (!doneImage) return;
  
      const link = document.createElement('a');
      link.href = doneImage;
      link.download = 'uml-image.jpeg';
      link.click();
    };
  
    return (
      <div style={{display: "flex", flexDirection: "column", gap: 20, alignItems: "end"}}>
        <ReactCrop
          style={{cursor: "cell"}}
          crop={crop}
          onChange={(c) => setCrop(c)}
          onComplete={handleCropComplete}
        >
          <img
            src={imageBlob}
            ref={imageRef}
            alt="Source"
          />
        </ReactCrop>
        <Button style={{width: "auto"}} type="button" onClick={handleDownload}>
          Download
        </Button>
      </div>
    );
  };