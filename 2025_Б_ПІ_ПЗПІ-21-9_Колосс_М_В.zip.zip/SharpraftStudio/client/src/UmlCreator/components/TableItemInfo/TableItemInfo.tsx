import React, { Dispatch, SetStateAction, useContext } from "react";
import { ContextMenuContext, DiagramContext } from "../../..";
import { Button } from "../../../components/UI/Button/Button";
import { ContextMenu } from "../../../components/UI/ContextMenu/ContextMenu";
import { CustomSelect } from "../../../components/UI/CustomSelect/CustomSelect";
import { DefaultInput } from "../../../components/UI/Input/DefaultInput";
import { Input } from "../../../components/UI/Input/Input";
import { useContextMenu } from "../../../hooks/useContextMenu";
import { ISelect } from "../../../interfaces/ISelect";
import { UMLDiagram } from "../../../interfaces/Models/UMLDiagram";
import { UMLTable } from "../../../interfaces/Models/UMLTable";
import { UMLTableColumn } from "../../../interfaces/Models/UMLTableColumn";
import { columnDataTypes } from "../../../types/UMLColumnDataType";
import cl from "./TableItemInfo.module.css";
import { MenuButton } from "../../../components/UI/MenuButton/MenuButton";
import { TableColumn } from "../TableColumn/TableColumn";

interface IProps {
  columns: UMLTableColumn[];
  table: UMLTable;
  disabled?:boolean
}

export const TableItemInfo = ({ columns, table, disabled }: IProps) => {
  const { addColumn } = useContext(DiagramContext)!;

  return (
    <div className={cl.content}>
      <div className={cl.items}>
        {columns.map((column) => (
          <TableColumn key={column.tableColumnId} disabled={disabled} column={column} table={table}></TableColumn>
        ))}
      </div>
      {(table.operations.columnCreationAvailable && !disabled) && (
          <div className={cl.addButton}>
            <Button type="button" disabled={disabled} onClick={() => addColumn(table.tableId)}>
              Add column
            </Button>
          </div>
        )}
    </div>
  );
};
