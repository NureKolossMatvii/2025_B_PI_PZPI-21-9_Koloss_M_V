import React from "react";
import { EdgeProps, getSmoothStepPath, getStraightPath, Position } from "reactflow";

const foreignObjectSize = 28;

export default function CustomEdge({
  id,
  sourceX,
  sourceY,
  targetX,
  targetY,
  sourcePosition,
  targetPosition,
  style = {},
  markerEnd,
}: EdgeProps) {
  const [path] = getSmoothStepPath({
    sourceX,
    sourceY,
    sourcePosition,
    targetX,
    targetY,
    targetPosition,
  });

  const getOffset = (pos: Position) => {
    if(pos === 'bottom'){
      return {
        y: 10,
        x: -6
      }
    }

    return {
        x: 10,
        y: -6
    }
  }

  const sourceOffset = getOffset(sourcePosition);
  const targetOffset = getOffset(targetPosition);

  return (
    <>
      <text
        x={sourceX + sourceOffset.x + 6}
        y={sourceY + sourceOffset.y - 6}
        fill="#7d7d80"
        fontSize={20}
        textAnchor="middle"
        dominantBaseline="middle"
      >
        V
      </text>
      <text
        x={targetX + targetOffset.x - 10}
        y={targetY + targetOffset.y - 10}
        fill="#7d7d80"
        fontSize={20}
        textAnchor="middle"
        dominantBaseline="middle"
      >
        __
      </text>
      <path
        id={id}
        style={{ ...style, cursor: "pointer" }}
        className="react-flow__edge-path"
        d={path}
        markerEnd={markerEnd}
      />
    </>
  );
}
