import React, { useState } from 'react';

import { toPng } from 'html-to-image';
import { getNodesBounds, getViewportForBounds, Panel, useReactFlow } from 'reactflow';
import { Modal } from '../../../components/UI/Modal/Modal';
import { UmlImageEditor } from '../UmlImageEditor/UmlImageEditor';
import { Button } from '../../../components/UI/Button/Button';
 
function downloadImage(dataUrl: string) {
    console.log(dataUrl)
//   const a = document.createElement('a');
 
//   a.setAttribute('download', 'reactflow.png');
//   a.setAttribute('href', dataUrl);
//   a.click();
}
 
const imageWidth = 1024;
const imageHeight = 768;
 
function DownloadButton() {
  const { getNodes } = useReactFlow();
  const [umlImageModal, setUmlImageModal] = useState<boolean>(false);
  const [umlImage, setUmlImage] = useState<string>("");

  const onUmlImageModalClose = () => setUmlImageModal(false)
  const onUmlImageModalOpen = (dataUrl: string) => {
    setUmlImage(dataUrl);
    setUmlImageModal(true);
  }


  const onClick = () => {
    const nodesBounds = getNodesBounds(getNodes());
    const viewport = getViewportForBounds(
      nodesBounds,
      imageWidth,
      imageHeight,
      0.5,
      2,
    );
 
    const element = document.querySelector('.react-flow__viewport');
    if(element instanceof HTMLElement) {
        toPng(element, {
            backgroundColor: '#ffffff',
            width: imageWidth,
            height: imageHeight,
            style: {
              width: `${imageWidth}`,
              height: `${imageHeight}`,
              transform: `translate(${viewport.x}px, ${viewport.y}px) scale(${viewport.zoom})`,
            },
          }).then(onUmlImageModalOpen);
    }
    
  };
 
  return (
    <>
      <Modal
        title="Downloading uml image"
        show={umlImageModal}
        onClose={onUmlImageModalClose}
      >
       <UmlImageEditor imageBlob={umlImage}></UmlImageEditor>
      </Modal>
      <Button type='button' onClick={onClick}>Download UML</Button>
    </>
  );
}
 
export default DownloadButton;