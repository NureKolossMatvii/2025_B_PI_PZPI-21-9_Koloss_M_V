import { toPng } from "html-to-image";
import React, {
  useRef,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from "react";
import ReactFlow, {
  addEdge,
  Background,
  Controls,
  MiniMap,
  Edge,
  MarkerType,
  Node,
  Connection,
  NodeChange,
  EdgeChange,
  applyNodeChanges,
  applyEdgeChanges,
  ConnectionLineType,
  NodePositionChange,
  Viewport,
  useReactFlow,
  useNodesState,
  ReactFlowProvider,
  useEdgesState,
  Panel,
  getNodesBounds,
  getViewportForBounds,
  BackgroundVariant,
  Handle,
  Position,
} from "reactflow";
import "reactflow/dist/style.css";
import { DiagramContext } from "../../..";
import { iconAngleSmallLeftDark } from "../../../Admin/components/AdminNavbar/assets";
import { Arrow } from "../../../components/UI/Arrow/Arrow";
import { Button } from "../../../components/UI/Button/Button";
import { UMLDiagram } from "../../../interfaces/Models/UMLDiagram";
import { UMLTable } from "../../../interfaces/Models/UMLTable";
import { UMLTableConnection } from "../../../interfaces/Models/UMLTableConnection";
import { DiagramTable } from "../UI/DiagramTable/DiagramTable";
import CustomEdge from "./CustomEdge";
import DownloadButton from "./DownloadButton";

interface IProps {
  tables: UMLTable[];
  connections: UMLTableConnection[];
  onContextMenu?: (e: any) => void;
  disabled?: boolean
}

const ReactFlowTables = ({ tables, connections, onContextMenu, disabled }: IProps) => {
  const defaultNodeOptions = (inputTables: UMLTable[]): Node[] =>
    inputTables.map((table) => {
      return {
        style: { width: "auto", padding: 0, borderColor: "transparent" },
        connectable: !disabled,
        selectable: !disabled,
        type: "default",
        id: table.tableId,
        data: { label: <DiagramTable disabled={disabled} table={table} key={table.tableId} /> },
        position: { x: table.position.x, y: table.position.y },
      };
    });

  const defaultEdgesOptions = (
    inputConnections: UMLTableConnection[]
  ): Edge<any>[] =>
    inputConnections.map((connection) => {
      return {
        id: connection.tableConnectionId,
        source: connection.connectionType === 0 ? connection.rightTableId : connection.leftTableId,
        target: connection.connectionType === 0 ? connection.leftTableId : connection.rightTableId,
        type: "custom",
        deletable: true,
        className: "normal-edge",
        markerEnd: {type: MarkerType.Arrow},
      };
    });

  const {
    changeTablePosition,
    registerOnTableChangeFunction,
    registerOnConnectionChangeFunction,
    addNewConnection,
  } = useContext(DiagramContext)!;
  const [nodes, setNodes, onNodesChange] = useNodesState(
    defaultNodeOptions(tables)
  );
  const [edges, setEdges, onEdgesChange] = useEdgesState(
    defaultEdgesOptions(connections)
  );

  useEffect(() => {
    registerOnTableChangeFunction("position", (tables: UMLTable[]) => {
      setNodes(defaultNodeOptions(tables));
    });

    registerOnConnectionChangeFunction(
      "connection",
      (connections: UMLTableConnection[]) => {
        setEdges(defaultEdgesOptions(connections));
      }
    );
  }, []);

  const onNodesChangeInternal = (changes: NodeChange[]) => {
    if(disabled) return;
    onNodesChange(changes);
    changes.map((change) => {
      if (change.type === "position" && change.position) {
        changeTablePosition(change.id, {
          x: Math.round(change.position.x),
          y: Math.round(change.position.y),
        });
      }
    });
  };

  const onEdgesChangeInternal = (changes: EdgeChange[]) => {
    if(disabled) return;
    onEdgesChange(changes);
  };

  const onConnect = (connection: Connection) => {
    if(disabled) return;
    setEdges((eds) => addEdge({ ...connection }, eds));
    if (connection.source && connection.target) {
      addNewConnection(connection.target, connection.source);
    }
  };

  return (
      <div style={{ height: "100%", width: "100%" }}>
        <ReactFlow
           onContextMenu={onContextMenu}
          edgeTypes={{ custom: CustomEdge }}
          defaultEdgeOptions={{ type: ConnectionLineType.SmoothStep }}
          connectionLineType={ConnectionLineType.SmoothStep}
          onNodesChange={onNodesChangeInternal}
          nodes={nodes}
          edges={edges}
          onEdgesChange={onEdgesChangeInternal}
          onConnect={onConnect}
          fitView
        >
          <Controls />
          <MiniMap></MiniMap>
          <Background/>
        </ReactFlow>
      </div>
  );
};

export default ReactFlowTables;
