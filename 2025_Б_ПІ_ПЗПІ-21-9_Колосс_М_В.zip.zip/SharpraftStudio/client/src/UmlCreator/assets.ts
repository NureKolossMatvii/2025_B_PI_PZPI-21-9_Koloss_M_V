export const iconKeyDark = require('./assets/key_dark.png');
export const iconKeyWhite = require('./assets/key_white.png')

export const iconKeyYellow = require('./assets/key_yellow.png')

export const iconLabel = require('./assets/brand.png')
export const iconLabelDark = require('./assets/brand_dark.png')