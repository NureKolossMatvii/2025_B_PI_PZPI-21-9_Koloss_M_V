import HTMLReactParser from 'html-react-parser';
import React, { useState, useContext, useEffect } from 'react'
import { ClientTextInfoContext } from '../../..';
import { Loader } from '../../../components/Loader/Loader';
import { Button } from '../../../components/UI/Button/Button';
import { howToDownloadTextKey, mainTextKey } from '../../../consts';
import { IClientTextInfoItem } from '../../../interfaces/Models/IClientTextInfoItem';
import { ClientTextInfoKey } from '../../../types/ClientTextInfoKey';
import { MainTextModal } from '../components/Modals/MainTextModal/TextModal';
import cl from './SiteConfig.module.css';

interface TextModalChild {
  title: string,
  key: ClientTextInfoKey
}

export const SiteConfig = () => {
  const [loading, setLoading] = useState<boolean>(false);
  const [textModal, setTextModal] = useState<boolean>(false);
  const [textModalChild, setTextModalChild] = useState<TextModalChild | undefined>()
  const {getClientTextInfoByKey, clientTextInfo} = useContext(ClientTextInfoContext)!;

  const [textData, setTextData] = useState<IClientTextInfoItem[]>([]);

  const handleMainTextModalOpen = (item: TextModalChild) => {
    setTextModalChild(item)
    setTextModal(true)
  }
  const handleMainTextModalClose = () => setTextModal(false);

  useEffect(() => {
    setTextData(clientTextInfo)
  }, [clientTextInfo])

  const renderText = (inputKey: ClientTextInfoKey, title: string) => {
    const text = textData.find(({key}) => key === inputKey);
    return (
      <div className={cl.textContent}>
        <div className={cl.textBlock}>
          <div className={cl.title}>{title} (En)</div>
          <div className={cl.textWrapper}>{text ? HTMLReactParser(text.engLabel) : ""}</div>
        </div>
        <div className={cl.textBlock}>
          <div className={cl.title}>{title} (Ru)</div>
          <div className={cl.textWrapper}>{text ? HTMLReactParser(text.ruLabel) : ""}</div>
        </div>
      </div>
    )
  }

  return (
    <>
    <Loader loading={loading}></Loader>
    <div className={cl.container}>
      {textModalChild && <MainTextModal setLoading={setLoading} show={textModal} onHide={handleMainTextModalClose} title={textModalChild.title} clientTextInfoKey={textModalChild.key}></MainTextModal>}
      <div className={cl.block}>
        {renderText(mainTextKey, "Main page text")}
        <Button style={{width: "auto"}} type="button" onClick={() => handleMainTextModalOpen({key: mainTextKey, title: "Main page text"})}>Edit text</Button>
      </div>
      <div className={cl.block}>
        {renderText(howToDownloadTextKey, "How to download text")}
        <Button style={{width: "auto"}} type="button" onClick={() => handleMainTextModalOpen({key: howToDownloadTextKey, title: "How to download text"})}>Edit text</Button>
      </div>
    </div>
    </>
  )
}
