import React, { useState, useContext, useEffect } from 'react'
import { ClientTextInfoContext } from '../../../../..';
import { Button } from '../../../../../components/UI/Button/Button';
import { Modal } from '../../../../../components/UI/Modal/Modal'
import { addClientTextInfo } from '../../../../../http/clientTextInfoClient';
import { IClientTextInfoItem } from '../../../../../interfaces/Models/IClientTextInfoItem';
import { ClientTextInfoKey } from '../../../../../types/ClientTextInfoKey';
import { CustomCKEditor } from '../../../../components/CustomCKEditor/CustomCKEditor';
import cl from './TextModal.module.css';

interface IProps {
    onHide: () => void;
    show: boolean,
    setLoading: (val: boolean) => void,
    clientTextInfoKey: ClientTextInfoKey,
    title: string
}

type LanguageTextType = "EN" | "RU";

export const MainTextModal = ({onHide, show, setLoading, clientTextInfoKey, title}:IProps) => {
  const {getClientTextInfoByKey, fetchClientTextInfo} = useContext(ClientTextInfoContext)!;
  const [text, setText] = useState<IClientTextInfoItem>({key: clientTextInfoKey, engLabel: "", ruLabel: ""})

  useEffect(() => {
    setLoading(true)
    getClientTextInfoByKey(clientTextInfoKey).then((data) => {
      setText(data)
    }).finally(() => setLoading(false))
  }, [clientTextInfoKey])

  const handleChangeText = (value: string, type: LanguageTextType) => {
    switch (type) {
      case "EN":
        setText({...text, engLabel: value})
        break;
      case "RU":
        setText({...text, ruLabel: value})
        break;
    }
  }

  const handleSave = async () => {
    setLoading(true);
    await addClientTextInfo(text).then(() => {
      onHide()
      fetchClientTextInfo()
    }).finally(() => setLoading(false));
  }

  return (
    <Modal title={title} onClose={onHide} show={show}>
        <div className={cl.container}>
          <div className={cl.editors}>
            <div>
              <div className={cl.title}>Text (EN)</div>
              <CustomCKEditor defaultValue={text.engLabel} onChange={(val) => handleChangeText(val, "EN")}></CustomCKEditor>
            </div>
            <div>
              <div className={cl.title}>Text (RU)</div>
              <CustomCKEditor defaultValue={text.ruLabel} onChange={(val) => handleChangeText(val, "RU")}></CustomCKEditor>
            </div>
          </div> 
          <div className={cl.buttons}>
            <Button style={{width: "auto"}} theme="light" type='button' onClick={onHide}>Cancel</Button>
            <Button style={{width: "auto"}} type='button' onClick={handleSave}>Save</Button>
          </div>
        </div>
    </Modal>
  )
}
