import React, { useEffect } from 'react'
import { CKEditor } from '@ckeditor/ckeditor5-react';
import { ClassicEditor, Bold, FontSize, EventInfo, Editor, Essentials, WordCount, Italic, ImageInsert, Image, Alignment, Table, Underline, Heading, Paragraph, Undo, Font, Strikethrough, Subscript, Superscript, Code, Link, BlockQuote, CodeBlock, List, Indent, SourceEditing} from 'ckeditor5';
import cl from './CustomCKEditor.module.css';

import 'ckeditor5/ckeditor5.css';

interface IProps {
  defaultValue: string,
  onChange: (value: string) => void
}

export const CustomCKEditor = ({defaultValue, onChange}: IProps) => {

    const handleWordCounter = (data: { words: number; characters: number;}) => {
        // console.log(data.words)
    }

    const handleChange = (event: EventInfo, editor: Editor) => {
        const data = editor.getData();
        onChange(data)
    };

  return (
    <div className={cl.container}>
        <CKEditor
    editor={ ClassicEditor }
    config={ {
        wordCount: {
            displayWords: true,
            onUpdate: handleWordCounter
        },
      plugins: [ Essentials, Bold, Alignment, Image, ImageInsert, WordCount, Table, FontSize, Heading, Underline, Italic, Paragraph, Undo, Font, Strikethrough, Subscript, Superscript, Code, Link, BlockQuote, CodeBlock, List, Indent, SourceEditing],
      fontSize: {
        options: Array.from({ length: 12 }, (_, i) => 10 + i * 2)
      },
      image: {
        insert: {
            integrations: [ 'upload' ]
        }
    },
      toolbar: {
        items: [
            
            'undo', 'redo', '|', 'heading', '|', 'fontfamily', 'fontSize', 'fontColor', 'fontBackgroundColor', '|',
            'bold', 'italic', 'underline', 'strikethrough', '|', 'code',
            '-',
            'subscript', 'superscript', '|', 'bulletedList', 'numberedList', 'alignment', '|', 'insertTable', 'link', 'insertImage', '|', 'sourceEditing', 'blockQuote', 'codeBlock', 'todoList', 'outdent', 'indent'
      ],
      shouldNotGroupWhenFull: true
      }
    }}
    data={defaultValue}
    contextItemMetadata={{
        name: 'editor1',
        yourAdditionalData: 2
    }}
    onChange={handleChange}
    onReady={ ( editor ) => {
    } }
  />
  {/* <div className={cl.}></div> */}
    </div>
  )
}
