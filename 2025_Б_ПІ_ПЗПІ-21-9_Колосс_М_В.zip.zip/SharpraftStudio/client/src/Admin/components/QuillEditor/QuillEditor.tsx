import React, { useState, useEffect } from "react";
import ReactQuill, { Quill } from "react-quill";
import "react-quill/dist/quill.snow.css";
interface IProps {
    value: string,
    onChange: (value: string) => void
}

export const QuillEditor = ({value, onChange}:IProps) => {
    const handleChange = (content: string) => {
        onChange(content);
      };

  const modules = {
    toolbar: [
        [{ font: [] }],
        [{ size: [] }],
        ['bold', 'italic', 'underline', 'strike', 'blockquote'], 
        [{ 'script': 'sub'}, { 'script': 'super' }],
        [
          { list: 'ordered' },
          { list: 'bullet' },
          { indent: '-1' },
          { indent: '+1' }
        ],
        [{ color: [] }],
        [{ background: [] }],
        ['link', 'image', 'video'],
        ['clean'],
      ],
      clipboard: {
        matchVisual: false  
      },
}
const formats = [
    'header',
    'font',
    'size',
    'bold',
    'italic',
    'underline',
    'strike',
    'blockquote',
    'list',
    "color",
    'bullet',
    'indent',
    'link','image', 'video',
]


  return (
      <ReactQuill
        style={{ width: "100%", height: "100%"}}
        theme="snow"
        modules={modules}
        formats={formats}
        value={value}
        onChange={handleChange}
      />
  );
};
