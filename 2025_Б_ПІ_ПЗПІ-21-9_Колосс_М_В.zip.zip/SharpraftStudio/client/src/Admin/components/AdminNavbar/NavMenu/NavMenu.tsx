import React, { useState, ReactElement } from "react";
import { Button } from "../../../../components/UI/Button/Button";
import {
  ADMIN_PAGE_SITE_CONFIGURATION,
  ADMIN_PAGE_SITE_STOP_WORDS,
  ADMIN_TEMPLATES_ROUTE,
  ADMIN_USERS_ROUTE,
} from "../../../../routesConsts";
import {
  iconAngleSmallLeft,
  iconAngleSmallLeftDark,
  iconAngleSmallRight,
  iconAngleSmallRightDark,
  iconFileWord,
  iconGears,
  iconGearsDark,
  iconTemplates,
  iconTemplatesDark,
  iconText,
  iconUsers,
  iconUsersDark,
} from "../assets";
import { NavItem } from "../NavItem/NavItem";
import cl from "./NavMenu.module.css";

export interface INavItem {
  node: ReactElement;
  link: string;
  icon?: string;
  items?: INavItem[]
}

interface IProps {
}

export const NavMenu = ({}:IProps) => {

  const firstBlockTabItems: INavItem[] = [
    { node: <>Users</>, link: ADMIN_USERS_ROUTE, icon: iconUsersDark, items: [] },
    { node: <>Templates</>, link: ADMIN_TEMPLATES_ROUTE, icon: iconTemplatesDark, items: [] },
    { node: <>Configurations</>, link: "", icon: iconGearsDark, items: [
      // { node: <>Stop words</>, icon: iconFileWord, link: ADMIN_PAGE_SITE_STOP_WORDS, items: [] },
      { node: <>Text configuration</>, icon: iconText, link: ADMIN_PAGE_SITE_CONFIGURATION, items: [] }
    ] },
  ];

  return (
    <div className={[cl.container].join(" ")}>
      <div className={cl.header}>
        <span>Admin console</span>
      </div>
      <div className={cl.items}>
        {firstBlockTabItems.map((item) => (
          <NavItem item={item} />
        ))}
      </div>
    </div>
  );
};
