import React, { ReactNode, useState } from 'react';
import cl from './AdminNavbar.module.css';
import { NavMenu } from './NavMenu/NavMenu';

interface IProps {
    children: ReactNode
}

export const AdminNavbar = ({children}: IProps) => {

  return (
    <div className={cl.container}>
        <NavMenu></NavMenu>
        <div className={cl.content}>
            {children}
        </div>
    </div>
  )
}
