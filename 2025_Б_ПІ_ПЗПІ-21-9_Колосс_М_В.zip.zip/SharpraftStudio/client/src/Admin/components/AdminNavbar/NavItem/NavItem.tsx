import React, { useState } from 'react'
import { NavLink } from 'react-router-dom';
import { Arrow } from '../../../../components/UI/Arrow/Arrow';
import { INavItem } from '../NavMenu/NavMenu';
import cl from './NavItem.module.css';

interface IProps {
    item: INavItem,
}

export const NavItem = ({item}:IProps) => {
  const [active, setActive] = useState<boolean>(false)

  return (item.items?.length !== 0 && item.items !== undefined) ? (
    <>
      <div className={cl.item} onClick={() => setActive(!active)}>
        <div className={cl.block}>
          {item.icon && <div className={cl.icon}><img src={item.icon} alt="" /></div>}
          <div className={cl.label}>{item.node}</div>
        </div>
        <Arrow active={active} size={15}></Arrow>
      </div>
      {active &&
        <div style={{paddingLeft: "10px"}}>
          {item.items?.map((item) => (
            <NavItem item={item} />
          ))}
        </div>
        }
      </>
  ) :
  (
    <NavLink to={item.link} className={cl.item}>
    <div className={cl.block}>
      {item.icon && <div className={cl.icon}><img src={item.icon} alt="" /></div>}
      <div className={cl.label}>{item.node}</div>
    </div>
    {item.items?.length !== 0 && <Arrow active={active} size={15}></Arrow>}
  </NavLink> 
  )
}
