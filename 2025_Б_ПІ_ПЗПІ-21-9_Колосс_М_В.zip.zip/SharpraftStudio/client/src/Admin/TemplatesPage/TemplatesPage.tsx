import React, { useState, useEffect } from "react";
import { Loader } from "../../components/Loader/Loader";
import { getTemplates } from "../../http/templateApi";
import { ITemplate } from "../../interfaces/Templates/ITemplate";
import { TemplateCreateModal } from "./components/Modals/TemplateCreateModal/TemplateCreateModal";
import { TemplateDeleteModal } from "./components/Modals/TemplateDeleteModal/TemplateDeleteModal";
import { TemplateEditModal } from "./components/Modals/TemplateEditModal/TemplateEditModal";
import { TemplateItems } from "./components/TemplateItems/TemplateItems";
import cl from './TemplatesPage.module.css';

export const TemplatesPage = () => {
  const [templates, setTemplates] = useState<ITemplate[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [createModal, setCreateModal] = useState<boolean>(false);
  const [editModal, setEditModal] = useState<boolean>(false)
  const [deleteModal, setDeleteModal] = useState<boolean>(false)

  const [editionItem, setEditionItem] = useState<ITemplate | null>(null);
  const [deleteItem, setDeleteItem] = useState<ITemplate | null>(null);

  const handleOpenCreateModal = () => setCreateModal(true);
  const handleCloseCreateModal = () => setCreateModal(false);

  const handleOpenDeleteModal = (template: ITemplate) => {
    setDeleteItem(template)
    setDeleteModal(true)
  };
  const handleCloseDeleteModal = () => setDeleteModal(false);

  const handleOpenEditModal = (template: ITemplate) => {
    setEditionItem(template);
    setEditModal(true);
  }
  
  const handleCloseEditModal = () => setEditModal(false);

  const fetchTemplates = async () => {
    setLoading(true);
    await getTemplates()
      .then((data) => setTemplates(data))
      .finally(() => setLoading(false));
  };

  useEffect(() => {
    fetchTemplates();
  }, []);

  return (
    <div className={cl.container}>
      <Loader loading={loading} />
      <TemplateCreateModal
        show={createModal}
        onHide={handleCloseCreateModal}
        fetchItems={fetchTemplates}
      ></TemplateCreateModal>
      <TemplateEditModal
        show={editModal}
        item={editionItem}
        onHide={handleCloseEditModal}
        fetchItems={fetchTemplates}
      ></TemplateEditModal>
      <TemplateDeleteModal
        show={deleteModal}
        onHide={handleCloseDeleteModal}
        deleteItem={deleteItem}
        fetchItems={fetchTemplates}
      ></TemplateDeleteModal>
      <div className={cl.title}>Templates</div>
      <TemplateItems
        templates={templates}
        handleOpenCreateModal={handleOpenCreateModal}
        handleOpenEditModal={handleOpenEditModal}
        handleOpenDeleteModal={handleOpenDeleteModal}
      />
    </div>
  );
};
