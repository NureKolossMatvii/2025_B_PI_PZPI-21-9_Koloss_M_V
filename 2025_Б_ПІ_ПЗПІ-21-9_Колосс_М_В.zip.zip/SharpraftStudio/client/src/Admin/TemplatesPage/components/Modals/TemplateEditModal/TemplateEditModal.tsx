import React from 'react'
import { Button } from '../../../../../components/UI/Button/Button';
import { Modal } from '../../../../../components/UI/Modal/Modal';
import { ITemplate } from '../../../../../interfaces/Templates/ITemplate';
import { ADMIN_PAGE_PREVIEW } from '../../../../../routesConsts';
import { EditForm } from '../../Forms/EditForm/EditForm';
import cl from './TemplateEditModal.module.css';

interface IProps {
    onHide: () => void;
    show: boolean;
    fetchItems: () => void;
    item: ITemplate | null
}

export const TemplateEditModal = ({onHide, show, fetchItems, item}:IProps) => {

    const openPreview = () => {
        const params = 'scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,width=1000,height=800,left=100,top=100';
        window.open(ADMIN_PAGE_PREVIEW, '_blank', params);
      };

  return (
    <Modal
    onClose={onHide}
    show={show}
    title="Edit template"
  >
    <div className={cl.previewButton}><Button type='button' style={{width: "auto"}} onClick={openPreview}>Open Preview</Button></div>
   {item && <EditForm item={item} fetchItems={fetchItems} handleCloseCreateModal={onHide}></EditForm>}
  </Modal>
  )
}