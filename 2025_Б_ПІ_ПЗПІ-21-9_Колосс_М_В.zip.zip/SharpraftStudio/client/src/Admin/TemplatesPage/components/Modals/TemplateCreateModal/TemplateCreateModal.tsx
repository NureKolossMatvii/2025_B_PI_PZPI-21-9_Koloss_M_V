import React from 'react'
import { Button } from '../../../../../components/UI/Button/Button';
import { Modal } from '../../../../../components/UI/Modal/Modal'
import { ADMIN_PAGE_PREVIEW } from '../../../../../routesConsts';
import { CreateForm } from '../../Forms/CreateForm/CreateForm';
import cl from './TemplateCreateModal.module.css';

interface IProps {
    onHide: () => void;
    show: boolean;
    fetchItems: () => void
}

export const TemplateCreateModal = ({onHide, show, fetchItems}:IProps) => {

    const openPreview = () => {
        const params = 'scrollbars=no,resizable=no,status=no,location=no,toolbar=no,menubar=no,width=1000,height=800,left=100,top=100';
        window.open(ADMIN_PAGE_PREVIEW, '_blank', params);
      };

  return (
    <Modal
    onClose={onHide}
    show={show}
    title="Create template"
  >
    <div className={cl.previewButton}><Button type='button' style={{width: "auto"}} onClick={openPreview}>Open Preview</Button></div>
   <CreateForm fetchItems={fetchItems} handleCloseCreateModal={onHide}></CreateForm>
  </Modal>
  )
}
