import React from 'react'
import { Button } from '../../../../../components/UI/Button/Button';
import { Modal } from '../../../../../components/UI/Modal/Modal';
import { deleteTemplate } from '../../../../../http/templateApi';
import { ITemplate } from '../../../../../interfaces/Templates/ITemplate';
import cl from './TemplateDeleteModal.module.css';

interface IProps {
    onHide: () => void;
    show: boolean;
    fetchItems: () => void;
    deleteItem: ITemplate | null;
}

export const TemplateDeleteModal = ({onHide, show, fetchItems, deleteItem}:IProps) => {

    const remove = async () => {
        if (deleteItem) {
            await deleteTemplate(deleteItem.colorTemplateId)
            .then(() => {
              fetchItems();
              onHide()
            })
        }
    }

  return (
    <Modal
    onClose={onHide}
    show={show}
    title="Delete template"
  >
    <div className={cl.title}>Are you sure you want to delete the template "{deleteItem?.title}"?</div>
    <div className={cl.buttons}>
        <Button theme="light" type='button' style={{width: "auto"}} onClick={onHide}>Cancel</Button>
        <Button type='button' style={{width: "auto"}} onClick={remove}>Delete</Button>
    </div>
  </Modal>
  )
}

