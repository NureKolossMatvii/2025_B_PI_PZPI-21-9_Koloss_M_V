import React from 'react'
import { ITemplate } from '../../../../interfaces/Templates/ITemplate';
import cl from './TemplateItems.module.css';
import { iconAdd, iconAddDark, iconDelete, iconDeleteDark, iconEdit, iconEditDark } from '../../../../assets';

interface IProps {
    templates: ITemplate[]
    handleOpenCreateModal: () => void
    handleOpenDeleteModal: (template: ITemplate) => void
    handleOpenEditModal: (template: ITemplate) => void
}

export const TemplateItems = ({templates, handleOpenCreateModal, handleOpenEditModal, handleOpenDeleteModal}: IProps) => {
  return (
    <div className={cl.container}>
        <div className={cl.items}>
            {templates.map((template) => 
                <div className={cl.item}>
                    <div className={cl.edition}>
                        <div onClick={() => handleOpenEditModal(template)}><img src={iconEditDark} alt="" /></div>
                        <div onClick={() => handleOpenDeleteModal(template)}><img src={iconDeleteDark} alt="" /></div>
                    </div>
                    <div className={cl.label}>{template.title}</div>
                </div>
            )}
            <div className={cl.item} onClick={handleOpenCreateModal}>
                <img src={iconAddDark} alt="" />
            </div>
        </div>
    </div>
  )
}
