import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { FormLayout } from "../../../../../components/FormLayout/FormLayout";
import { Button } from "../../../../../components/UI/Button/Button";
import { DefaultInput } from "../../../../../components/UI/Input/DefaultInput";
import { InputColorSelector } from "../../../../../components/UI/InputColorSelector/InputColorSelector";
import { editTemplate } from "../../../../../http/templateApi";
import { IColor } from "../../../../../interfaces/IColor";
import { ITemplate } from "../../../../../interfaces/Templates/ITemplate";
import cl from './EditForm.module.css'
import { ITemplateColor } from "../../../../../interfaces/Templates/ITemplateColor";
import { ITemplateButton } from "../../../../../interfaces/Templates/ITemplateButton";

interface IProps {
  fetchItems: () => void;
  handleCloseCreateModal: () => void;
  item: ITemplate
}

export const EditForm = ({ fetchItems, handleCloseCreateModal, item}: IProps) => {
  const [formData, setFormData] = useState<ITemplate>(item);
  
  const updateColor = (key: string, value: IColor) => {
    setFormData((prevFormData) => ({
      ...prevFormData,
      colors: {
        ...prevFormData?.colors,
        [key]: value.hex,
      },
    }));
  };

  const updateButtonColor = (
    firstKey: keyof ITemplateColor,
    key: keyof ITemplateButton,
    value: IColor
  ) => {
    setFormData((prevFormData) => {
      const currentColor = prevFormData?.colors[firstKey] || {};

      return {
        ...prevFormData,
        colors: {
          ...prevFormData?.colors,
          [firstKey]: {
            ...(currentColor || {}),
            [key]: value.hex,
          },
        },
      };
    });
  };

  useEffect(() => {
    if (formData?.colors) {
      const channel = new BroadcastChannel("color-change");
      channel.postMessage({ color: formData.colors });
      channel.close();
    }
  }, [formData]);

  const edit = async () => {
    await editTemplate(formData)
      .then(() => {
        fetchItems();
        handleCloseCreateModal();
      })
      .catch((error) => console.error(error));
  };

  return (
    <div>
      <FormLayout onSubmit={edit}>
        <div className={cl.form}>
          <DefaultInput
            label="Title"
            inputType="text"
            value={formData.title}
            setValue={(value) => setFormData({ ...formData, title: value })}
          ></DefaultInput>
          <div className={cl.blocks}>
            <div>
              <div className={cl.title}>General</div>
              <div className={cl.item}>
                <InputColorSelector
                  value={formData.colors.backgroundColor}
                  label="Background color"
                  onChange={(value) => updateColor("backgroundColor", value)}
                />
                <InputColorSelector
                  value={formData.colors.color}
                  label="Text color"
                  onChange={(value) => updateColor("color", value)}
                />
                <InputColorSelector
                  value={formData.colors.borderColor}
                  label="Border color"
                  onChange={(value) => updateColor("borderColor", value)}
                />
              </div>
            </div>
            <div>
              <div className={cl.title}>Default button</div>
              <div className={cl.item}>
                <InputColorSelector
                  value={formData.colors.defaultButtonColor.background}
                  label="Background color"
                  onChange={(value) =>
                    updateButtonColor("defaultButtonColor", "background", value)
                  }
                />
                <InputColorSelector
                  value={formData.colors.defaultButtonColor.color}
                  label="Text color"
                  onChange={(value) =>
                    updateButtonColor("defaultButtonColor", "color", value)
                  }
                />
              </div>
            </div>
            <div>
              <div className={cl.title}>Delete button</div>
              <div className={cl.item}>
                <InputColorSelector
                  value={formData.colors.defaultButtonColor.background}
                  label="Background color"
                  onChange={(value) =>
                    updateButtonColor("deleteButtonColor", "background", value)
                  }
                />
                <InputColorSelector
                  value={formData.colors.deleteButtonColor.color}
                  label="Text color"
                  onChange={(value) =>
                    updateButtonColor("deleteButtonColor", "color", value)
                  }
                />
              </div>
            </div>

            <div>
              <div className={cl.title}>Edit button</div>
              <div className={cl.item}>
                <InputColorSelector
                  value={formData.colors.editButtonColor.background}
                  label="Background color"
                  onChange={(value) =>
                    updateButtonColor("editButtonColor", "background", value)
                  }
                />
                <InputColorSelector
                  value={formData.colors.editButtonColor.color}
                  label="Text color"
                  onChange={(value) =>
                    updateButtonColor("editButtonColor", "color", value)
                  }
                />
              </div>
            </div>
            <div>
              <div className={cl.title}>Cancel button</div>
              <div className={cl.item}>
                <InputColorSelector
                  value={formData.colors.cancelButtonColor.background}
                  label="Background color"
                  onChange={(value) =>
                    updateButtonColor("cancelButtonColor", "background", value)
                  }
                />
                <InputColorSelector
                  value={formData.colors.cancelButtonColor.color}
                  label="Text color"
                  onChange={(value) =>
                    updateButtonColor("cancelButtonColor", "color", value)
                  }
                />
              </div>
            </div>
            <div>
              <div className={cl.title}>Table</div>
              <div className={cl.item}>
                <InputColorSelector
                  value={formData.colors.tableColor.borderColor}
                  label="Border color"
                  onChange={(value) =>
                    setFormData({
                      ...formData,
                      colors: {
                        ...formData.colors,
                        tableColor: {...formData.colors.tableColor, borderColor: value.hex },
                      },
                    })
                  }
                />
              </div>
            </div>
          </div>
        </div>
        <div className={cl.button}>
          <Button theme="light" style={{ width: "auto" }} type="button" onClick={handleCloseCreateModal}>
            Cancel
          </Button>
          <Button style={{ width: "auto" }} type="submit">
            Save
          </Button>
        </div>
      </FormLayout>
    </div>
  );
};
