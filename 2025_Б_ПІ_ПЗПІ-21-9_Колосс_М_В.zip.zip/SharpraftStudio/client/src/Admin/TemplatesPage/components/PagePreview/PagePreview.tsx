import React, { useEffect, useState } from 'react'
import { Preview } from '../../../../ColorSelector/components/Preview/Preview';
import { ITemplateColor } from '../../../../interfaces/Templates/ITemplateColor';

export const PagePreview = () => {
    const [colors, setColors] = useState<ITemplateColor>();

    useEffect(() => {
        const channel = new BroadcastChannel('color-change');
        channel.onmessage = (event) => {
          if (event.data && event.data.color) {
            setColors(event.data.color);
          }
        };
    
        return () => {
          channel.close();
        };
      }, []); 

  return (
    <div>{colors && <Preview template={colors}></Preview>}</div>
  )
}
