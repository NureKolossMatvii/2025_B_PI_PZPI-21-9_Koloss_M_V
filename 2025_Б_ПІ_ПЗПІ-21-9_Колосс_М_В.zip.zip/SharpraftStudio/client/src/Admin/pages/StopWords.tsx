import React from 'react'
import { AdminNavbar } from '../components/AdminNavbar/AdminNavbar'
import { StopWordsPage } from '../StopWordsPage/StopWordsPage'

export const StopWords = () => {
  return (
    <AdminNavbar>
        <StopWordsPage></StopWordsPage>
    </AdminNavbar>
  )
}
