import React from 'react'
import { Navbar } from '../../components/Navbar/Navbar'
import { AdminNavbar } from '../components/AdminNavbar/AdminNavbar'
import { TemplatesPage } from '../TemplatesPage/TemplatesPage'

export const Templates = () => {
  return (
     <AdminNavbar>
        <TemplatesPage></TemplatesPage>
    </AdminNavbar>
  )
}
