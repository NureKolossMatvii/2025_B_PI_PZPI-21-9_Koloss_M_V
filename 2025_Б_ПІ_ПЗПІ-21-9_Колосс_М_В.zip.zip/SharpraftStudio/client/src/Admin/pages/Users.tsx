import React from 'react'
import { Navbar } from '../../components/Navbar/Navbar'
import { AdminNavbar } from '../components/AdminNavbar/AdminNavbar'
import { UsersPage } from '../UsersPage/UsersPage'

export const Users = () => {
  return (
      <AdminNavbar>
        <UsersPage />
    </AdminNavbar>
  )
}
