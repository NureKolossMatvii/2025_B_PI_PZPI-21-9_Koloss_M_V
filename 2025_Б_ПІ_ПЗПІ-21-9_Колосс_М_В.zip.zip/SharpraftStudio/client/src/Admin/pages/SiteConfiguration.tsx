import React from 'react'
import { Navbar } from '../../components/Navbar/Navbar'
import { AdminNavbar } from '../components/AdminNavbar/AdminNavbar'
import { SiteConfig } from '../SiteConfiguration/SiteConfig/SiteConfig'

export const SiteConfiguration = () => {
  return (
     <AdminNavbar>
        <SiteConfig />
    </AdminNavbar>
  )
}
