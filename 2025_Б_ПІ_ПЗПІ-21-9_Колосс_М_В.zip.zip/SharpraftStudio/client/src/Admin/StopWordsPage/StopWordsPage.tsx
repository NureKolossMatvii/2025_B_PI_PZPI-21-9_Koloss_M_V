import React from 'react'

export const StopWordsPage = () => {
  return (
    <div>StopWordsPage</div>
  )
}
