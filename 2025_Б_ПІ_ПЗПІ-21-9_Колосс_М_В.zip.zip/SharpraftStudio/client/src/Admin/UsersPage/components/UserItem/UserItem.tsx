import React from 'react'
import { IUser } from '../../../../interfaces/Models/IUser'
import cl from './UserItem.module.css';

interface IProps {
    item: IUser
}

export const UserItem = ({item}:IProps) => {
  return (
    <div className={cl.item}>
        <div>{item.userName}</div>
        <div>{item.roles.map((role) => role.name).join(", ")}</div>
    </div>
  )
}
