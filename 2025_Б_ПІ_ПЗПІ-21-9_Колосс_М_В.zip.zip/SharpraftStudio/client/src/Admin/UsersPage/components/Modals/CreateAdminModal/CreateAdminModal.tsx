import React from 'react'
import { Modal } from '../../../../../components/UI/Modal/Modal';
import { CreateAdminForm } from '../../Forms/CreateAdminForm';
import cl from './CreateAdminModal.module.css';

interface IProps {
    onHide: () => void;
    show: boolean;
    fetchItems: () => void
}


export const CreateAdminModal = ({onHide, show, fetchItems}:IProps) => {

  return (
    <Modal
    onClose={onHide}
    show={show}
    title="Create template"
  >
   <CreateAdminForm fetchItems={fetchItems} handleCloseCreateModal={onHide}></CreateAdminForm>
  </Modal>
  )
}