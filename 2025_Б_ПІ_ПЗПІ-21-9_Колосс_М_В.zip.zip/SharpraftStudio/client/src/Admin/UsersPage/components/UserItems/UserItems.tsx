import React from 'react'
import { Button } from '../../../../components/UI/Button/Button';
import { IUser } from '../../../../interfaces/Models/IUser'
import { CreateAdminModal } from '../Modals/CreateAdminModal/CreateAdminModal';
import { UserItem } from '../UserItem/UserItem';
import cl from './UserItems.module.css';

interface IProps {
    users: IUser[];
    handleOpenCreateModal: () => void
}

export const UserItems = ({users, handleOpenCreateModal}:IProps) => {
  return (
    <div className={cl.container}>
        <div className={cl.title}>Users</div>
        <Button style={{width: "auto"}} type='button' onClick={handleOpenCreateModal}>Create admin</Button>
        <div className={cl.items}>
            <div className={cl.item}>
                <div>Name</div>
                <div>Roles</div>
            </div>
            {users.map((item) =>
                <UserItem item={item} />
            )}
        </div>
    </div>
  )
}
