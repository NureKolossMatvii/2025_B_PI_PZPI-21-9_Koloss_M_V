import React, { useState } from "react";
import { FormLayout } from "../../../../components/FormLayout/FormLayout";
import { Button } from "../../../../components/UI/Button/Button";
import { DefaultInput } from "../../../../components/UI/Input/DefaultInput";
import { createAdmin } from "../../../../http/userApi";
import { IAdminCreateDto } from "../../../../interfaces/Dto/IAdminCreateDto";
import cl from './CreateAdminForm.module.css';

interface IProps {
  fetchItems: () => void;
  handleCloseCreateModal: () => void;
}

export const CreateAdminForm = ({ fetchItems, handleCloseCreateModal }: IProps) => {
  const [formData, setFormData] = useState<IAdminCreateDto>({userName: ""});

  const create = async () => {
    await createAdmin(formData)
      .then(() => {
        fetchItems();
        handleCloseCreateModal();
      })
      .catch((error) => console.error(error));
  };

  return (
    <div>
      <FormLayout onSubmit={create}>
        <div className={cl.form}>
          <DefaultInput
            label="User name"
            inputType="text"
            setValue={(value) => setFormData({ ...formData, userName: value })}
          ></DefaultInput>
        </div>
        <div className={cl.button}>
          <Button style={{ width: "auto" }} type="submit">
            Create
          </Button>
        </div>
      </FormLayout>
    </div>
  );
};
