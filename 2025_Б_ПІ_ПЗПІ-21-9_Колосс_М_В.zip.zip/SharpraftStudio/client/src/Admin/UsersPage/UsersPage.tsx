import React, { useEffect, useState } from 'react'
import { Loader } from '../../components/Loader/Loader';
import { getUsers } from '../../http/userApi';
import { IUser } from '../../interfaces/Models/IUser'
import { AdminNavbar } from '../components/AdminNavbar/AdminNavbar';
import { CreateAdminModal } from './components/Modals/CreateAdminModal/CreateAdminModal';
import { UserItems } from './components/UserItems/UserItems';

export const UsersPage = () => {
    const [users, setUsers] = useState<IUser[]>([]);
    const [loading, setLoading] = useState<boolean>(false);
    const [createModal, setCreateModal] = useState<boolean>(false);

    const handleOpenCreateModal = () => setCreateModal(true);
    const handleCloseCreateModal = () => setCreateModal(false);

    const fetchUsers = async () => {
        setLoading(true);
        await getUsers()
        .then((data) => setUsers(data))
        .finally(() => setLoading(false));
    }

    useEffect(() => {
        fetchUsers();
    }, [])

  return (
    <div>
        <CreateAdminModal onHide={handleCloseCreateModal} show={createModal} fetchItems={fetchUsers}></CreateAdminModal>
        <Loader loading={loading}/>
        <UserItems users={users} handleOpenCreateModal={handleOpenCreateModal}/>
    </div>
  )
}
