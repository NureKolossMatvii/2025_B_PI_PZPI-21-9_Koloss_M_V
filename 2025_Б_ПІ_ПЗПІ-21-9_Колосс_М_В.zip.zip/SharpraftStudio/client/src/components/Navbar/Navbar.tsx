import React, { ReactNode, useContext, ReactElement } from "react";
import cl from "./Navbar.module.css";
import records from "../../records.json";
import { NavLink, useNavigate } from "react-router-dom";
import { ContextMenuContext, UserSessionContext } from "../..";
import { ADMIN_ROLE, CREATOR_ROLE, tokenLocalStorageKey } from "../../consts";
import { LOGIN_ROUTE, REGISTRATION_ROUTE, PROJECTS_VIEWER_ROUTE, MAIN_ROUTE, ADMIN_USERS_ROUTE } from "../../routesConsts";
import { ContextMenu } from "../UI/ContextMenu/ContextMenu";
import { Button } from "../UI/Button/Button";
import { observer } from "mobx-react-lite";

interface IProps {
  children: ReactNode;
}

interface INavigationItem {
  link: string;
  node: ReactElement;
  roles?: string[];
}

const navigationItems: INavigationItem[] = [];

const nonAuthNavigationItems: INavigationItem[] = [
  { link: LOGIN_ROUTE, node: <Button theme="light" type="button">Sign in</Button> },
  { link: REGISTRATION_ROUTE, node: <Button type="button">Sign up</Button> },
];

const authNavigationItems: INavigationItem[] = [
  { link: PROJECTS_VIEWER_ROUTE, node: <>My projects</>, roles: [ADMIN_ROLE, CREATOR_ROLE] },
  { link: ADMIN_USERS_ROUTE, node: <Button theme="light" type="button">Admin panel</Button>, roles: [ADMIN_ROLE] },
];

export const Navbar = observer(({ children }: IProps) => {
  const { isAuthorized, user, logout } = useContext(UserSessionContext)!;
  const {hideMenu, position, isVisible, contextChildren} = useContext(ContextMenuContext)!;

  return (
    <div className={cl.wrapper}>
      {isVisible && (
          <ContextMenu position={position} onHide={hideMenu}>{contextChildren}</ContextMenu>
        )}
      <header className={cl.header}>
        <div className={cl.headerContent}>
          <NavLink to={MAIN_ROUTE} className={cl.logotype}>
            <img src={records.redLogotype} alt="Logotype" />
          </NavLink>
          <nav className={cl.navigation}>
            {navigationItems.map(({ link, node }) => (
              <NavLink key={link} className={cl.navItem} to={link}>
                {node}
              </NavLink>
            ))}
            {isAuthorized
              ? <>
              {authNavigationItems.map(
                  ({ link, node, roles }) =>
                    roles?.some((role) => user?.role.includes(role)) && (
                      <NavLink key={link} className={cl.navItem} to={link}>
                        {node}
                      </NavLink>
                    )
                )}
                <Button style={{width: "auto"}} type="button" onClick={logout}>Logout</Button>
              </>
              : nonAuthNavigationItems.map(({ link, node }) => (
                  <NavLink key={link} className={cl.navItem} to={link}>
                    {node}
                  </NavLink>
                ))}
          </nav>
        </div>
      </header>
      <main>{children}</main>
    </div>
  );
});