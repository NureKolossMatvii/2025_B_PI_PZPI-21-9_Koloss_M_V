import React, { CSSProperties, MouseEvent, ReactNode } from 'react'
import cl from './Button.module.css';

interface IProps {
    children: ReactNode,
    type: ButtonType
    onClick?: (e: MouseEvent) => void
    style?: CSSProperties,
    disabled?:boolean,
    theme?: ButtonTheme
}

type ButtonTheme = "dark" | "light" | "red";

type ButtonType = "submit" | "button";

export const Button = ({children, type, onClick, style, disabled = false, theme = "dark"}: IProps) => {

  const className = () => {
    switch (theme) {
      case "dark":
        return cl.dark;
      case "light":
        return cl.light
      case "red":
        return cl.red
    }
  }

  const handleClick = (event: MouseEvent) => {
    if(!disabled && onClick) {
      onClick(event)
    }
  }

  return (
    <button disabled={disabled} className={[cl.button, className()].join(" ")} style={style} onClick={handleClick} type={type}>{children}</button>
  )
}
