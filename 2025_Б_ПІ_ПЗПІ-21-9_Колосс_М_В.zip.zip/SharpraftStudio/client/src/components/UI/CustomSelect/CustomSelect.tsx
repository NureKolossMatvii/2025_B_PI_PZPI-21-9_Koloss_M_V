import React from "react";
import { ISelect } from "../../../interfaces/ISelect";
import cl from "./CustomSelect.module.css";

interface IProps {
  items: ISelect[];
  onChange: (value: string) => void,
  value?:any,
  disabled?: boolean
}

export const CustomSelect = ({ items, onChange, value, disabled = false}: IProps) => {
  return (
    <select disabled={disabled} className={cl.select} value={value} onChange={(e) => !disabled && onChange(e.target.value)}>
      {items.map((option) => (
        <option key={option.value} value={option.value}>{option.label}</option>
      ))}
    </select>
  );
};
