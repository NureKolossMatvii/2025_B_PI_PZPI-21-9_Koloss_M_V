import React from "react";
import { InputType } from "./Input";
import cl from "./Input.module.css";

interface IProps {
  inputType: InputType;
  label?: string,
  value?: string,
  setValue: (val: string) => void,
  disabled?: boolean
  onEnter?: () => void
}

export const DefaultInput = ({inputType, label, value, setValue, onEnter, disabled = false}: IProps) => {
    const onChange = (val: string) => {
      if (!disabled) {
        setValue(val);
      }
    }

    const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
      if (event.key === 'Enter' && onEnter) {
        onEnter();
      }
    }

  return (
    <div className={cl.content}>
      {label && <label>{label}</label>}
      <input type={inputType} disabled={disabled} defaultValue={value} onKeyDown={handleKeyDown} onChange={(e) => onChange(e.target.value)}></input>
    </div>
  );
};
