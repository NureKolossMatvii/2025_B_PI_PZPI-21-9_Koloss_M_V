import React, { useState } from 'react'
import cl from './CustomCheckbox.module.css';

interface IProps {
    label: string,
    styles?: object,
    onChange: (value: boolean) => void,
    checked?: boolean,
    size?:number
    disabled?: boolean,
}

export const CustomCheckbox = ({label, styles, onChange, checked, disabled = false, size = 25}: IProps) => {
    const onHandleChecked = (e: any) => {
        if (!disabled) {
          onChange(e.target.checked)
        }
    }

  return (
    <label className={[cl.container, disabled && cl.disabled].join(" ")} style={{...styles, height: size, paddingLeft: size + 10}}><div className={cl.label}>{label}</div>
  <input checked={checked} disabled={disabled} type="checkbox" onChange={onHandleChecked}/>
  <span className={cl.checkmark} style={{width: size, height: size, borderRadius: size / 5}}></span>
</label>
  )
}