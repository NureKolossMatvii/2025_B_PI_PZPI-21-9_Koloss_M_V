import React, { useState } from 'react'
import { SketchPicker } from 'react-color';
import cl from './InputColorSelector.module.css';
import { IColor } from '../../../interfaces/IColor';
import { IPosition } from '../../../interfaces/IPosition';

interface IProps {
    onChange: (value: IColor) => void
    label?: string,
    value?: string
}

export const InputColorSelector = ({ onChange, label, value}: IProps) => {
    const [color, setColor] = useState<IColor>({hex: value ?? "#000", rgb: {r: 0, g: 0, b: 0, a: 1}});
    const [position, setPosition] = useState<IPosition>({x: 0, y: 0});
    const [openMenu, setOpenMenu] = useState<boolean>(false)

    const handleColorChange = (value: any) => {
        setColor(value)
        onChange(value);
    }

    const handleOpenMenu = (event: React.MouseEvent<HTMLButtonElement>) => {
      event.preventDefault();
      setPosition({x: event.clientX - 10, y: event.clientY - 10})
      setOpenMenu(true)
    }

    const handleCloseMenu = () => {
      setOpenMenu(false)
    }

    const onHide = () => {

    }

  return (
      <div className={cl.input}>
        <button style={{backgroundColor: color?.hex}} className={cl.button} onClick={handleOpenMenu}></button>
        {label && <div className={cl.label}>{label}</div>}
        {openMenu && 
        <div className={cl.menuContent} onMouseLeave={handleCloseMenu} style={{top: position.y, left: position.x}}>
          <SketchPicker color={color} onChange={handleColorChange}/>
        </div>
        }
      </div>
  )
}
