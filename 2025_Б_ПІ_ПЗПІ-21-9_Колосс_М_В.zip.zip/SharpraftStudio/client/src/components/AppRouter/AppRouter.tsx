import { observer } from "mobx-react-lite";
import React, { useContext } from "react";
import { Route, Routes } from "react-router-dom";
import { UserSessionContext } from "../..";
import { PagePreview } from "../../Admin/TemplatesPage/components/PagePreview/PagePreview";
import { ADMIN_ROLE } from "../../consts";
import { authRoutes, publicRoutes } from "../../routes";
import { ADMIN_PAGE_PREVIEW } from "../../routesConsts";

export const AppRouter = observer(() => {
  const { isAuthorized, user } = useContext(UserSessionContext)!;

  const checkRole = (roles: string[], userRoles?: string[]) => {
    return roles.some((role) => userRoles?.includes(role));
  };

  return (
    <Routes>
      {/* Authorized Routes */}
      {isAuthorized &&
        authRoutes.map(({ path, Component, roles }) => {
          return checkRole(roles!, user?.role) ? (
            <Route path={path} key={path} element={<Component />} />
          ) : null;
        })}

      {/* Public Routes */}
      {publicRoutes.map(({ path, Component }) => (
        <Route path={path} key={path} element={<Component />} />
      ))}
    </Routes>
  );
});
