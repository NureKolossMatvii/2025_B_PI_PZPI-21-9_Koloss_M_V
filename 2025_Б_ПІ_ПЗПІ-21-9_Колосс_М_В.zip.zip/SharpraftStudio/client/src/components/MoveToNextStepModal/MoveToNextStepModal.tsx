import React, { ReactElement } from 'react'
import { Button } from '../UI/Button/Button'
import { Modal } from '../UI/Modal/Modal'
import cl from './MoveToNextStepModal.module.css';

interface IProps {
    show: boolean,
    onClose: () => void,
    move: () => void
    children?: ReactElement,
    disabled?:boolean
}

export const MoveToNextStepModal = ({ show, onClose, move, children, disabled }: IProps) => {
  return (
    <Modal
    title="Move to next step"
    show={show}
    onClose={onClose}
  >
    <div>
      {children ?? 
      <>
        <div className={cl.nextStepTitle}>Do you really want to move to the next step?</div>
        <div className={cl.nextStepTitle}>Attention! It will be impossible to go to the previous step!</div>
      </>
      }
      <div className={cl.nextStep_buttons}>
        <Button theme='light' type="button" onClick={onClose}>Cancel</Button>
        <Button type="button" onClick={move} disabled={disabled}>Move</Button>
      </div>
    </div>
  </Modal>
  )
}