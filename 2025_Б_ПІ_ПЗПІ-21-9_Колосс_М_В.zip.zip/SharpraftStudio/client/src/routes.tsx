import { ComponentType } from "react";
import { SiteConfiguration } from "./Admin/pages/SiteConfiguration";
import { StopWords } from "./Admin/pages/StopWords";
import { Templates } from "./Admin/pages/Templates";
import { Users } from "./Admin/pages/Users";
import { PagePreview } from "./Admin/TemplatesPage/components/PagePreview/PagePreview";
import { Login } from "./Auth/pages/Login/Login";
import { Registration } from "./Auth/pages/Registration/Registration";
import { ADMIN_ROLE, CREATOR_ROLE } from "./consts";
import { MainPage } from "./MainPage/MainPage";
import { Project } from "./Project/pages/Project/Project";
import { ProjectViewer } from "./ProjectView/pages/ProjectViewer/ProjectViewer";
import { LOGIN_ROUTE, REGISTRATION_ROUTE, PROJECTS_VIEWER_ROUTE, PROJECT_CREATOR_ROUTE, ADMIN_USERS_ROUTE, ADMIN_TEMPLATES_ROUTE, ADMIN_PAGE_PREVIEW, ADMIN_PAGE_SITE_CONFIGURATION, MAIN_ROUTE, NO_ROUTE, ADMIN_PAGE_SITE_STOP_WORDS } from "./routesConsts";

interface RouteData {
    path: string,
    Component: ComponentType<{}>,
    roles?: string[]
}

export const authRoutes: RouteData[] = [
    { path: PROJECT_CREATOR_ROUTE + `/:projectId`, Component: Project, roles: [CREATOR_ROLE]},
    { path: PROJECTS_VIEWER_ROUTE, Component: ProjectViewer, roles: [CREATOR_ROLE]},
    { path: ADMIN_USERS_ROUTE, Component: Users, roles: [ADMIN_ROLE]},
    { path: ADMIN_TEMPLATES_ROUTE, Component: Templates, roles: [ADMIN_ROLE]},
    { path: ADMIN_PAGE_PREVIEW, Component: PagePreview, roles: [ADMIN_ROLE]},
    { path: ADMIN_PAGE_SITE_CONFIGURATION, Component: SiteConfiguration, roles: [ADMIN_ROLE]},
    { path: ADMIN_PAGE_SITE_STOP_WORDS, Component: StopWords, roles: [ADMIN_ROLE]},
];

export const publicRoutes: RouteData[] = [
    { path: REGISTRATION_ROUTE, Component: Registration},
    { path: LOGIN_ROUTE, Component: Login},
    { path: NO_ROUTE, Component: MainPage},
    { path: MAIN_ROUTE, Component: MainPage},
];