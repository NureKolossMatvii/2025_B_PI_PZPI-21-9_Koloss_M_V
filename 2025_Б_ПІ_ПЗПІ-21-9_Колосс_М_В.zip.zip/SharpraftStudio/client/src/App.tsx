import React, { useEffect, useContext } from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { ClientTextInfoContext, ContextMenuContext, ProjectContext, UserSessionContext } from ".";
import { PagePreview } from "./Admin/TemplatesPage/components/PagePreview/PagePreview";
import { AppRouter } from "./components/AppRouter/AppRouter";
import { Navbar } from "./components/Navbar/Navbar";
import { ContextMenu } from "./components/UI/ContextMenu/ContextMenu";
import { useClientTextInfo } from "./hooks/useClientTextInfo";
import { useContextMenu } from "./hooks/useContextMenu";
import { useDiagram } from "./hooks/useDiagram";
import { useProject } from "./hooks/useProject";
import { useUserAuthorization } from "./hooks/useUserAuthorization";
import { ADMIN_PAGE_PREVIEW } from "./routesConsts";
import "./styles/App.css";

export const App = () => {
  const userSessionValue = useUserAuthorization();
  const projectValue = useProject();
  const contextMenuValue = useContextMenu();
  const clientTextInfo = useClientTextInfo()

  return (
    <ClientTextInfoContext.Provider value={clientTextInfo}>
      <ContextMenuContext.Provider value={contextMenuValue}>
        <UserSessionContext.Provider value={userSessionValue}>
          <ProjectContext.Provider value={projectValue}>
            <BrowserRouter>
              <AppRouter />
            </BrowserRouter>
          </ProjectContext.Provider>
        </UserSessionContext.Provider>
      </ContextMenuContext.Provider>
    </ClientTextInfoContext.Provider>
  );
};
