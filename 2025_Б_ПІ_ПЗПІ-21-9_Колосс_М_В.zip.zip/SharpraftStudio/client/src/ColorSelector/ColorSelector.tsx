import React, { useContext, useState, useEffect } from "react";
import { ProjectContext } from "..";
import { Loader } from "../components/Loader/Loader";
import { MoveToNextStepModal } from "../components/MoveToNextStepModal/MoveToNextStepModal";
import { Button } from "../components/UI/Button/Button";
import { Input } from "../components/UI/Input/Input";
import { moveProjectToNextStep } from "../http/projectApi";
import { saveColorTemplate } from "../http/projectConfigurationApi";
import { getTemplates } from "../http/templateApi";
import { ITemplate } from "../interfaces/Templates/ITemplate";
import cl from "./ColorSelector.module.css";
import { Preview } from "./components/Preview/Preview";

interface IProps {
  disabled?: boolean
}

export const ColorSelector = ({disabled}: IProps) => {
  const [currentTemplate, setCurrentTemplate] = useState<ITemplate>();
  const { project, fetchProject } = useContext(ProjectContext)!;
  const [templates, setTemplates] = useState<ITemplate[]>([]);

  const [nextStepModal, setNextStepModal] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const handleOpenNextStepModal = () => setNextStepModal(true);

  const handleCloseNextStepModal = () => setNextStepModal(false);

  const handleSave = async () => {
    if (project && currentTemplate) {
      setLoading(true);
      await saveColorTemplate(project?.projectConfigurationId, currentTemplate?.colorTemplateId)
      .finally(() => setLoading(false));
    }
  }

  const fetchProjectData = async () => {
    if (project) {
      setLoading(true);
      await fetchProject(project?.projectConfigurationId).finally(() => setLoading(false));
    }
  }

  const moveToNextStep = async () => {
    if (project) {
      const move = async () => {
        setLoading(true);
        await moveProjectToNextStep(project.projectConfigurationId)
        .then(() => fetchProjectData())
        .finally(() => setLoading(false));
      }

      await handleSave().then(() => move())
    }
  };

  const fetchTemplates = async () => {
    setLoading(true)
    await getTemplates()
    .then((data) => setTemplates(data))
    .finally(() => setLoading(false))
  }

  useEffect(() => {
    fetchTemplates();
  }, [])

  useEffect(() => {
    if(templates.length && project) {
      setCurrentTemplate(templates.find((template) => template.colorTemplateId === project?.colorTemplateId) ?? templates[0])
    }
  }, [templates])

  return (
   <>
   <Loader loading={loading} />
   <div className={cl.container}>
    <MoveToNextStepModal show={nextStepModal} onClose={handleCloseNextStepModal} move={moveToNextStep}></MoveToNextStepModal>
   <div className={cl.buttons}>
      <Button type="button" onClick={handleSave} disabled={disabled}>Save colors</Button>
      <Button type="button" onClick={handleOpenNextStepModal} disabled={disabled}>Move to next step</Button>
   </div>
   
    <div className={cl.title}>Templates</div>
     <div className={cl.blocks}>
      {templates.map((template) => (
        <div className={[cl.block, template.colorTemplateId === currentTemplate?.colorTemplateId && cl.active].join(" ")} onClick={disabled ? undefined : () => setCurrentTemplate(template)}>
          <span>{template.title}</span>
        </div>
      ))}
    </div>
    <div className={cl.title}>Preview</div>
    {currentTemplate && <div className={cl.preview}><Preview template={currentTemplate.colors}></Preview></div>}
   </div>
   </>
  );
};
