import React, { useEffect } from 'react'
import { Controller, useForm } from 'react-hook-form';
import { IPreviewProduct } from '../Preview/Preview';
import { IPreviewCreateData } from '../PreviewCreateModal/PreviewCreateModal';
import {Modal, Button} from 'react-bootstrap';
import { ITemplateColor } from '../../../interfaces/Templates/ITemplateColor';

export interface IPreviewEditData extends IPreviewCreateData {
    id: number
}

interface IProps {
    show: boolean,
    onHide: () => void,
    item?: IPreviewProduct,
    template: ITemplateColor
}

export const PreviewEditModal = ({ show, onHide, item, template }: IProps) => {
    const {
        control,
        handleSubmit,
        reset,
        formState: { errors },
      } = useForm<IPreviewEditData>();
    
      useEffect(() => {
        if (item) {
          reset({
            ...item
          });
        }
      }, [item, reset]);
          
      const onSubmit = async (data: IPreviewEditData) => {
       onHide()
      };


    return (
        <Modal show={show} onHide={onHide}>
        <form onSubmit={handleSubmit(onSubmit)}>
          <Modal.Header style={{background: template.backgroundColor, borderColor: template.borderColor}}>
            <Modal.Title style={{color: template.color}}>Modal title</Modal.Title>
          </Modal.Header>
          <Modal.Body style={{background: template.backgroundColor}}>
            <div
              asp-validation-summary="ModelOnly"
              className="text-danger"
            ></div>
             <div className="form-group">
              <label className="control-label" style={{color: template.color}}>Name</label>
              <Controller
                control={control}
                name={"name"}
                rules={{
                  required: "enter name",
                }}
                render={({ field }) => (
                  <input className="form-control" {...field} style={{background: template.backgroundColor, color: template.color, borderColor: template.borderColor}}/>
                )}
              ></Controller>
              <p style={{ color: "red" }}>{errors.name?.message}</p>
            </div>
            <div className="form-group">
              <label className="control-label" style={{color: template.color}}>Description</label>
              <Controller
                control={control}
                name={"description"}
                rules={{
                  required: "enter description",
                }}
                render={({ field }) => (
                  <input className="form-control" {...field} style={{background: template.backgroundColor, color: template.color, borderColor: template.borderColor}} />
                )}
              ></Controller>
              <p style={{ color: "red" }}>{errors.description?.message}</p>
            </div>
            <div className="form-group">
              <label className="control-label" style={{color: template.color}}>Cost</label>
              <Controller
                control={control}
                name={"cost"}
                rules={{
                  required: "enter cost",
                }}
                render={({ field }) => (
                  <input className="form-control" type={"number"} {...field} style={{background: template.backgroundColor, color: template.color, borderColor: template.borderColor}} />
                )}
              ></Controller>
              <p style={{ color: "red" }}>{errors.cost?.message}</p>
            </div>
            <div className="form-group">
              <label className="control-label" style={{color: template.color}}>Weight</label>
              <Controller
                control={control}
                name={"weight"}
                rules={{
                  required: "enter weight",
                }}
                render={({ field }) => (
                  <input className="form-control" type={"number"} {...field} style={{background: template.backgroundColor, color: template.color, borderColor: template.borderColor}} />
                )}
              ></Controller>
              <p style={{ color: "red" }}>{errors.weight?.message}</p>
            </div>
            <div className="form-group">
              <label className="control-label" style={{color: template.color}}>Height</label>
              <Controller
                control={control}
                name={"height"}
                rules={{
                  required: "enter height",
                }}
                render={({ field }) => (
                  <input className="form-control" type={"number"} {...field} style={{background: template.backgroundColor, color: template.color, borderColor: template.borderColor}} />
                )}
              ></Controller>
              <p style={{ color: "red" }}>{errors.height?.message}</p>
            </div>
            <div className="form-group">
              <label className="control-label" style={{color: template.color}}>Width</label>
              <Controller
                control={control}
                name={"width"}
                rules={{
                  required: "enter width",
                }}
                render={({ field }) => (
                  <input className="form-control" type={"number"} {...field} style={{background: template.backgroundColor, color: template.color, borderColor: template.borderColor}} />
                )}
              ></Controller>
              <p style={{ color: "red" }}>{errors.width?.message}</p>
            </div>
          </Modal.Body>
          <Modal.Footer style={{background: template.backgroundColor, borderColor: template.borderColor}}>
            <Button style={{...template.cancelButtonColor, borderColor: template.cancelButtonColor.background}} onClick={onHide}>
              Close
            </Button>
            <Button style={{...template.defaultButtonColor, borderColor: template.defaultButtonColor.background}} type="submit">
              Save
            </Button>
          </Modal.Footer>
        </form>
      </Modal>
      )
}
