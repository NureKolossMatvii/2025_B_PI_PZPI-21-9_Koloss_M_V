import React, { useState } from "react";
import "./Preview.css";
import { Button } from "react-bootstrap";
import "bootstrap/dist/css/bootstrap.css";
import { PreviewCreateModal } from "../PreviewCreateModal/PreviewCreateModal";
import { PreviewEditModal } from "../PreviewEditModal/PreviewEditModal";
import { ITemplateColor } from "../../../interfaces/Templates/ITemplateColor";

export interface IPreviewProduct {
  id: number;
  name: string;
  description: string;
  cost: number;
  weight: number;
  height: number;
  width: number;
}

interface IProps {
    template: ITemplateColor
}

export const Preview = ({ template }: IProps) => {
    const [createModal, setCreateModal] = useState<boolean>(false);
    const handleShowCreateModal = () => setCreateModal(true);
    const handleCloseCreateModal = () => setCreateModal(false);
    const handleShowEditModal = (data: IPreviewProduct) => {
        setEditableData(data);
        setEditModal(true);
      }
    
      const handleCloseEditModal = () => {
        setEditModal(false);
      }
    const [editModal, setEditModal] = useState<boolean>(false);
    const [editableData, setEditableData] = useState<IPreviewProduct>();

  const products: IPreviewProduct[] = [
    {
      id: 1,
      name: "IPhone 12 Pro MAX",
      description: "Phone",
      cost: 1234,
      weight: 100,
      width: 50,
      height: 50,
    },
    {
      id: 2,
      name: "IPhone 12 Pro MAX",
      description: "Phone",
      cost: 1234,
      weight: 100,
      width: 50,
      height: 50,
    },
    {
      id: 3,
      name: "IPhone 12 Pro MAX",
      description: "Phone",
      cost: 1234,
      weight: 100,
      width: 50,
      height: 50,
    },
    {
      id: 4,
      name: "IPhone 12 Pro MAX",
      description: "Phone",
      cost: 1234,
      weight: 100,
      width: 50,
      height: 50,
    },
    {
      id: 5,
      name: "IPhone 12 Pro MAX",
      description: "Phone",
      cost: 1234,
      weight: 100,
      width: 50,
      height: 50,
    },
    {
      id: 6,
      name: "IPhone 12 Pro MAX",
      description: "Phone",
      cost: 1234,
      weight: 100,
      width: 50,
      height: 50,
    },
  ];

  return (
    <div style={{ background: template.backgroundColor }}>
        <PreviewCreateModal
          onHide={handleCloseCreateModal}
          show={createModal}
          template={template}
        ></PreviewCreateModal>
        <PreviewEditModal
          item={editableData}
          show={editModal}
          template={template}
          onHide={handleCloseEditModal}
        ></PreviewEditModal>
      <noscript>You need to enable JavaScript to run this app.</noscript>
      <div>
        <header style={{background: template.backgroundColor}}>
          <nav className="navbar navbar-expand-sm navbar-toggleable-sm  mb-3" style={{borderBottom: "1px solid", borderColor: template.borderColor}}>
            <div className="container">
              <a className="navbar-brand" style={{color: template.color}}>Market</a>
              <button
                className="navbar-toggler"
                type="button"
                data-toggle="collapse"
                data-target=".navbar-collapse"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation"
              >
                <span className="navbar-toggler-icon"></span>
              </button>
              <div className="navbar-collapse collapse d-sm-inline-flex justify-content-between">
                <ul className="navbar-nav flex-grow-1">
                  <li className="nav-item">
                    <a className="nav-link" style={{color: template.color}}>Link 1</a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" style={{color: template.color}}>Link 2</a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" style={{color: template.color}}>Link 3</a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" style={{color: template.color}}>Link 4</a>
                  </li>
                  <li className="nav-item">
                    <a className="nav-link" style={{color: template.color}}>Link 5</a>
                  </li>
                </ul>
              </div>
            </div>
          </nav>
        </header>
        <div className="container">
          <main role="main" className="pb-3">
            <div>
              <h1 style={{color: template.color}}>Product</h1>
            <div asp-action="Index" >
                <div className="input-group mb-3">
                    <div className="input-group-prepend">
                        <span className="input-group-text" id="inputGroup-sizing-default" style={{...template.defaultButtonColor, borderColor: template.defaultButtonColor.background}}>Product name</span>
                    </div>
                    <input type="text" className="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" style={{background: template.backgroundColor, color: template.color, borderColor: template.borderColor}}/>
                </div>

                <div className="input-group mb-3">
                    <div className="input-group-prepend ml-3">
                        <span className="input-group-text" id="inputGroup-sizing-default" style={{...template.defaultButtonColor, borderColor: template.defaultButtonColor.background}}>Cost from</span>
                    </div>
                    <input type="text" className="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" style={{background: template.backgroundColor, color: template.color, borderColor: template.borderColor}}/>
                    <div className="input-group-prepend ml-3">
                        <span className="input-group-text" id="inputGroup-sizing-default" style={{...template.defaultButtonColor, borderColor: template.defaultButtonColor.background}}>Cost to</span>
                    </div>
                    <input type="text" className="form-control" aria-label="Default" aria-describedby="inputGroup-sizing-default" style={{background: template.backgroundColor, color: template.color, borderColor: template.borderColor}}/>
                </div>
                <div className="input-group mb-3">
                    <div className="input-group-prepend ml-3">
                        <span className="input-group-text" id="inputGroup-sizing-default" style={{...template.defaultButtonColor, borderColor: template.defaultButtonColor.background}}>Sort</span>
                    </div>
                    <select id="inputGroupSelect01" style={{background: template.backgroundColor, color: template.color, borderColor: template.borderColor}}>
                        <option value="">Name Asc</option>
                        <option value="">Name Desc</option>
                        <option value="">Cost Asc</option>
                        <option value="">Cost Desc</option>
                    </select>
                </div>

                <div className="input-group mb-3 d-flex justify-content-end">
                    <input style={{...template.defaultButtonColor, borderColor: template.defaultButtonColor.background}} type="submit" value="Search" className="btn btn-primary" />
                </div>
            </div>
              <p>
                <Button style={{...template.defaultButtonColor, borderColor: template.defaultButtonColor.background}} onClick={handleShowCreateModal}>Create New</Button>
              </p>
              <table className="customTable" style={{background: template.backgroundColor}}>
                <thead style={{borderBottom: `1px solid ${template.tableColor.borderColor}`}}>
                  <tr style={{color: template.color}}>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Cost</th>
                    <th>Weight</th>
                    <th>Height</th>
                    <th>Width</th>
                    <th></th>
                  </tr>
                </thead>
                <tbody style={{color: template.color}}>
                  {products.map((product) => (
                    <tr key={product.id} style={{borderBottom: `1px solid ${template.tableColor.borderColor}`}}>
                      <td>{product.id}</td>
                      <td>{product.name}</td>
                      <td>{product.description}</td>
                      <td>{product.cost}</td>
                      <td>{product.weight}</td>
                      <td>{product.height}</td>
                      <td>{product.width}</td>
                      <td className="d-flex gap-3">
                        <button className="btn" style={{...template.editButtonColor}} onClick={() => handleShowEditModal(product)}>Edit</button>
                        <button className="btn" style={{...template.deleteButtonColor}}>Delete</button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
};
