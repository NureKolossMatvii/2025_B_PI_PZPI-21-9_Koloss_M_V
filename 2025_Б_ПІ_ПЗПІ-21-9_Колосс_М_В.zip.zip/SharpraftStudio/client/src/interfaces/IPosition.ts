export interface IPosition {
    x: number,
    y: number,
}