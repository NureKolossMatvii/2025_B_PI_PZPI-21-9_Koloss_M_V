export interface IUMLOperationsBaseDto {
    removeEnabled: boolean,
    nameChangeEnabled: boolean
}