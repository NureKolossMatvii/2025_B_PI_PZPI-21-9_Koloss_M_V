export interface IUpdateProjectStepDto {
    projectId: string,
    step: number,
}