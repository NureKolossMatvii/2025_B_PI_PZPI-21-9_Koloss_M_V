import { IUMLOperationsBaseDto } from "./IUMLOperationsBaseDto";

export interface IUMLTableOperationsDto extends IUMLOperationsBaseDto {
    columnCreationAvailable: boolean,
}