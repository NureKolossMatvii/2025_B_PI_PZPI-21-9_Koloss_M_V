export interface UMLTableConnectionDto {
    tableConnectionId: string,
    leftTableId: string,
    rightTableId: string,
    foreignKeyColumnId: string,
    connectionType: number
}