export interface IProjectCreationDto {
    projectConfigurationId: string,
    name: string,
}