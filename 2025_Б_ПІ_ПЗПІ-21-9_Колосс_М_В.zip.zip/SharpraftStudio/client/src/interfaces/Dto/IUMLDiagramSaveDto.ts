import { UMLTableConnectionDto } from "./UMLTableConnectionDto";
import { UMLTableDto } from "./UMLTableDto";

export interface IUMLDiagramSaveDto {
    projectId: string,
    tables: UMLTableDto[],
    connections: UMLTableConnectionDto[]
}