export interface IAdminCreateDto {
    userName: string
}