import { IDimension } from "../IDimension";
import { IPosition } from "../IPosition";
import { UMLTableColumn } from "../Models/UMLTableColumn";
import { IUMLTableOperationsDto } from "./IUMLTableOperationsDto";

export interface UMLTableDto {
    tableId: string,
    name: string,
    position: IPosition,
    operations: IUMLTableOperationsDto,
    columns: UMLTableColumn[],
    labelColumnTableId: string
}