export interface ITemplateButton {
    background: string,
    color: string
  }