export interface ITemplateTable {
    borderColor: string
  }