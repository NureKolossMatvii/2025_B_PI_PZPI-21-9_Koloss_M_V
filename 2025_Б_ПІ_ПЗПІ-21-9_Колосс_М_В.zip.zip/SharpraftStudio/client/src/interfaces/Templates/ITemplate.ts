import { ITemplateColor } from "./ITemplateColor";

export interface ITemplate {
    colorTemplateId: string,
    colors: ITemplateColor,
    title: string
  }