import { ITemplateButton } from "./ITemplateButton"
import { ITemplateTable } from "./ITemplateTable"

export interface ITemplateColor {
    backgroundColor: string,
    color: string,
    borderColor: string,
    defaultButtonColor: ITemplateButton
    deleteButtonColor: ITemplateButton
    editButtonColor: ITemplateButton
    cancelButtonColor: ITemplateButton
    tableColor: ITemplateTable
  }