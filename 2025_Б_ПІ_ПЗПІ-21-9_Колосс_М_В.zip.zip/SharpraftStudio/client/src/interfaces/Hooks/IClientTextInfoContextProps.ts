import { ClientTextInfoKey } from "../../types/ClientTextInfoKey";
import { IClientTextInfoItem } from "../Models/IClientTextInfoItem";

export interface IClientTextInfoContextProps {
    clientTextInfo: IClientTextInfoItem[];
    getClientTextInfoByKey: (key: ClientTextInfoKey) => Promise<IClientTextInfoItem>;
    fetchClientTextInfo: () => Promise<IClientTextInfoItem[]>
}