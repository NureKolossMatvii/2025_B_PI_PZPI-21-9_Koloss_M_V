import { IProjectCreationDto } from "../Dto/IProjectCreationDto";
import { IProject } from "../Models/IProject";
import { UMLDiagram } from "../Models/UMLDiagram";
import { IValidationConfigHookProps } from "./IValidationConfigHookProps";
import { IViewConfigHookProps } from "./IViewConfigHookProps";

export interface IProjectHookProps {
    createNewProject: (newProject: IProjectCreationDto) => Promise<void>,
    project: IProject | undefined,
    fetchProject: (id: string) => Promise<void>,
    updateProject: (project: IProject) => void,
    viewConfig: IViewConfigHookProps
    validationConfig: IValidationConfigHookProps
}