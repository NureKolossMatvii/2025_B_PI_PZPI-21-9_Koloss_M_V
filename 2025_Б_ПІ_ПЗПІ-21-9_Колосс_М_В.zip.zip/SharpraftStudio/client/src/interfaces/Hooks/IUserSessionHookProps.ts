import { User } from "../../hooks/useUserAuthorization";

export interface IUserSessionHookProps {
    user: User | undefined;
    checkIsAuthorized: () => Promise<User | undefined>;
    isAuthorized: boolean;
    logout: () => Promise<void>;
}