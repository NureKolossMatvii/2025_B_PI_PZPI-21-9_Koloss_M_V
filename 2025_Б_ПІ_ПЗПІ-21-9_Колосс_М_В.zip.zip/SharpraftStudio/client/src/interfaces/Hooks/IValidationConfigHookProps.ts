import { ParameterType } from "../../Project/components/StepPages/Validation/Modals/EditColumnModal";
import { ValidationType } from "../../types/ValidationType";

export interface IValidationConfigHookProps {
    saveValidation: () => Promise<void>;
    toggleValidation: (columnValidationConfigurationId: string, type: ValidationType) => void;
    handleValidationChange: (type: ValidationType, field: ParameterType, value: string) => void
}