import { MouseEvent, ReactNode} from "react";
import { IPosition } from "../IPosition";

export interface IContextMenuHookProps {
    showMenu: (e: MouseEvent<HTMLDivElement, MouseEvent>, children: ReactNode) => void;
    hideMenu: () => void;
    position: IPosition;
    isVisible: boolean,
    contextChildren: ReactNode,
}