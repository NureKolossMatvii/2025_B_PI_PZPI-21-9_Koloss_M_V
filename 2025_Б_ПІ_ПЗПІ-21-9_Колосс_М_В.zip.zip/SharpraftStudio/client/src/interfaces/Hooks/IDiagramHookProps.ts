import { IUMLDiagramSaveDto } from "../Dto/IUMLDiagramSaveDto";
import { IDimension } from "../IDimension";
import { IPosition } from "../IPosition";
import { IUMLTableColumnOperations } from "../Models/Features/IUMLTableColumnOperations";
import { UMLDiagram } from "../Models/UMLDiagram";
import { UMLTableColumn } from "../Models/UMLTableColumn";
import { Dispatch, SetStateAction } from "react";
import { ErrorsModel } from "../../hooks/useDiagram";
import { UMLTable } from "../Models/UMLTable";
import { UMLTableConnection } from "../Models/UMLTableConnection";

export interface IDiagramHookProps {
    saveDiagram: (projectId: string) => Promise<void>,
    diagram: UMLDiagram | undefined,
    setDiagram: Dispatch<SetStateAction<UMLDiagram | undefined>>,
    fetchDiagram: (id: string) => Promise<void>,
    addNewTable: () => void,
    deleteTable: (tableId: string) => void,
    editTableName: (tableId: string, val: string) => void;
    setPrimaryKey: (newColumn: UMLTableColumn, tableId: string) => void;
    editColumn: (newColumn: UMLTableColumn) => void,
    deleteColumn: (columnId: string) => void;
    updateTableDimensions: (tableId: string, dimension: IDimension) => void;
    changeTablePosition: (tableId: string, position: IPosition) => void;
    addNewDiagram: (newDiagram: IUMLDiagramSaveDto) => Promise<void>,
    addColumn: (tableId: string, isForeignKey?: boolean, operations?: IUMLTableColumnOperations) => void,
    deleteConnection: (connectionId: string) => void;
    editColumnLabel: (tableId: string, columnId: string) => void;
    renderColumnName: (tableId: string) => string,
    copyTableToClipboard: (tableId: string) => void;
    cloneTableFromClipboard: (table?: UMLTable) => void;
    addNewConnection: (leftTableId: string, rightTableId: string) => void,
    registerOnTableChangeFunction: (name: string, tableCallback: (table: UMLTable[]) => void) => void;
    registerOnConnectionChangeFunction: (name: string, tableCallback: (table: UMLTableConnection[]) => void) => void;
    checkErrors: {
        validateTables: () => ErrorsModel;
        validateColumns: () => ErrorsModel;
        validateConnections: () => ErrorsModel;
    };
    clipboard: {
        copyDiagram: () => void
        pasteDiagram: () => Promise<void>
    }
  }