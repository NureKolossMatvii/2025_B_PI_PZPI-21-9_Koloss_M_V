import { ErrorsModel } from "../../hooks/useDiagram";
import { IDatasetSelectorRules } from "../Models/IDatasetSelectorRules";
import { IViewConfig } from "../Models/IViewConfig";

export interface IViewConfigHookProps {
    editTableLabel: (id: string, label: string) => void
    editColumnLabel: (id: string, label: string) => void
    editColumnDataSetSelectorRules: (columnViewConfigurationId: string, rules: IDatasetSelectorRules) => void;
    save: () => Promise<void>;
    validateTables: () => ErrorsModel
    validateColumns: () => ErrorsModel
    setViewConfig: (viewConfig: IViewConfig) => void;
}