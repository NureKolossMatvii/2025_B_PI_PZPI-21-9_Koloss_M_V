import { IDatasetSelectorRules } from "./IDatasetSelectorRules";

export interface IColumnViewConfig {
    columnViewConfigurationId: string,
    umlColumnId: string,
    label: string,
    datasetSelectorRules: IDatasetSelectorRules
}