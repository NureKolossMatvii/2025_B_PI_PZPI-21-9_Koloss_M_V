import { ReactNode } from "react"

export interface IContent {
    items: IContentItem[]
}

export type ContentType = "text" | "image" | "table" | "code" | "carousel"

export interface IContentItem {
    type: ContentType,
    value: ReactNode
}