import { UMLTable } from "./UMLTable";
import { UMLTableConnection } from "./UMLTableConnection";

export interface UMLDiagram {
    tables: UMLTable[],
    connections: UMLTableConnection[],
  }