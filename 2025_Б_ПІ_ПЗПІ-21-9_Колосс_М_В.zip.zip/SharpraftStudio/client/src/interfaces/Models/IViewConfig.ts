import { ITableViewConfig } from "./ITableViewConfig";

export interface IViewConfig {
    tableViewConfigs: ITableViewConfig[]
}