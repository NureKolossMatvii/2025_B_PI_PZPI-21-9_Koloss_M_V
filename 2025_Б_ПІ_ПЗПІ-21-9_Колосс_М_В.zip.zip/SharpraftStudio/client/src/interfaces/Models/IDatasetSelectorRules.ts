export interface IDatasetSelectorRules {
    sortingEnabled: boolean,
    searchingEnabled: boolean,
    filteringEnabled: boolean
}