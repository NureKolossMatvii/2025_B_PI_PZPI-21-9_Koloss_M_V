import { UMLColumnDataType } from "../../../types/UMLColumnDataType";
import { ValidationType } from "../../../types/ValidationType";

export interface IValidationConfig {
    tableValidationConfigs: ITableValidationConfig[]
}

export interface ITableValidationConfig {
    tableValidationConfigurationId: string,
    umlTableId: string,
    columnValidationConfigs: IColumnValidationConfig[]
}

export interface IColumnValidationConfig {
    columnValidationConfigurationId: string,
    umlColumnId: string,
    validation: IValidation[]
}

export interface IValidation {
    type: number,
    message: string,
    firstParameter: string
    secondParameter: string
}


export interface IValidationView {
    type: ValidationType,
    label: string,
    dataTypes: UMLColumnDataType[];
    defaultValues: DefaultValue
}

interface DefaultValue {
    message: string,
    firstParameter: string,
    secondParameter: string,
}

export const validationList: IValidationView[] = [
    { type: "Required", label: "Required", dataTypes: ["String", "Int", "DateTime", "Double", "Boolean"], defaultValues: { message: "Should be not required", firstParameter: "", secondParameter: "" }},
    { type: "MinLength", label: "Min length", dataTypes: ["String"], defaultValues: { message: "Should be more than 0", firstParameter: "0", secondParameter: ""}},
    { type: "MaxLength", label: "Max length", dataTypes: ["String"], defaultValues: { message: "Should be less than 1000", firstParameter: "1000", secondParameter: "" }},
    { type: "Email", label: "Email", dataTypes: ["String"], defaultValues: { message: "Email must be entered", firstParameter: "", secondParameter: "" }},
    { type: "PhoneNumber", label: "Phone number", dataTypes: ["String"], defaultValues: { message: "Phone number must be entered", firstParameter: "", secondParameter: "" } },
    { type: "Range", label: "Range", dataTypes: ["Int", "Double"], defaultValues: { message: "Should be more than 0 and less than 100", firstParameter: "1", secondParameter: "100" }},
]