import { IUMLOperationsBase } from "./IUMLOperationsBase";

export interface IUMLTableOperations extends IUMLOperationsBase {
    columnCreationAvailable: boolean
}