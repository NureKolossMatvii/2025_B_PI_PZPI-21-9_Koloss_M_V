import { IUMLOperationsBase } from "./IUMLOperationsBase";

export interface IUMLTableColumnOperations extends IUMLOperationsBase {
    dataTypeChangeAvailable: boolean,
    restrictionChangeAvailable: boolean,
}