export interface IEnabledFeatures {
    authorizationEnabled: boolean,
    userTableName: string,
}