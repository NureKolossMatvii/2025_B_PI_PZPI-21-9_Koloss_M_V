export interface IUMLOperationsBase {
    removeEnabled: boolean,
    nameChangeEnabled: boolean
}