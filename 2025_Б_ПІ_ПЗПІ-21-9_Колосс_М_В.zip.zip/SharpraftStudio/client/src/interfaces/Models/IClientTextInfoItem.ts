export interface IClientTextInfoItem {
    key: string,
    engLabel: string,
    ruLabel: string
}