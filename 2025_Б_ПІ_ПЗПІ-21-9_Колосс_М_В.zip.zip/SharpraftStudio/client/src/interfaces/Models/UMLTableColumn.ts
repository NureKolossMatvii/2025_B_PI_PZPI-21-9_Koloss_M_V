import { UMLColumnDataType } from "../../types/UMLColumnDataType";
import { IUMLTableColumnOperations } from "./Features/IUMLTableColumnOperations";

export interface UMLTableColumn {
    tableColumnId: string,
    name: string,
    isForeignKey: boolean,
    isPrimaryKey: boolean,
    operations: IUMLTableColumnOperations
    dataType: number,
  }