import { UMLConnectionType } from "../../types/UMLConnectionType";
import { UMLTable } from "./UMLTable";

export interface UMLTableConnection {
    tableConnectionId: string,
    leftTableId: string,
    rightTableId: string,
    foreignKeyColumnId: string,
    connectionType: number,
  }