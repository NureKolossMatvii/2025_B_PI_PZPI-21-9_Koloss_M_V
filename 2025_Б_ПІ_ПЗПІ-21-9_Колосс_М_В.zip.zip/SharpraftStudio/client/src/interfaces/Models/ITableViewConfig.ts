import { IColumnViewConfig } from "./IColumnViewConfig";

export interface ITableViewConfig {
    tableViewConfigurationId: string,
    umlTableId: string,
    label: string,
    columnViewConfigs: IColumnViewConfig[]
}