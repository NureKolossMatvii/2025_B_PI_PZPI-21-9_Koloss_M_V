import { IEnabledFeatures } from "./Features/IEnabledFeatures";
import { IViewConfig } from "./IViewConfig";
import { UMLDiagram } from "./UMLDiagram";
import { IValidationConfig } from "./Validation/IValidationConfig";

export interface IProject {
    projectConfigurationId: string,
    name: string,
    creationDate: string,
    step: number,
    enabledFeatures?: IEnabledFeatures,
    diagram?: UMLDiagram,
    viewConfig: IViewConfig
    validationConfig?: IValidationConfig,
    colorTemplateId?: string
}