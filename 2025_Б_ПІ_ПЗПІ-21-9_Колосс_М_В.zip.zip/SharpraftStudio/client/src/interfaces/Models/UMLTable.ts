import { IDimension } from "../IDimension";
import { IPosition } from "../IPosition";
import { IUMLTableOperations } from "./Features/IUMLTableOperations";
import { UMLTableColumn } from "./UMLTableColumn";

export interface UMLTable {
    tableId: string,
    name: string,
    position: IPosition,
    columns: UMLTableColumn[],
    dimensions: IDimension,
    operations: IUMLTableOperations,
    labelColumnTableId: string
  }