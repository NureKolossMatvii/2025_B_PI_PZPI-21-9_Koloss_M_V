import { ProjectCreationStep } from "../types/ProjectCreationStep";

export interface IProjectStepViewer {
    label: string,
    step: ProjectCreationStep
}