export interface ISelect {
    label: string,
    value: string,
}