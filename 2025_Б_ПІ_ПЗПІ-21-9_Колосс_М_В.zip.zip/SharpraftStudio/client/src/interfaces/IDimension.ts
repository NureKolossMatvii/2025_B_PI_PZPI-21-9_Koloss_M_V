export interface IDimension {
    width: number,
    height: number
}