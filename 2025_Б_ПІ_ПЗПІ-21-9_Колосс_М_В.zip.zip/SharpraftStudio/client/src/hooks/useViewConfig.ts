import { useContext } from "react";
import { ProjectContext } from "..";
import { saveProjectConfiguration } from "../http/projectConfigurationApi";
import { IViewConfigHookProps } from "../interfaces/Hooks/IViewConfigHookProps";
import { IDatasetSelectorRules } from "../interfaces/Models/IDatasetSelectorRules";
import { IProject } from "../interfaces/Models/IProject";
import { IViewConfig } from "../interfaces/Models/IViewConfig";
import { ErrorsModel } from "./useDiagram";

export const useViewConfig = (project: IProject | undefined, updateProject: (project: IProject) => void): IViewConfigHookProps => {

  const editTableLabel = (id: string, label: string) => {
    if (project) {
        updateProject({
          ...project,
          viewConfig: {
            ...project?.viewConfig,
            tableViewConfigs: [
              ...project?.viewConfig.tableViewConfigs.map((tableViewConfig) => {
                if (tableViewConfig.tableViewConfigurationId === id) {
                  return { ...tableViewConfig, label };
                }
  
                return tableViewConfig;
              }),
            ],
          },
        });
      }
  };

  const editColumnLabel = (id: string, label: string) => {
    if (project) {
        updateProject({
            ...project,
            viewConfig: {
                ...project?.viewConfig,
                tableViewConfigs: project?.viewConfig.tableViewConfigs.map((tableViewConfig) => ({
                    ...tableViewConfig,
                    columnViewConfigs: tableViewConfig.columnViewConfigs.map((columnViewConfig) => {
                        if (columnViewConfig.columnViewConfigurationId === id) {
                            return { ...columnViewConfig, label };
                        }
                        return columnViewConfig;
                    }),
                })),
            },
        });
    }
  }

  const editColumnDataSetSelectorRules = (columnViewConfigurationId: string, rules: IDatasetSelectorRules) => {
    if (project) {
        updateProject({
            ...project,
            viewConfig: {
                ...project?.viewConfig,
                tableViewConfigs: project?.viewConfig.tableViewConfigs.map((tableViewConfig) => ({
                    ...tableViewConfig,
                    columnViewConfigs: tableViewConfig.columnViewConfigs.map((columnViewConfig) => {
                        if (columnViewConfig.columnViewConfigurationId === columnViewConfigurationId) {
                            return { ...columnViewConfig, datasetSelectorRules: rules };
                        }
                        return columnViewConfig;
                    }),
                })),
            },
        });
    }
  }

  const save = async () => {
    if (project) {
        await saveProjectConfiguration(project?.projectConfigurationId, project?.viewConfig)
    }
  }


const normalizeLabel = (label: string): string => label.replace(/\s+/g, '').toUpperCase();
const findDuplicates = (items: { label: string }[]): { duplicates: string[], originalNames: { [key: string]: string } } => {
  const nameCounts: { [key: string]: number } = {};
  const originalNames: { [normalized: string]: string } = {};

  items.forEach((item) => {
    const normalizedLabel = normalizeLabel(item.label);
    nameCounts[normalizedLabel] = (nameCounts[normalizedLabel] || 0) + 1;
    if (!originalNames[normalizedLabel]) {
      originalNames[normalizedLabel] = item.label;
    }
  });

  const duplicates = Object.keys(nameCounts).filter((name) => nameCounts[name] > 1).map((normalized) => originalNames[normalized]);
  return { duplicates, originalNames };
};

const validateTables = (): ErrorsModel => {
  let newErrors: ErrorsModel = { success: true, messages: [] };

  if (project?.viewConfig) {
    const tables = project.viewConfig.tableViewConfigs;
    const { duplicates } = findDuplicates(tables);

    if (duplicates.length > 0) {
      newErrors.success = false;
      duplicates.forEach((value: string) => {
        newErrors.messages.push(`The table label is repeated: ${value}`);
      });
    }
  }

  return newErrors;
};

const setViewConfig = (viewConfig: IViewConfig) => {
  if (project) {{
    updateProject({
      ...project,
      viewConfig: viewConfig
    })
  }}
}

const validateColumns = (): ErrorsModel => {
  let newErrors: ErrorsModel = { success: true, messages: [] };

  if (project?.viewConfig) {
    const tables = project.viewConfig.tableViewConfigs;

    tables.forEach((table) => {
      const { duplicates } = findDuplicates(table.columnViewConfigs);

      if (duplicates.length > 0) {
        newErrors.success = false;
        duplicates.forEach((value: string) => {
          newErrors.messages.push(`The column label "${value}" in table "${table.label}" is repeated.`);
        });
      }
    });
  }

  return newErrors;
};

  return {
    editTableLabel,
    editColumnLabel,
    editColumnDataSetSelectorRules,
    save,
    validateTables,
    validateColumns,
    setViewConfig
  };
};
