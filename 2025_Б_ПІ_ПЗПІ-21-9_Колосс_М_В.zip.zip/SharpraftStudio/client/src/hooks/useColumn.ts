import uuid from "react-uuid";
import { IUMLTableColumnOperations } from "../interfaces/Models/Features/IUMLTableColumnOperations";
import { UMLDiagram } from "../interfaces/Models/UMLDiagram";
import { UMLTable } from "../interfaces/Models/UMLTable";
import { UMLTableColumn } from "../interfaces/Models/UMLTableColumn";
import { UMLTableConnection } from "../interfaces/Models/UMLTableConnection";

const defaultColumnName = "column";

export const useColumn = (
  diagram: UMLDiagram | undefined,
  setDiagram: (diagram: UMLDiagram) => void,
  onTableChangeFunctions: Record<string, (table: UMLTable[]) => void>
): {
  setPrimaryKey: (newColumn: UMLTableColumn, tableId: string) => void;
  editColumn: (newColumn: UMLTableColumn) => void;
  addColumn: (tableId: string, isForeignKey?: boolean, operations?: IUMLTableColumnOperations) => void;
  deleteColumn: (columnId: string) => void;
  renderColumnName: (tableId: string) => string;
  editColumnLabel: (tableId: string, columnId: string) => void
} => {

  const editColumn = (newColumn: UMLTableColumn) => {
    if (diagram) {
      const updatedTables = diagram.tables.map((table) => {
        return {
          ...table,
          columns: table.columns.map((column) => {
            if (column.tableColumnId === newColumn.tableColumnId) {
              return newColumn;
            }
            return column;
          }),
        };
      });
      
      Object.values(onTableChangeFunctions).forEach((func) => func(updatedTables));

      setDiagram({
        ...diagram,
        tables: updatedTables
      });
      
    }
  };

  const setPrimaryKey = (newColumn: UMLTableColumn, tableId: string) => {
    if (diagram) {
      setDiagram({
        ...diagram,
        tables: diagram.tables.map((table) => {
          if(tableId === table.tableId) {
            return {
              ...table,
              columns: table.columns.map((column) => {
                if (column.tableColumnId === newColumn.tableColumnId) {
                  return newColumn;
                }
                return {...column, isPrimaryKey: false};
              }),
            }
          }

          return table
        }),
      });
    }
  }

  const renderColumnName = (tableId: string) => {
    let columnName = defaultColumnName;
   if (diagram) {
    const existingColumnNames = diagram.tables
    .find((table) => table.tableId === tableId)
    ?.columns.map((column) => column.name);

    if (existingColumnNames) {
      for (let i = 1; existingColumnNames.includes(columnName); ++i) {
        columnName = `${defaultColumnName}${i}`;
      }
    }
   }

   return columnName;
  }

  const addColumn = (tableId: string, isForeignKey = false, operations = {
    dataTypeChangeAvailable: true,
    restrictionChangeAvailable: true,
    removeEnabled: true,
    nameChangeEnabled: true
  } as IUMLTableColumnOperations) => {
    if (diagram) {
      const columnName = renderColumnName(tableId);

      const newColumn: UMLTableColumn = {
        tableColumnId: uuid(),
        name: columnName,
        dataType: 0,
        isForeignKey: isForeignKey,
        isPrimaryKey: false,
        operations: operations
      };

      const updatedTables = diagram.tables.map((table) => {
        if (table.tableId === tableId) {
          return {
            ...table,
            columns: [...table.columns, newColumn],
          };
        }

        return table;
      })
      
      Object.values(onTableChangeFunctions).forEach((func) => func(updatedTables));

      setDiagram({
        ...diagram,
        tables: updatedTables
      });
    }
  };

  const deleteColumn = (columnId: string) => {
    if (diagram) {
      const tableIndex = diagram.tables.findIndex((t) =>t.columns.some((c) => c.tableColumnId === columnId));

      if (tableIndex !== -1) {
          const updatedTable = {
              ...diagram.tables[tableIndex],
              columns: diagram.tables[tableIndex].columns.filter((column) => column.tableColumnId !== columnId),
          };

          const updatedTables = [...diagram.tables];
          updatedTables.splice(tableIndex, 1, updatedTable);
          Object.values(onTableChangeFunctions).forEach((func) => func(updatedTables));
          setDiagram({ ...diagram, tables: updatedTables });
      }
  }
  };

  const editColumnLabel = (tableId: string, columnId: string) => {
    if (diagram) {
     setDiagram({
       ...diagram,
       tables: diagram?.tables.map((table) => {
         if (table.tableId === tableId) {
           return {...table, labelColumnTableId: columnId}
         }
         return table
       })
     })
    }
   }

  return {
    editColumn,
    addColumn,
    deleteColumn,
    setPrimaryKey,
    renderColumnName,
    editColumnLabel
  };
};
