import { useState, useEffect } from "react";
import uuid from "react-uuid";
import { saveUmlDiagram } from "../http/umlApi";
import { IUMLDiagramSaveDto } from "../interfaces/Dto/IUMLDiagramSaveDto";
import { IDiagramHookProps } from "../interfaces/Hooks/IDiagramHookProps";
import { UMLDiagram } from "../interfaces/Models/UMLDiagram";
import { UMLTable } from "../interfaces/Models/UMLTable";
import { UMLTableConnection } from "../interfaces/Models/UMLTableConnection";
import { DiagramService } from "../Services/DiagramService";
import { isValidNamespace } from "../utils/isValidNamespace";
import { useColumn } from "./useColumn";
import { useTable } from "./useTable";

export interface ErrorsModel {
  success: boolean,
  messages: string[]
}

export const useDiagram = (): IDiagramHookProps => {
  const [diagram, setDiagram] = useState<UMLDiagram>();
  const [onTableChangeFunctions, setOnTableChangeFunctions] = useState<Record<string, (table: UMLTable[]) => void>>({});
  const [onConnectionChangeFunctions, setOnConnectionChangeFunctions] = useState<Record<string, (table: UMLTableConnection[]) => void>>({});

  const {
    addNewTable,
    deleteTable,
    editTableName,
    changeTablePosition,
    updateTableDimensions,
    copyTableToClipboard,
    cloneTableFromClipboard,
    deleteConnection,
  } = useTable(diagram, setDiagram, onTableChangeFunctions, onConnectionChangeFunctions);
  const { editColumn, addColumn, deleteColumn, setPrimaryKey, renderColumnName, editColumnLabel } = useColumn(
    diagram,
    setDiagram,
    onTableChangeFunctions
  );

  const diagramService = new DiagramService();

  const registerOnTableChangeFunction = (name: string, tableCallback: (table: UMLTable[]) => void) => {
    setOnTableChangeFunctions((prev) => {
      const clone = {...prev};
      clone[name] = tableCallback;
      return clone
    })
  }

  const registerOnConnectionChangeFunction = (name: string, tableCallback: (connection: UMLTableConnection[]) => void) => {
    setOnConnectionChangeFunctions((prev) => {
      const clone = {...prev};
      clone[name] = tableCallback;
      return clone;
    })
  }

  const validateTables = (): ErrorsModel => {
    let newErrors: ErrorsModel = { success: true, messages: [] };
  
    if (diagram) {
      const tables = diagram.tables;
  
      const nameCounts: { [key: string]: number } = {};
  
      tables.forEach((table) => {
        nameCounts[table.name] = (nameCounts[table.name] || 0) + 1;
        const tableNameIsCorrect = isValidNamespace(table.name);
        if (!tableNameIsCorrect) {
          newErrors.success = false;
          newErrors.messages.push(`Invalid table name: '${table.name}'. This name is breaks the rules of tables names`)
        }
      });
  
      const duplicateNames = Object.keys(nameCounts).filter((name) => nameCounts[name] > 1);
  
      if (duplicateNames.length > 0) {
        newErrors.success = false;
        duplicateNames.forEach((value: string) => {
          newErrors.messages.push(`The table name is repeated: ${value}`);
        })
      }
    }
  
    return newErrors
  };

  const validateColumns = (): ErrorsModel => {
    let newErrors: ErrorsModel = { success: true, messages: [] };
    
    if (diagram) {
      diagram.tables.forEach((table) => {
        const columnNameCounts: { [key: string]: number } = {};
        table.columns.forEach((column) => {
          columnNameCounts[column.name] = (columnNameCounts[column.name] || 0) + 1;
          const columnNameIsCorrect = isValidNamespace(column.name);
          if (!columnNameIsCorrect) {
            newErrors.success = false;
            newErrors.messages.push(`Invalid column name: '${column.name}'. This name is breaks the rules of column names`)
          }
        });
  
        const duplicateColumnNames = Object.keys(columnNameCounts).filter(
          (name) => columnNameCounts[name] > 1
        );
  
        if (duplicateColumnNames.length > 0) {
          newErrors.success = false;
          newErrors.messages.push(`Table '${table.name}' has duplicate column names: ${duplicateColumnNames.join(", ")}`);
        }
      });
    }

    return newErrors;
  };

  const validateConnections = (): ErrorsModel => {
    let newErrors: ErrorsModel = { success: true, messages: [] };
  
    if (diagram) {
      for (const connection of diagram.connections) {
        if (connection.leftTableId === connection.rightTableId) {
          newErrors.success = false;
          const currentTable = diagram.tables.find(
            (table) => table.tableId === connection.leftTableId
          );
          newErrors.messages.push(
            `Invalid connection: Table "${currentTable?.name}" is connected to itself.`
          );
        }
      }
  
      const visited = new Set<string>();
      const visiting = new Set<string>();
  
      const hasCycle = (tableId: string): boolean => {
        if (visiting.has(tableId)) {
          return true;
        }
  
        if (visited.has(tableId)) {
          return false;
        }
  
        visiting.add(tableId);
  
        const outgoingConnections = diagram.connections.filter(
          (connection) => connection.leftTableId === tableId
        );
  
        for (const connection of outgoingConnections) {
          if (hasCycle(connection.rightTableId)) {
            return true;
          }
        }
  
        visiting.delete(tableId);
        visited.add(tableId);
  
        return false;
      };
  
      for (const table of diagram.tables) {
        if (hasCycle(table.tableId)) {
          newErrors.success = false;
          newErrors.messages.push(`Cyclic connection detected involving table "${table.name}".`);
          break;
        }
      }
    }
  
    return newErrors;
  };
  
  const saveDiagram = async (projectId: string) => {
    if (diagram) {
      await diagramService.save(diagram, projectId);
    }
  };

  const addNewDiagram = async (newDiagram: IUMLDiagramSaveDto) => {
    await saveUmlDiagram(newDiagram);
  };

  const fetchDiagram = async (projectId: string) => {
    const responseDiagram = await diagramService.get(projectId);
    setDiagram(responseDiagram);
  };

  const addNewConnection = (leftTableId: string, rightTableId: string) => {
    if (diagram) {
      let updatedTables: UMLTable[] = diagram.tables;

      const addForeignKeyColumn = (
        table: UMLTable,
        columnName: string,
        columnId: string
      ) => ({
        ...table,
        columns: [
          ...table.columns,
          {
            tableColumnId: columnId,
            name: columnName,
            isForeignKey: true,
            isPrimaryKey: false,
            operations: {
              dataTypeChangeAvailable: false,
              restrictionChangeAvailable: false,
              removeEnabled: false,
              nameChangeEnabled: true,
            },
            dataType: 1,
          },
        ],
      });

      const table = diagram.tables.find((table) => table.tableId === leftTableId);
      const columnId = uuid();
      
      const newConnection: UMLTableConnection = {
        tableConnectionId: uuid(),
        leftTableId,
        rightTableId,
        foreignKeyColumnId: columnId,
        connectionType: 0
      }

      const columnName = `Foreign_${table?.name}_Id`

      updatedTables = updatedTables.map((table) =>
        table.tableId === rightTableId ? addForeignKeyColumn(table, columnName, columnId) : table
      );

      const updatedConnections = [...diagram.connections, newConnection];
      Object.values(onConnectionChangeFunctions).forEach((func) => func(updatedConnections));
      Object.values(onTableChangeFunctions).forEach((func) => func(updatedTables));

      setDiagram({
        ...diagram,
        connections: updatedConnections,
        tables: updatedTables,
      });
    }
  }

  const copyDiagram = () => {
    if (diagram) {
        const tables = diagram.tables;
        const connections = diagram.connections;

        const idMapping: { tableIdMap: { [oldId: string]: string }, columnIdMap: { [oldId: string]: string } } = {
            tableIdMap: {},
            columnIdMap: {}
        };

        const newTables = tables.map((table) => {
            const columns = table.columns.map((column) => {
                const newColumnId = uuid();
                idMapping.columnIdMap[column.tableColumnId] = newColumnId;
                return { ...column, tableColumnId: newColumnId };
            });

            const newTableId = uuid();
            idMapping.tableIdMap[table.tableId] = newTableId;

            return {
                ...table,
                tableId: newTableId,
                labelColumnTableId: columns[0].tableColumnId,
                columns: columns
            };
        });

        const newConnections = connections.map((connection) => ({
            ...connection,
            tableConnectionId: uuid(),
            leftTableId: idMapping.tableIdMap[connection.leftTableId],
            rightTableId: idMapping.tableIdMap[connection.rightTableId],
            foreignKeyColumnId: idMapping.columnIdMap[connection.foreignKeyColumnId]
        }));

        navigator.clipboard.writeText(JSON.stringify({ tables: newTables, connections: newConnections }))
    }
};  

const pasteDiagram = async () => {
  const isUMLDiagram = (obj: any): obj is UMLDiagram  => {
      return obj && typeof obj.name === "string" && Array.isArray(obj.elements);
  }

  const diagramFromClipboard: any = await navigator.clipboard.readText();
  try {
  const parsedDiagram = JSON.parse(diagramFromClipboard);
  if (!isUMLDiagram(parsedDiagram)) {
    const tables = parsedDiagram.tables;
    const connections = parsedDiagram.connections;
    setDiagram(parsedDiagram)
    Object.values(onTableChangeFunctions).forEach((func) => func(tables));
    Object.values(onConnectionChangeFunctions).forEach((func) => func(connections));
  }
  } catch (error) {
  }
}

  return {
    saveDiagram,
    diagram,
    setDiagram,
    fetchDiagram,
    addNewTable,
    deleteTable,
    setPrimaryKey,
    editColumn,
    deleteColumn,
    changeTablePosition,
    updateTableDimensions,
    addNewDiagram,
    addColumn,
    editTableName,
    deleteConnection,
    editColumnLabel,
    renderColumnName,
    copyTableToClipboard,
    cloneTableFromClipboard,
    addNewConnection,
    registerOnTableChangeFunction,
    registerOnConnectionChangeFunction,
    checkErrors: {
      validateColumns,
      validateTables,
      validateConnections
    },
    clipboard: {
        copyDiagram,
        pasteDiagram
    }
  };
};
