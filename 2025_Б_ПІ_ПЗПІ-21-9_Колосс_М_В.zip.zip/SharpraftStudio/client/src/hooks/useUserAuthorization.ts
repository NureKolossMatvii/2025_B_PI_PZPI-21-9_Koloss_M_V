import { jwtDecode } from "jwt-decode";
import { useEffect, useState } from "react";
import { checkToken, UserClaims } from "../Auth/http/authApi";
import { tokenLocalStorageKey } from "../consts";
import { IUserSessionHookProps } from "../interfaces/Hooks/IUserSessionHookProps";
import mapJwtClaims from "../utils/mapJwtClaims";


export interface User {
    name:string,
    role:string[],
}

export const useUserAuthorization = () : IUserSessionHookProps => {
    const [user, setUser] = useState<User | undefined>()
    const [isAuthorized, setIsAuthorized] = useState<boolean>(false);

    useEffect(() => {
        checkIsAuthorized();
    }, [])

    const checkIsAuthorized = async (): Promise<User | undefined> => {
        try {
            await checkToken()
            const token = localStorage.getItem(tokenLocalStorageKey);
                if (token) {
                    const jwtDecoded = jwtDecode(token) as UserClaims;
                    const userDecoded = mapJwtClaims(jwtDecoded);
                    setUser(userDecoded);
                    setIsAuthorized(true);
                    return userDecoded;
                }

                return undefined
        } catch (error) {
            console.error(error)
            return undefined;
        }
    }

    const logout = async () => {
        localStorage.removeItem(tokenLocalStorageKey);
        setUser(undefined);
        setIsAuthorized(false);
    }

    return { user, checkIsAuthorized, isAuthorized, logout };
}