import React, {useState, useEffect} from 'react'
import uuid from "react-uuid";
import { IDimension } from "../interfaces/IDimension";
import { IPosition } from "../interfaces/IPosition";
import { UMLDiagram } from "../interfaces/Models/UMLDiagram";
import { UMLTable } from "../interfaces/Models/UMLTable";
import { UMLTableColumn } from '../interfaces/Models/UMLTableColumn';
import { UMLTableConnection } from '../interfaces/Models/UMLTableConnection';

const defaultTableName = "NewTable";

export const useTable = (
  diagram: UMLDiagram | undefined,
  setDiagram: (diagram: UMLDiagram) => void,
  onTableChangeFunctions: Record<string, (table: UMLTable[]) => void>,
  onConnectionChangeFunctions: Record<string, (table: UMLTableConnection[]) => void>
): {
    addNewTable: () => void;
  deleteTable: (tableId: string) => void;
  editTableName: (tableId: string, val: string) => void;
  updateTableDimensions: (tableId: string, dimension: IDimension) => void;
  changeTablePosition: (tableId: string, position: IPosition) => void;
  copyTableToClipboard: (tableId: string) => void;
  cloneTableFromClipboard: (table?: UMLTable) => void;
  deleteConnection: (connectionId: string) => void;
} => {
  const [tableDimensions, setTableDimensions] = useState<{ [key: string]: IDimension }>({});
  const [clipboardTable, setClipboardTable] = useState<UMLTable | undefined>();

  const renderTableName = (name = defaultTableName) => {
    const existingTableNames = diagram?.tables ? diagram.tables.map((table) => table.name) : [];
    let tableName = name;
    for (let i = 1; existingTableNames.includes(tableName); ++i) {
      tableName = `${name}${i}`;
    }

    return tableName;
  }

  const addNewTable = () => {
    if (diagram) {
      const tableName = renderTableName();
      const defaultColumn =  {
        tableColumnId: uuid(),
        name: `${tableName}_Id`,
        isForeignKey: false,
        isPrimaryKey: true,
        operations: {
          dataTypeChangeAvailable: false,  
          restrictionChangeAvailable: false,
          removeEnabled: false,
          nameChangeEnabled: true
        },
        dataType: 1
      }

      const newTable: UMLTable = {
        tableId: uuid(),
        name: tableName,
        position: diagram.tables.length ? { x: diagram.tables[diagram.tables.length - 1].position.x + 10, y: diagram.tables[diagram.tables.length - 1].position.y + 10 } : { x: 0, y: 0 },
        dimensions: { width: 100, height: 100 },
        columns: [defaultColumn],
        operations: {
          columnCreationAvailable: true,
          removeEnabled: true,
          nameChangeEnabled: true
        },
        labelColumnTableId: defaultColumn.tableColumnId
      };

      const updatedTables = [...(diagram.tables || []), newTable];

      setDiagram({
        ...diagram,
        tables: updatedTables,
      });

      Object.values(onTableChangeFunctions).forEach((func) => func(updatedTables));
    }
  };

  const deleteTable = (tableId: string) => {
    if (diagram) {
      const connectionsToDelete = diagram.connections.filter(
        (connection) => connection.leftTableId === tableId || connection.rightTableId === tableId
      );
  
      const updatedTables = diagram.tables.map((table) => ({
        ...table,
        columns: table.columns.filter(
          (column) =>
            !connectionsToDelete.some((connection) => connection.foreignKeyColumnId === column.tableColumnId)
        ),
      }));

        Object.values(onTableChangeFunctions).forEach((func) => func(updatedTables.filter((table) => table.tableId !== tableId)));

      setDiagram({
        ...diagram,
        connections: diagram.connections.filter(
          (connection) =>
            !connectionsToDelete.some((conn) => conn.tableConnectionId === connection.tableConnectionId)
        ),
        tables: updatedTables.filter((table) => table.tableId !== tableId),
      });
    }
  };

  const deleteConnection = (connectionId: string) => {
    if (diagram) {
      let updatedTables: UMLTable[] = diagram.tables;
      const connection: UMLTableConnection | undefined =
        diagram.connections.find(
          (connection) => connection.tableConnectionId === connectionId
        );
      if (connection) {
        const tableId = connection.connectionType === 0 ? connection.rightTableId : connection.leftTableId;
        updatedTables = updatedTables.map((table) =>
          table.tableId === tableId
          ? {
                ...table,
                columns: table.columns.filter((column) => column.tableColumnId !== connection.foreignKeyColumnId),
              }
            : table
        );
      }

      const updatedConnections = diagram?.connections.filter(
        (connection) => connection.tableConnectionId !== connectionId
      )

      Object.values(onConnectionChangeFunctions).forEach((func) => func(updatedConnections));
      Object.values(onTableChangeFunctions).forEach((func) => func(updatedTables));

      setDiagram({
        ...diagram,
        connections: updatedConnections,
        tables: updatedTables,
      });
    }
  };

  const editTableName = (tableId: string, val: string) => {
    if (diagram) {
      const updatedTables = diagram.tables.map((table) => {
        if (table.tableId === tableId) {
            return {
                ...table,
                name: val !== "" ? val : renderTableName()
            }
        }

        return table;
    });

        setDiagram({
            ...diagram,
            tables: updatedTables
        })

        Object.values(onTableChangeFunctions).forEach((func) => func(updatedTables));
    }
  };

  const changeTablePosition = (tableId: string, position: IPosition) => {
    if (diagram) {
      const newDiagram: UMLDiagram = {
        ...diagram,
        tables: diagram.tables.map((table) => {
          if (table.tableId === tableId) {
            return { ...table, position: position };
          }

          return table;
        }),
      };

      setDiagram(newDiagram);
    }
  };
  
  const updateTableDimensions = (tableId: string, dimension: IDimension) => {
    setTableDimensions((prevDimensions) => ({
      ...prevDimensions,
      [tableId]: dimension,
    }));
  };

  const copyTableToClipboard = (tableId: string) => {
    if (diagram?.tables) {
      const table = diagram.tables.find((table) => table.tableId === tableId);
      setClipboardTable(table)
    }
  }

  const cloneTableFromClipboard = (table = clipboardTable) => {
    if (table && diagram) {
      const newColumns:UMLTableColumn[] = table.columns
      .filter((column) => !column.isForeignKey)
      .map((column) => {
          return {
            ...column,
            tableColumnId: uuid(),
            name: column.name,
            isForeignKey: false,
            operations: {
              removeEnabled: true,
              nameChangeEnabled: true,
              dataTypeChangeAvailable: true,
              restrictionChangeAvailable: true,
            }
          }
      })

      const newTable:UMLTable = {
        ...table,
        tableId: uuid(),
        name: renderTableName(`${table.name}_Copy`),
        position: {x: 10, y: 10},
        columns: newColumns,
        operations: {
          removeEnabled: true,
          nameChangeEnabled: true,
          columnCreationAvailable: true
        },
        labelColumnTableId: newColumns[0].tableColumnId
      }
      
      const updatedTables = [...diagram.tables, newTable];
      
      Object.values(onTableChangeFunctions).forEach((func) => func(updatedTables));

      setDiagram({
        ...diagram,
        tables: updatedTables
      })
    }
  }

  useEffect(() => {
    if (diagram) {
      setDiagram({
        ...diagram,
        tables: diagram?.tables.map((table) => {
          return {...table, dimensions: tableDimensions[table.tableId]}
        })
      });
    } 
}, [tableDimensions])

  return {
    addNewTable,
    deleteTable,
    editTableName,
    changeTablePosition,
    updateTableDimensions,
    copyTableToClipboard,
    cloneTableFromClipboard,
    deleteConnection,
  };
};
