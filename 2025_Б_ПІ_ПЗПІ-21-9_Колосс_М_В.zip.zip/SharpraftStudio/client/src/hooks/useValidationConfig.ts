import { saveValidationConfig } from "../http/projectConfigurationApi";
import { IProject } from "../interfaces/Models/IProject";
import {
  IColumnValidationConfig,
  IValidation,
  validationList,
} from "../interfaces/Models/Validation/IValidationConfig";
import { ParameterType } from "../Project/components/StepPages/Validation/Modals/EditColumnModal";
import { ValidationType, validationTypes } from "../types/ValidationType";

export const useValidationConfig = (
  project: IProject | undefined,
  updateProject: (project: IProject) => void
) => {
  const saveValidation = async () => {
    if (project?.validationConfig) {
      await saveValidationConfig(project?.projectConfigurationId, project?.validationConfig);
    }
  };

  const toggleValidation = (
    columnValidationConfigurationId: string,
    type: ValidationType
  ) => {
    if (project?.validationConfig) {
      const currentColumnValidationConfig: IColumnValidationConfig | undefined = project.validationConfig.tableValidationConfigs
          .flatMap((tableValidationConfig) => tableValidationConfig.columnValidationConfigs)
          .find((columnValidationConfig) => columnValidationConfig.columnValidationConfigurationId === columnValidationConfigurationId);

      if (!currentColumnValidationConfig) return;

      const validationExists = currentColumnValidationConfig.validation.some((validation) => validationTypes[validation.type] === type);
      let updatedValidation: IValidation[];

      if (validationExists) {
        updatedValidation = currentColumnValidationConfig.validation.filter((validation) => validationTypes[validation.type] !== type);
      } else {
        const validationItem = validationList.find((val) => val.type === type);
        if (validationItem) {
            const newValidation: IValidation = {
                type: validationTypes.indexOf(type),
                message: validationItem.defaultValues.message,
                firstParameter: validationItem.defaultValues.firstParameter,
                secondParameter: validationItem.defaultValues.secondParameter
            };
            updatedValidation = [...currentColumnValidationConfig.validation, newValidation];
        }
      }

      updateProject({
        ...project,
        validationConfig: {
          ...project.validationConfig,
          tableValidationConfigs:
            project.validationConfig?.tableValidationConfigs.map(
              (tableConfig) => ({
                ...tableConfig,
                columnValidationConfigs:
                  tableConfig.columnValidationConfigs.map((columnConfig) =>
                    columnConfig.columnValidationConfigurationId ===
                    columnValidationConfigurationId
                      ? { ...columnConfig, validation: updatedValidation }
                      : columnConfig
                  ),
              })
            ),
        },
      });
    }
  };

  const handleValidationChange = (type: ValidationType, field: ParameterType, value: string) => {
    if (project?.validationConfig) {
     const updatedProject = {
       ...project,
       validationConfig: {
           ...project.validationConfig,
           tableValidationConfigs: project.validationConfig.tableValidationConfigs.map((tableConfig) => ({
               ...tableConfig,
               columnValidationConfigs: tableConfig.columnValidationConfigs.map((columnConfig) => ({
                   ...columnConfig,
                   validation: columnConfig.validation.map((validation) =>
                       validationTypes[validation.type] === type
                           ? { ...validation, [field]: value } 
                           : validation
                   ),
               })),
           })),
       },
   };
 
   updateProject(updatedProject);
    }
 };

  return {
    saveValidation,
    toggleValidation,
    handleValidationChange
  };
};
