import { MouseEvent, useState, ReactNode, useEffect} from "react";
import { IPosition } from "../interfaces/IPosition";
import { IContextMenuHookProps } from "../interfaces/Hooks/IContextMenuHookProps";
import { IClientTextInfoContextProps } from "../interfaces/Hooks/IClientTextInfoContextProps";
import { addClientTextInfo, getClientTextInfo } from "../http/clientTextInfoClient";
import { IClientTextInfoItem } from "../interfaces/Models/IClientTextInfoItem";
import { ClientTextInfoKey } from "../types/ClientTextInfoKey";

export const useClientTextInfo = (): IClientTextInfoContextProps => {
    const [clientTextInfo, setClientTextInfo] = useState<IClientTextInfoItem[]>([])

    useEffect(() => {
        fetchClientTextInfo()
    }, [])

    const fetchClientTextInfo = async (): Promise<IClientTextInfoItem[]> => {
        const data = await getClientTextInfo()
        setClientTextInfo(data);
        return data
    }

    const getClientTextInfoByKey = async (clientTextInfoKey: ClientTextInfoKey):Promise<IClientTextInfoItem> => {
        const item = clientTextInfo.find(({key}) => key === clientTextInfoKey);
        if (!item) {
            return {key: clientTextInfoKey, engLabel: "", ruLabel: ""}
        }

        return item;
    }

  return {
    clientTextInfo,
    getClientTextInfoByKey,
    fetchClientTextInfo
  };
};
