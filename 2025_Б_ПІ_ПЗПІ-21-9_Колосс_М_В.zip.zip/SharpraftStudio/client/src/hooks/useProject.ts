import { useState } from "react"
import uuid from "react-uuid";
import { createProject } from "../http/projectApi";
import { IProjectCreationDto } from "../interfaces/Dto/IProjectCreationDto";
import { IProjectHookProps } from "../interfaces/Hooks/IProjectHookProps";
import { IProject } from "../interfaces/Models/IProject";
import { UMLDiagram } from "../interfaces/Models/UMLDiagram";
import { ProjectService } from "../Services/ProjectService";
import { useValidationConfig } from "./useValidationConfig";
import { useViewConfig } from "./useViewConfig";

export const useProject = (): IProjectHookProps => {
    const [project, setProject] = useState<IProject>();

    const updateProject = (project: IProject) => {
        setProject(project);
    }

    const { editTableLabel, editColumnLabel, editColumnDataSetSelectorRules, save, validateTables, validateColumns, setViewConfig } = useViewConfig(project, updateProject);
    const { saveValidation, toggleValidation, handleValidationChange } = useValidationConfig(project, updateProject);
    const projectService = new ProjectService();
    
    const createNewProject = async (newProject: IProjectCreationDto) => {
        return await createProject(newProject);
    }

    const fetchProject = async (id: string) => {
        const project = await projectService.get(id)
        setProject(project);
    }

    return {
        project,
        createNewProject,
        fetchProject,
        updateProject,
        viewConfig: {
            editTableLabel,
            editColumnLabel,
            editColumnDataSetSelectorRules,
            setViewConfig,
            save,
            validateTables,
            validateColumns
        },
        validationConfig: {
            saveValidation,
            toggleValidation,
            handleValidationChange
        }
    }
}