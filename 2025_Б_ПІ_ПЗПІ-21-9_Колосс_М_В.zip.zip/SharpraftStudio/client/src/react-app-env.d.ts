/// <reference types="react-scripts" />

declare module 'react-color' {
    export * from 'react-color/lib/components/common';
    export * from 'react-color/lib/components/sketch/Sketch';
    export { SketchPicker } from 'react-color/lib/components/sketch/Sketch';
}
declare module 'react-bootstrap';
declare module 'quill-resize-image';