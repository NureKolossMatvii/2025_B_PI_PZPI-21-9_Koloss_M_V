import { $authhost } from "."
import { IProjectCreationDto } from "../interfaces/Dto/IProjectCreationDto";
import { SetupEnabledFeaturesDto } from "../Project/components/StepPages/FeaturesEnabling/FeaturesEnabling";

export const getProjects = async () => {
    const {data} = await $authhost.get('api/ProjectConfiguration');
    return data;
}

export const getProject = async (id: string) => {
    const {data} = await $authhost.get('api/ProjectConfiguration/' + id);
    return data;
}

export const moveProjectToNextStep = async (projectId: string) => {
    const {data} = await $authhost.patch(`api/ProjectConfiguration/step/${projectId}`)
    return data;
}

export const createProject = async (project: IProjectCreationDto) => {
    const {data} = await $authhost.post(`api/ProjectConfiguration`, project)
    return data;
}

export const removeProject = async (projectId: string) => {
    await $authhost.delete(`api/ProjectConfiguration/${projectId}`)
}