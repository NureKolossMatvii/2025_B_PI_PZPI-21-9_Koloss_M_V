import { $authhost } from "."
import { IAdminCreateDto } from "../interfaces/Dto/IAdminCreateDto";
import { IUser } from "../interfaces/Models/IUser";

export const getUsers = async () => {
    /* const {data} = await $authhost.get('api/Users'); */
    const data:IUser[] = [
        {id: "1", userName: "admin", roles: [{ id: "1", name: "ADMIN" }, { id: "2", name: "CREATOR" }]},
        {id: "2", userName: "matvey", roles: [{ id: "2", name: "CREATOR" }]},
        {id: "2", userName: "matvey", roles: [{ id: "2", name: "CREATOR" }]},
        {id: "2", userName: "matvey", roles: [{ id: "2", name: "CREATOR" }]},
        {id: "2", userName: "matvey", roles: [{ id: "2", name: "CREATOR" }]},
        {id: "2", userName: "matvey", roles: [{ id: "2", name: "CREATOR" }]},
        {id: "2", userName: "matvey", roles: [{ id: "2", name: "CREATOR" }]},
        {id: "2", userName: "matvey", roles: [{ id: "2", name: "CREATOR" }]},
        {id: "2", userName: "matvey", roles: [{ id: "2", name: "CREATOR" }]},
    ]

    return data;
}

export const createAdmin = async (admin: IAdminCreateDto) => {
    const {data} = await $authhost.post('api/Users', admin);
}