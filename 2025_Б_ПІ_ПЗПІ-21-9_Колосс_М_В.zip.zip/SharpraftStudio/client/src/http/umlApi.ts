import { $authhost } from "."
import { IUMLDiagramSaveDto } from "../interfaces/Dto/IUMLDiagramSaveDto";

export const saveUmlDiagram = async (diagram: IUMLDiagramSaveDto) => {
    const {data} = await $authhost.post('api/UserUML/save', diagram)
    return data;
}