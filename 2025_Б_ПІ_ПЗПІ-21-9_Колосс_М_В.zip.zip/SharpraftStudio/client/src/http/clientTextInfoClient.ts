import { $authhost } from "."
import { IClientTextInfoItem } from "../interfaces/Models/IClientTextInfoItem"

export const getClientTextInfo = async (): Promise<IClientTextInfoItem[]> => {
    const {data} = await $authhost.get(`api/ClientTextInfo`)
    return data
}

export const addClientTextInfo = async (item: IClientTextInfoItem) => {
    await $authhost.post(`api/ClientTextInfo`, item)
}