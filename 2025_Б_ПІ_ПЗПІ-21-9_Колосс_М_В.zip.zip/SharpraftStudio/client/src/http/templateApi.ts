import { $authhost } from "."
import { ITemplate } from "../interfaces/Templates/ITemplate";

export const getTemplates = async () => {
    const {data} = await $authhost.get('api/ColorTemplates');
    return data;
}

export const createTemplate = async (template: ITemplate) => {
    const {data} = await $authhost.post('api/ColorTemplates', template);
}

export const editTemplate = async (template: ITemplate) => {
    const {data} = await $authhost.patch('api/ColorTemplates', template);
}

export const deleteTemplate = async (id: string) => {
    const {data} = await $authhost.delete(`api/ColorTemplates/${id}`);
}