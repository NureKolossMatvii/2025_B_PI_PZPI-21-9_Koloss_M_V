import { $authhost } from "."
import { IViewConfig } from "../interfaces/Models/IViewConfig";
import { IValidationConfig } from "../interfaces/Models/Validation/IValidationConfig";
import { SetupEnabledFeaturesDto } from "../Project/components/StepPages/FeaturesEnabling/FeaturesEnabling";

export const saveProjectConfiguration = async (projectConfigurationId: string, viewConfig: IViewConfig) => {
    const {data} = await $authhost.post(`api/ProjectConfiguration/${projectConfigurationId}/ViewConfiguration/save`, viewConfig);
    return data;
}

export const saveValidationConfig = async (projectConfigurationId: string, validationConfig: IValidationConfig) => {
    const {data} = await $authhost.patch(`api/ProjectConfiguration/${projectConfigurationId}/saveValidation`, validationConfig);
}

export const saveEnabledFeatures = async (features: SetupEnabledFeaturesDto) => {
    const {data} = await $authhost.patch(`api/ProjectConfiguration/saveEnabledFeatures`, features)
    return data;
}

export const saveColorTemplate = async (projectConfigurationId: string, colorTemplateId: string) => {
    const {data} = await $authhost.patch(`api/ProjectConfiguration/${projectConfigurationId}/saveColorTemplate/${colorTemplateId}`);
    return data;
}

export const getMVCProjectResult = async (projectConfigurationId: string) => {
    const {data} = await $authhost.get(`api/ProjectConfiguration/${projectConfigurationId}/result/mvc`, {
        responseType: "blob"
    });
    return data;
}