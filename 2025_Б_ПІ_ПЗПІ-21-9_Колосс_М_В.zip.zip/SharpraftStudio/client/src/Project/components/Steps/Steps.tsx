import React from 'react'
import { ProjectCreationStep, projectCreationSteps } from '../../../types/ProjectCreationStep';
import cl from './Steps.module.css';

interface IProps {
    stepIndex: number
    handleChangeStep: (step: ProjectCreationStep) => void
}

export const Steps = ({stepIndex, handleChangeStep}: IProps) => {
  return (
    <div className={cl.steps}>
          {projectCreationSteps.map(({step, label}, index) =>
            <button onClick={() => handleChangeStep(step)} key={step} className={[cl.step, stepIndex === index && cl.active].join(' ')}>{label}</button>
          )}
        </div>
  )
}
