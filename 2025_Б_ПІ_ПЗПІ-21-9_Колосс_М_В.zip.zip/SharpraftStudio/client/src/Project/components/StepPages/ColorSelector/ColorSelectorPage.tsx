import React from 'react'
import { ColorSelector } from '../../../../ColorSelector/ColorSelector'

export const ColorSelectorPage = () => {
  return (
    <ColorSelector />
  )
}
