import React, { useContext, useMemo, useState } from 'react'
import { ProjectContext } from '../../../../..'
import { Arrow } from '../../../../../components/UI/Arrow/Arrow'
import { Button } from '../../../../../components/UI/Button/Button'
import { DefaultInput } from '../../../../../components/UI/Input/DefaultInput'
import { ITableViewConfig } from '../../../../../interfaces/Models/ITableViewConfig'
import { ColumnListConfig } from '../Columns/ColumnListConfig/ColumnListConfig'
import cl from './TableItemConfig.module.css'

interface IProps {
    item: ITableViewConfig
    disabled?:boolean
}

export const TableItemConfig = ({ item, disabled }: IProps) => {
    const { project, viewConfig } = useContext(ProjectContext)!;
    const [labelActive, setLabelActive] = useState<boolean>(false);
    const [tableActive, setTableActive] = useState<boolean>(false);
    const [label, setLabel] = useState<string>(item.label);
    
    const table = useMemo(() => {
        return project?.diagram?.tables.find((table) => table.tableId === item.umlTableId)
    }, [item])

    const handleChangeLabel = () => {
        viewConfig.editTableLabel(item.tableViewConfigurationId, label)
    }

    const toggleTableActive = () => {
        setTableActive(!tableActive)
    }

    const onSetLabelActive = () => setLabelActive(true);
    const onSetLabelInActive = () => {
        handleChangeLabel();
        setLabelActive(false)
    };

  return (
    <div className={cl.block}>
        <div className={cl.title} onClick={toggleTableActive}>
            <div>Table name: <span>{table?.name}</span></div>
            <Arrow active={tableActive} size={15}></Arrow>
        </div>
       {tableActive &&
        <>
         <div className={cl.label}>
            <span>Label:</span>
            <div className={cl.input} onDoubleClick={disabled ? undefined : onSetLabelActive}>
                {labelActive ? 
                    <div style={{display: "flex", gap: 10}}>
                        <DefaultInput disabled={disabled} inputType="text" value={label} setValue={setLabel}></DefaultInput>
                        <Button disabled={disabled} type='button' onClick={onSetLabelInActive}>Save</Button>
                    </div>
                    :
                    <span>{item.label}</span>
                }
            </div>
        </div>
        <ColumnListConfig disabled={disabled} items={item.columnViewConfigs} tableViewConfig={item} />
        </>
       }
    </div>
  )
}
