import React, { useContext, useMemo } from "react";
import { DiagramContext, ProjectContext } from "../../../../../..";
import { IColumnViewConfig } from "../../../../../../interfaces/Models/IColumnViewConfig";
import { UMLTable } from "../../../../../../interfaces/Models/UMLTable";
import { UMLTableColumn } from "../../../../../../interfaces/Models/UMLTableColumn";
import { ColumnItemConfig } from "../ColumnItemConfig/ColumnItemConfig";
import cl from "./ColumnListConfig.module.css";
import { DragDropContext, Droppable, Draggable } from "react-beautiful-dnd";
import { ITableViewConfig } from "../../../../../../interfaces/Models/ITableViewConfig";

interface IProps {
    items: IColumnViewConfig[];
    disabled?: boolean
    tableViewConfig: ITableViewConfig
}

export const ColumnListConfig = ({ items, disabled, tableViewConfig }: IProps) => {
    const { project, viewConfig } = useContext(ProjectContext)!;
    const getCurrentColumn = (umlColumnId: string): UMLTableColumn | undefined => {
        return project?.diagram?.tables?.flatMap(table => table.columns).find(column => column.tableColumnId === umlColumnId);
    };

    const handleDragEnd = (result: any) => {
      if (!result.destination || !project || disabled) return;
      
      const reorderedItems = Array.from(items);
      const [movedItem] = reorderedItems.splice(result.source.index, 1);
      reorderedItems.splice(result.destination.index, 0, movedItem);
  
      viewConfig.setViewConfig({
        ...project?.viewConfig,
        tableViewConfigs: project?.viewConfig.tableViewConfigs.map((item) => {
          if (item.tableViewConfigurationId === tableViewConfig.tableViewConfigurationId) {
            return { ...item, columnViewConfigs: reorderedItems }
          } else {
            return item;
          }
        })
      })

      console.log(reorderedItems)

    };
    
    return (
      <DragDropContext onDragEnd={handleDragEnd}>
        <div className={cl.container}>
          <div className={cl.content}>
            <div className={cl.title}>Columns</div>
            <Droppable droppableId="columns-list">
              {(provided) => (
                <div
                  className={cl.list}
                  {...provided.droppableProps}
                  ref={provided.innerRef}
                >
                  {items.map((item, index) => {
                    const column = getCurrentColumn(item.umlColumnId);
                    if(column) {
                      const table = project?.diagram?.tables.find((table) =>
                      table.columns.includes(column)
                    );
                    return (
                      <Draggable
                        key={item.columnViewConfigurationId}
                        draggableId={item.columnViewConfigurationId.toString()}
                        index={index}
                        isDragDisabled={disabled}
                      >
                        {(provided) => (
                          <div
                            ref={provided.innerRef}
                            {...provided.draggableProps}
                            {...provided.dragHandleProps}
                          >
                            <ColumnItemConfig
                              disabled={disabled}
                              table={table}
                              item={item}
                              column={column}
                            />
                          </div>
                        )}
                      </Draggable>
                    );
                    }
                    
  
                    
                  })}
                  {provided.placeholder}
                </div>
              )}
            </Droppable>
          </div>
        </div>
      </DragDropContext>
    );
  };
