import React, { useContext, useState } from 'react'
import { ProjectContext } from '../../../../../..';
import { Arrow } from '../../../../../../components/UI/Arrow/Arrow';
import { Button } from '../../../../../../components/UI/Button/Button';
import { CustomCheckbox } from '../../../../../../components/UI/CustomCheckbox/CustomCheckbox';
import { DefaultInput } from '../../../../../../components/UI/Input/DefaultInput';
import { IColumnViewConfig } from '../../../../../../interfaces/Models/IColumnViewConfig';
import { IDatasetSelectorRules } from '../../../../../../interfaces/Models/IDatasetSelectorRules';
import { UMLTable } from '../../../../../../interfaces/Models/UMLTable';
import { UMLTableColumn } from '../../../../../../interfaces/Models/UMLTableColumn';
import { columnDataTypes } from '../../../../../../types/UMLColumnDataType';
import cl from './ColumnItemConfig.module.css';

interface IProps {
    item: IColumnViewConfig
    column: UMLTableColumn | undefined
    table: UMLTable | undefined;
    disabled?:boolean
}

export const ColumnItemConfig = ({ item, column, table, disabled }:IProps) => {
    const { viewConfig } = useContext(ProjectContext)!;
    const [labelActive, setLabelActive] = useState<boolean>(false);
    const [columnActive, setColumnActive] = useState<boolean>(false);
    const [label, setLabel] = useState<string>(item.label);

    const onSetLabelActive = () => setLabelActive(true);
    const onSetLabelInActive = () => {
        setLabelActive(false);
        handleChangeLabel();
    }

    const toggleColumn = () => {
        setColumnActive(!columnActive)
    }

    const handleChangeLabel = () => {
        viewConfig.editColumnLabel(item.columnViewConfigurationId, label)
    }

    const handleSortingChange = (value: boolean) => {
        viewConfig.editColumnDataSetSelectorRules(item.columnViewConfigurationId, { ...item.datasetSelectorRules, sortingEnabled: value })
    }

    const handleSearchingChange = (value: boolean) => {
        viewConfig.editColumnDataSetSelectorRules(item.columnViewConfigurationId, { ...item.datasetSelectorRules, searchingEnabled: value })
    }

    const handleFilteringChange = (value: boolean) => {
        viewConfig.editColumnDataSetSelectorRules(item.columnViewConfigurationId, { ...item.datasetSelectorRules, filteringEnabled: value })
    }

  return (
    <div className={cl.content}>
        <div className={cl.title} onClick={toggleColumn}>
            <div>UML column name: <span>{column?.name}</span> | Table: <span>{table?.name}</span></div>
            <Arrow active={columnActive} size={15}></Arrow>
        </div>
      {columnActive &&
       <>
       <div className={cl.label}>
            <span>Label:</span>
            <div className={cl.input} onDoubleClick={disabled ? undefined : onSetLabelActive}>
                {labelActive ? 
                    <div style={{display: "flex", gap: 10}}>
                        <DefaultInput inputType="text" value={label} setValue={setLabel}></DefaultInput>
                        <Button type='button' onClick={onSetLabelInActive}>Save</Button>
                    </div>
                    :
                    <span>{item.label}</span>
                }
            </div>
        </div>
        <div className={cl.controls}>
            <CustomCheckbox disabled={disabled} label="Sorting enabled" styles={checkBoxStyle} size={15} checked={item.datasetSelectorRules.sortingEnabled} onChange={handleSortingChange}></CustomCheckbox>
            {column && columnDataTypes[column?.dataType] === "String" && <CustomCheckbox disabled={disabled} label="Searching enabled" styles={checkBoxStyle} size={15} checked={item.datasetSelectorRules.searchingEnabled} onChange={handleSearchingChange}></CustomCheckbox>}
            {column && columnDataTypes[column?.dataType] !== "String" && <CustomCheckbox disabled={disabled} label="Filtering enabled" styles={checkBoxStyle} size={15} checked={item.datasetSelectorRules.filteringEnabled} onChange={handleFilteringChange}></CustomCheckbox> }
        </div>
       </>
      }
    </div>
  )
}

const checkBoxStyle = {
    fontSize: "14px",
    color: "#FFFFFF",
}
