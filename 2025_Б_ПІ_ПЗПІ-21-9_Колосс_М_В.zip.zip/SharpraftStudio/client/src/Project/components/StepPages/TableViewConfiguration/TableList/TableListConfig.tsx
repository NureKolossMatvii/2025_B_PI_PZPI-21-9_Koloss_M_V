import React, { useContext, useState } from "react";
import { ProjectContext } from "../../../../..";
import { Loader } from "../../../../../components/Loader/Loader";
import { MoveToNextStepModal } from "../../../../../components/MoveToNextStepModal/MoveToNextStepModal";
import { Button } from "../../../../../components/UI/Button/Button";
import { ErrorsModel } from "../../../../../hooks/useDiagram";
import { moveProjectToNextStep } from "../../../../../http/projectApi";
import { ITableViewConfig } from "../../../../../interfaces/Models/ITableViewConfig";
import { TableItemConfig } from "../TableItemConfig/TableItemConfig";
import cl from "./TableListConfig.module.css";
import contextStyle from '../../../../../components/UI/ContextMenu/ContextMenu.module.css';

interface IProps {
  tables: ITableViewConfig[];
  disabled?:boolean
}

export const TableListConfig = ({ tables, disabled }: IProps) => {
  const { project, viewConfig, fetchProject} = useContext(ProjectContext)!;
  const [nextStepModal, setNextStepModal] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [validationErrors, setValidationErrors] = useState<ErrorsModel>({success: true, messages: []})

  const handleOpenNextStepModal = () =>  {
    const tableErrors = viewConfig.validateTables()
    const columnErrors = viewConfig.validateColumns();
    setValidationErrors({
      success: tableErrors.success && columnErrors.success,
      messages: tableErrors.messages.concat(columnErrors.messages)
    })
    setNextStepModal(true);
  }

  const handleCloseNextStepModal = () => setNextStepModal(false);

  const handleSave = async () => {
    setLoading(true);
    await viewConfig.save().finally(() => setLoading(false));
  }

  const fetchProjectData = async () => {
    if (project) {
      setLoading(true);
      await fetchProject(project?.projectConfigurationId).finally(() => setLoading(false));
    }
  }

  const moveToNextStep = async () => {
    if (project) {
      const move = async () => {
        setLoading(true);
        await moveProjectToNextStep(project.projectConfigurationId)
        .then(() => fetchProjectData())
        .finally(() => setLoading(false));
      }

      await handleSave().then(() => move());
    }
  };

  return loading ? (
    <Loader loading={loading} />
  ) : (
    <>
    <MoveToNextStepModal show={nextStepModal} onClose={handleCloseNextStepModal} move={moveToNextStep} disabled={!validationErrors.success}>
        {!validationErrors.success ? 
        <>
          <div className={contextStyle.errorTitle}>There are some errors in your configuration. To move to the next step you need to solve problems</div>
          <div className={contextStyle.errorDescription}>Errors:</div>
          <div className={contextStyle.errors}>
            {validationErrors.messages.map((error) => 
              <div className={contextStyle.error}>{error}</div>
            )}
          </div>
        </>
        :
        undefined
        }
        </MoveToNextStepModal>
    <div className={cl.list}>
      <div className={cl.title}>
        <span>Tables</span>
       <div className={cl.buttons}>
        <Button onClick={handleSave} disabled={disabled} style={{ width: "auto", textWrap: "nowrap" }} type="button">
            Save configurations
          </Button>
          <Button type="button" disabled={disabled} onClick={handleOpenNextStepModal}>
                    Move to next step
                </Button>
       </div>
      </div>
      {tables.map((table) => (
        <TableItemConfig disabled={disabled} key={table.tableViewConfigurationId} item={table} />
      ))}
    </div>
    </>
  );
};
