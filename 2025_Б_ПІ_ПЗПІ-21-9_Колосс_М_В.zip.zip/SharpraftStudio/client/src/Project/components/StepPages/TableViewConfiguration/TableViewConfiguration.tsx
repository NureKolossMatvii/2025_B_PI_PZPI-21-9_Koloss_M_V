import React, { useContext } from 'react'
import { ProjectContext } from '../../../..';
import { TableListConfig } from './TableList/TableListConfig';

interface IProps {
  disabled?: boolean
}

export const TableViewConfiguration = ({disabled}:IProps) => {
  const { project } = useContext(ProjectContext)!;
  return (
    <div>
        {project?.viewConfig && <TableListConfig disabled={disabled} tables={project?.viewConfig.tableViewConfigs} />}
    </div>
  )
}
