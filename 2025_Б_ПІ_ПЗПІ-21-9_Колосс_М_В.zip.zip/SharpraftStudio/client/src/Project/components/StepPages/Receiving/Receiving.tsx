import React, { ReactElement, useContext, useRef } from 'react'
import { ClientTextInfoContext, DiagramContext, ProjectContext } from '../../../..'
import { Button } from '../../../../components/UI/Button/Button'
import { howToDownloadTextKey } from '../../../../consts'
import { getMVCProjectResult } from '../../../../http/projectConfigurationApi'
import { UmlArea } from '../../../../UmlCreator/components/UmlArea/UmlArea'
import { downloadComponentAsImage } from '../../../../utils/downloadComponentAsImage'
import cl from './Receiving.module.css';
import HTMLReactParser from 'html-react-parser';

export const Receiving = () => {
    const { project } = useContext(ProjectContext)!;
    const {clientTextInfo} = useContext(ClientTextInfoContext)!;

    const handleDownloadMVCProject = async () => {
        if (project) {
            await getMVCProjectResult(project.projectConfigurationId).then((data) => {
                var blob = new Blob([data], {
                    type: "text/plain;charset=utf-8",
                  });
                
                  const url = window.URL.createObjectURL(blob)
                  const link = document.createElement('a');
                  link.href = url;
                  link.download = `SCS_${project.name}.zip`;
                  document.body.appendChild(link);
                  link.click();
                  document.body.removeChild(link);
                  URL.revokeObjectURL(url);
            });
        }
    }

    const renderText = () => {
      const text = clientTextInfo.find(({key}) => key === howToDownloadTextKey)
      return HTMLReactParser(text?.engLabel || '')
    }

  return (
    <div className={cl.container}>
      <div className={cl.content}>
        <div><Button type='button' style={{width: "auto"}} onClick={handleDownloadMVCProject}>Download MVC project</Button> </div>
        <div><Button type='button' style={{width: "auto"}} onClick={handleDownloadMVCProject}>Download React project</Button></div> 
        <div className={cl.textContent}>
          {renderText()}
        </div>
      </div>
    </div>
  )
}
