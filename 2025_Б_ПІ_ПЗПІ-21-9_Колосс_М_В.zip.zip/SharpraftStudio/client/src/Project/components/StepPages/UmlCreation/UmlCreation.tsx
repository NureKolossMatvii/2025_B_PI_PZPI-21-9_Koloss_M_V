import React from "react";
import { DiagramContext } from "../../../..";
import { useDiagram } from "../../../../hooks/useDiagram";
import { UmlCreator } from "../../../../UmlCreator/components/UmlCreator/UmlCreator";

interface IProps {
  disabled?:boolean
}

export const UmlCreation = ({disabled}:IProps) => {
    const diagramValue = useDiagram();

  return (
    <DiagramContext.Provider value={diagramValue}>
      <UmlCreator disabled={disabled}></UmlCreator>
    </DiagramContext.Provider>
  );
};
