import React, { useContext, useState } from "react";
import { ProjectContext } from "../../../../..";
import { Loader } from "../../../../../components/Loader/Loader";
import { MoveToNextStepModal } from "../../../../../components/MoveToNextStepModal/MoveToNextStepModal";
import { Button } from "../../../../../components/UI/Button/Button";
import { moveProjectToNextStep } from "../../../../../http/projectApi";
import { ITableViewConfig } from "../../../../../interfaces/Models/ITableViewConfig";
import { UMLTable } from "../../../../../interfaces/Models/UMLTable";
import { ITableValidationConfig } from "../../../../../interfaces/Models/Validation/IValidationConfig";
import { TableItemValidation } from "../TableItemValidation/TableItemValidation";
import cl from "./TableListConfig.module.css";

interface IProps {
  tableValidationConfigs: ITableValidationConfig[];
  projectId: string | undefined;
  disabled?: boolean
}

export const TableListValidation = ({ tableValidationConfigs, projectId, disabled }: IProps) => {
  const { validationConfig, project, fetchProject } = useContext(ProjectContext)!;
  const [nextStepModal, setNextStepModal] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const handleSave = async () => {
    setLoading(true);
    if (projectId) {
      await validationConfig.saveValidation().finally(() => setLoading(false));
    }
  }
  
  const handleOpenNextStepModal = () => setNextStepModal(true);

  const handleCloseNextStepModal = () => setNextStepModal(false);

  const fetchProjectData = async () => {
    if (project) {
      setLoading(true);
      await fetchProject(project?.projectConfigurationId).finally(() => setLoading(false));
    }
  }

  const moveToNextStep = async () => {
    if (project) {
      const move = async () => {
        setLoading(true);
        await moveProjectToNextStep(project.projectConfigurationId)
        .then(() => fetchProjectData())
        .finally(() => setLoading(false));
      }

      await handleSave().then(() => move());
    }
  };

  return  (
    <>
    <Loader loading={loading} />
    <MoveToNextStepModal show={nextStepModal} onClose={handleCloseNextStepModal} move={moveToNextStep}></MoveToNextStepModal>
    <div className={cl.list}>
      <div className={cl.title}>
        <span>Tables</span>
       <div className={cl.buttons}>
          <Button onClick={handleSave} style={{ width: "auto", textWrap: "nowrap" }} type="button" disabled={disabled}>Save validation</Button>
          <Button type="button" onClick={handleOpenNextStepModal} disabled={disabled}>Move to next step</Button>
       </div>
      </div>
      {tableValidationConfigs.map((tableValidationConfig) => (
        <TableItemValidation disabled={disabled} key={tableValidationConfig.tableValidationConfigurationId} tableValidationConfig={tableValidationConfig}/>
      ))}
    </div>
    </>
  );
};
