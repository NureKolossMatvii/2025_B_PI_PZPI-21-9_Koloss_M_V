import React, { useMemo, useContext } from "react";
import { ProjectContext } from "../../../../..";
import { Button } from "../../../../../components/UI/Button/Button";
import { CustomCheckbox } from "../../../../../components/UI/CustomCheckbox/CustomCheckbox";
import { DefaultInput } from "../../../../../components/UI/Input/DefaultInput";
import { Modal } from "../../../../../components/UI/Modal/Modal";
import { UMLTableColumn } from "../../../../../interfaces/Models/UMLTableColumn";
import {
  IColumnValidationConfig,
  IValidationView,
  validationList,
} from "../../../../../interfaces/Models/Validation/IValidationConfig";
import { columnDataTypes } from "../../../../../types/UMLColumnDataType";
import { ValidationType, validationTypes } from "../../../../../types/ValidationType";
import cl from "./EditColumnModal.module.css";
import RenderInputs from "./RenderInputs";

interface IProps {
  onHide: () => void;
  show: boolean;
  columnValidationConfig: IColumnValidationConfig;
  column: UMLTableColumn | undefined
}

export type ParameterType = "firstParameter" | "secondParameter" | "message";

export const EditColumnModal = ({ onHide, show, columnValidationConfig, column }: IProps) => {
  const { validationConfig, project, updateProject } = useContext(ProjectContext)!;
  
  const normalizeValidationList = useMemo(() => {
    if (column) {
      return validationList.filter((item) => item.dataTypes.includes(columnDataTypes[column.dataType]));
    }

    return []
  }, []);

  const handleCheckBoxChange = (type: ValidationType) => validationConfig.toggleValidation(columnValidationConfig.columnValidationConfigurationId, type)

  const isChecked = (validationView: IValidationView) => {
    return (
      columnValidationConfig.validation.find(
        (validation) => validationTypes[validation.type] === validationView.type
      ) !== undefined
    );
  };

  const handleValidationChange = (type: ValidationType, field: ParameterType, value: string) => {
   if (project?.validationConfig) {
    const updatedProject = {
      ...project,
      validationConfig: {
          ...project.validationConfig,
          tableValidationConfigs: project.validationConfig.tableValidationConfigs.map((tableConfig) => ({
              ...tableConfig,
              columnValidationConfigs: tableConfig.columnValidationConfigs.map((columnConfig) => ({
                  ...columnConfig,
                  validation: columnConfig.validation.map((validation) =>
                      validationTypes[validation.type] === type
                          ? { ...validation, [field]: value } 
                          : validation
                  ),
              })),
          })),
      },
  };

  updateProject(updatedProject);
   }
};

return (
  <Modal onClose={onHide} show={show} title="Edit column">
      <div className={cl.container}>
          <div className={cl.items}>
              {normalizeValidationList.map((validationView) => {
                  const currentValidation = columnValidationConfig.validation.find((validation) => validationTypes[validation.type] === validationView.type)
                   || { type: validationTypes.indexOf(validationView.type), message: "", firstParameter: "", secondParameter: "" };

                  return !column?.isForeignKey && (
                      <div key={validationView.type} className={cl.item}>
                          <CustomCheckbox
                              label={validationView.label}
                              styles={checkBoxStyle}
                              size={15}
                              checked={isChecked(validationView)}
                              onChange={() => handleCheckBoxChange(validationView.type)}
                          />
                          {isChecked(validationView) && (
                              <RenderInputs
                                  validation={currentValidation}
                                  onChange={(field, value) => handleValidationChange(validationView.type, field, value)}
                              />
                          )}
                      </div>
                  );
              })}
          </div>
      </div>
  </Modal>
);
};

const checkBoxStyle = {
  fontSize: "14px",
  color: "#FFFFFF",
};
