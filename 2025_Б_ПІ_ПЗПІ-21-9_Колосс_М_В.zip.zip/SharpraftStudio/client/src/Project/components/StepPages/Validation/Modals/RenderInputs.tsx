import React from 'react';
import { DefaultInput } from '../../../../../components/UI/Input/DefaultInput';
import { IValidation } from '../../../../../interfaces/Models/Validation/IValidationConfig';
import { validationTypes } from '../../../../../types/ValidationType';
import { ParameterType } from './EditColumnModal';
import {UMLTableColumn} from '../../../../../interfaces/Models/UMLTableColumn';

interface RenderInputsProps {
    validation: IValidation;
    onChange: (field: ParameterType, value: string) => void;
}

const RenderInputs: React.FC<RenderInputsProps> = ({ validation, onChange }) => {
    switch (validation.type) {
        case validationTypes.indexOf("Range"):
            return (
                <div style={{display: "flex", flexDirection: "column", gap: "20px"}}>
                    <DefaultInput label="Message" value={validation.message} inputType='text' setValue={(value) => onChange("message", value)}/>
                    <div style={{display: "flex", justifyContent: "space-between", gap: "20px"}}>
                        <DefaultInput label="Minimum" value={validation.firstParameter} inputType='number' setValue={(value) => onChange("firstParameter", value)}/>
                        <DefaultInput label="Maximum" value={validation.secondParameter} inputType='number' setValue={(value) => onChange("secondParameter", value)}/>
                    </div>
                </div>
            );
        
        case validationTypes.indexOf("MinLength"):
        case validationTypes.indexOf("MaxLength"):
            return (
                <div style={{display: "flex", flexDirection: "column", gap: "20px"}}>
                    <DefaultInput label="Message" value={validation.message} inputType='text' setValue={(value) => onChange("message", value)}/>
                    <DefaultInput label="Minimum" value={validation.firstParameter} inputType='number' setValue={(value) => onChange("firstParameter", value)}/>
                </div>
            );
        
        default:
            return <DefaultInput label="Message" value={validation.message} inputType='text' setValue={(value) => onChange("message", value)}/>
    }
};

export default RenderInputs;