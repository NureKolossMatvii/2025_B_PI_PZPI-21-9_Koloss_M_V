import React, { useContext, useState, useEffect } from 'react'
import { useParams } from 'react-router-dom';
import { ProjectContext } from '../../../..';
import { TableListValidation } from './TableList/TableListValidation'

interface IProps {
  disabled?: boolean
}

export const Validation = ({disabled}: IProps) => {
    const { fetchProject, project } = useContext(ProjectContext)!;
    const { projectId } = useParams();
  
    useEffect(() => {
      if (projectId) {
        fetchProject(projectId);
      }
    }, [projectId]);

  return (
    <div>
        {project?.validationConfig && <TableListValidation disabled={disabled} tableValidationConfigs={project?.validationConfig?.tableValidationConfigs} projectId={projectId}></TableListValidation>}
    </div>
  )
}
