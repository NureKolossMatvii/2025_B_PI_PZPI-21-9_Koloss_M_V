import React, { useState, useContext, useMemo } from "react";
import { ProjectContext } from "../../../../..";
import { Arrow } from "../../../../../components/UI/Arrow/Arrow";
import { ITableValidationConfig } from "../../../../../interfaces/Models/Validation/IValidationConfig";
import { ColumnListValidation } from "../Columns/ColumnListValidation/ColumnListValidation";
import cl from "./TableItemValidation.module.css";

interface IProps {
  tableValidationConfig: ITableValidationConfig;
  disabled?: boolean
}

export const TableItemValidation = ({ tableValidationConfig, disabled }: IProps) => {
  const [tableActive, setTableActive] = useState<boolean>(false);
  const { project } = useContext(ProjectContext)!;
  
  const table = useMemo(() => {
      return project?.diagram?.tables.find((table) => table.tableId === tableValidationConfig.umlTableId)
  }, [tableValidationConfig])

  const toggleTableActive = () => {
    setTableActive(!tableActive);
  };

  return (
    <div className={cl.block}>
      <div className={cl.title} onClick={toggleTableActive}>
        <div>
          Table name: <span>{table?.name}</span>
        </div>
        <Arrow active={tableActive} size={15}></Arrow>
      </div>
      {(tableActive) && (
          <ColumnListValidation disabled={disabled} columnValidationConfigs={tableValidationConfig.columnValidationConfigs} />
      )}
    </div>
  );
};
