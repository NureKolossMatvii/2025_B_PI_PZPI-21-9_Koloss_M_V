import React, { useContext, useMemo } from "react";
import { ProjectContext } from "../../../../../..";
import { UMLTableColumn } from "../../../../../../interfaces/Models/UMLTableColumn";
import { IColumnValidationConfig } from "../../../../../../interfaces/Models/Validation/IValidationConfig";
import { ColumnItemValidation } from "../ColumnItemValidation/ColumnItemValidation";
import cl from "./ColumnListValidation.module.css";

interface IProps {
  columnValidationConfigs: IColumnValidationConfig[];
  disabled?: boolean
}

export const ColumnListValidation = ({ columnValidationConfigs, disabled }: IProps) => {
  const { project } = useContext(ProjectContext)!;
  const getCurrentColumn = (
    umlColumnId: string
  ): UMLTableColumn | undefined => {
    return project?.diagram?.tables
      ?.flatMap((table) => table.columns)
      .find((column) => column.tableColumnId === umlColumnId);
  };

  return (
    <div className={cl.container}>
      <div className={cl.content}>
        {columnValidationConfigs.length ? (
          <>
            <div className={cl.title}>Columns</div>
            <div className={cl.list}>
              {columnValidationConfigs.map((columnValidationConfig) => {
                return (
                  <ColumnItemValidation
                  disabled={disabled}
                    columnValidationConfig={columnValidationConfig}
                    column={getCurrentColumn(
                      columnValidationConfig.umlColumnId
                    )}
                  />
                );
              })}
            </div>
          </>
        ) : (
          <div className={cl.title}>No settings</div>
        )}
      </div>
    </div>
  );
};
