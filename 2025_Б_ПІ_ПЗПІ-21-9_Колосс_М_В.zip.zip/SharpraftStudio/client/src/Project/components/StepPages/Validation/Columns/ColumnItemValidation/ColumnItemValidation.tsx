import React, { useMemo, useState } from 'react'
import { Arrow } from '../../../../../../components/UI/Arrow/Arrow';
import { Button } from '../../../../../../components/UI/Button/Button';
import { UMLTableColumn } from '../../../../../../interfaces/Models/UMLTableColumn';
import { IColumnValidationConfig } from '../../../../../../interfaces/Models/Validation/IValidationConfig';
import { validationTypes } from '../../../../../../types/ValidationType';
import { EditColumnModal } from '../../Modals/EditColumnModal';
import cl from './ColumnItemValidation.module.css';

interface IProps {
    columnValidationConfig: IColumnValidationConfig,
    column: UMLTableColumn | undefined
    disabled?: boolean
}

export const ColumnItemValidation = ({ columnValidationConfig, column, disabled }:IProps) => {
    const [columnActive, setColumnActive] = useState<boolean>(false);
    const [editModal, setEditModal] = useState<boolean>(false);

    const handleCloseEditModal = () => setEditModal(false);
    const handleOpenEditModal = () => setEditModal(true)

    const toggleColumn = () => {
        setColumnActive(!columnActive)
    }

  return (
    <div className={cl.content}>
        <EditColumnModal show={editModal} onHide={handleCloseEditModal} columnValidationConfig={columnValidationConfig} column={column}></EditColumnModal>
        <div className={cl.title} onClick={toggleColumn}>
            <div>UML column name: <span>{column?.name}</span></div>
            <Arrow active={columnActive} size={15}></Arrow>
        </div>
      {columnActive &&
       <>
        <div className={cl.validation}>Valdidations: {columnValidationConfig?.validation.map((validation) => validationTypes[validation.type]).join(", ")}</div>
        {!column?.isForeignKey &&
          <div className={cl.controlsLabel}>
            <Button style={{width: 'auto'}} type="button" onClick={handleOpenEditModal} disabled={disabled}>Edit</Button>
          </div>
        }
       </>
      }
    </div>
  )
}
