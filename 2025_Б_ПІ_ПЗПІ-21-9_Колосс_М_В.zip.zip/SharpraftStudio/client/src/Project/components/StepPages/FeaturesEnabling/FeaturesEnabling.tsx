import React, { useState, useContext, useEffect } from "react";
import { useForm } from "react-hook-form";
import { ProjectContext } from "../../../..";
import { FormLayout } from "../../../../components/FormLayout/FormLayout";
import { Loader } from "../../../../components/Loader/Loader";
import { Button } from "../../../../components/UI/Button/Button";
import { CustomCheckbox } from "../../../../components/UI/CustomCheckbox/CustomCheckbox";
import { Input } from "../../../../components/UI/Input/Input";
import {
  moveProjectToNextStep,
} from "../../../../http/projectApi";
import { saveEnabledFeatures } from "../../../../http/projectConfigurationApi";
import cl from "./FeaturesEnabling.module.css";

export interface SetupEnabledFeaturesDto {
  projectId: string;
  authorizationEnabled: boolean;
  userTableName: string;
}

interface IProps {
  disabled: boolean
}

export const FeaturesEnabling = ({disabled}:IProps) => {
  const {
    handleSubmit,
    setValue,
    control,
    formState: { errors },
  } = useForm<SetupEnabledFeaturesDto>();
  const [authorizationEnabled, setAuthorizationEnabled] =
    useState<boolean>(false);
  const { project, fetchProject} = useContext(ProjectContext)!;
  const [loading, setLoading] = useState<boolean>(false)

  useEffect(() => {
    if (project?.enabledFeatures) {
      setAuthorizationEnabled(project?.enabledFeatures?.authorizationEnabled);
      setValue("userTableName", project.enabledFeatures.userTableName);
    }
  }, [project?.enabledFeatures]);

  const saveFeatures = async (data: SetupEnabledFeaturesDto) => {
    setLoading(true);
    data.authorizationEnabled = authorizationEnabled;
    if (project) {
      data.projectId = project?.projectConfigurationId;
    }

    await saveEnabledFeatures(data).finally(() => setLoading(false));
  };

  const fetchProjectData = async () => {
    if (project) {
      setLoading(true);
      await fetchProject(project?.projectConfigurationId).finally(() => setLoading(false));
    }
  }

  const onAuthorizationEnabledChange = (val: boolean) => {
    setValue("userTableName", "");
    setAuthorizationEnabled(val);
  };

  const moveToNextStep = async () => {
    if (project) {
      setLoading(true);
      await moveProjectToNextStep(project.projectConfigurationId)
      .then(() => fetchProjectData())
      .finally(() => setLoading(false));
    }
  };

  return (
   <>
    <Loader loading={loading}/>
    <div className={cl.container}>
      <div className={cl.content}>
        <div>
        <div className={cl.title}>Enable features in the project</div>
        <FormLayout onSubmit={handleSubmit(saveFeatures)}>
          <div className={cl.items}>
            <div className={cl.item}>
              <CustomCheckbox
                disabled={disabled}
                onChange={onAuthorizationEnabledChange}
                checked={authorizationEnabled}
                label="Authorization enabled"
                styles={checkBoxStyles}
                size={20}
              ></CustomCheckbox>
              {authorizationEnabled && (
                <Input
                  disabled={disabled}
                  control={control}
                  label="User table name"
                  inputType="text"
                  name="userTableName"
                  errorMessage={errors.userTableName?.message}
                  rules={{
                    required: "Name is required",
                    maxLength: {
                      value: 20,
                      message: "Max length should be under 20 chars",
                    },
                  }}
                ></Input>
              )}
            </div>
          </div>

          <div style={{display: "flex", justifyContent: "flex-end"}}><Button disabled={disabled} style={{width: "auto"}} type="submit">Save</Button></div>
        </FormLayout>
        </div>
        <div className={cl.nextStep}>
            <Button style={{maxWidth: 200}} disabled={disabled} onClick={moveToNextStep} type="button">
              Move to text step
            </Button>
          </div>
      </div>
    </div>
    </>
  );
};

const checkBoxStyles = {
  color: "var(--white-color)",
  fontSize: "16px",
};
