import React, { ReactNode, useContext, useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';
import { DiagramContext, ProjectContext } from '../../..';
import { ColorSelector } from '../../../ColorSelector/ColorSelector';
import { Navbar } from '../../../components/Navbar/Navbar';
import { useDiagram } from '../../../hooks/useDiagram';
import { ProjectCreationStep } from '../../../types/ProjectCreationStep';
import { ColorSelectorPage } from '../../components/StepPages/ColorSelector/ColorSelectorPage';
import { FeaturesEnabling } from '../../components/StepPages/FeaturesEnabling/FeaturesEnabling';
import { Receiving } from '../../components/StepPages/Receiving/Receiving';
import { TableViewConfiguration } from '../../components/StepPages/TableViewConfiguration/TableViewConfiguration';
import { UmlCreation } from '../../components/StepPages/UmlCreation/UmlCreation';
import { Validation } from '../../components/StepPages/Validation/Validation';
import { Steps } from '../../components/Steps/Steps';
import cl from './Project.module.css';

interface ProjectStep {
  step: ProjectCreationStep,
  node: ReactNode,
}

export const Project = () => {
  const {project, fetchProject} = useContext(ProjectContext)!;
  const [currentStep, setCurrentStep] = useState<number | undefined>(project?.step);
  const { projectId } = useParams();

  const isDifferentStep = currentStep !== project?.step;


  const steps: ProjectStep[] = [
    {step: "FeaturesEnabling", node: <FeaturesEnabling disabled={isDifferentStep} />},
    {step: "UmlCreation", node: <UmlCreation disabled={isDifferentStep} />},
    {step: "TableViewConfiguration", node: <TableViewConfiguration disabled={isDifferentStep} />},
    {step: "Validation", node: <Validation disabled={isDifferentStep} />},
    {step: "ColorsSelection", node: <ColorSelector disabled={isDifferentStep}></ColorSelector>},
    {step: "Receiving", node: <Receiving />},
  ]

  const handleChangeStep = (selectedStep: ProjectCreationStep) => {
    if (project) {
      const selectedStepIndex = steps.findIndex(({ step }) => step === selectedStep);
      if (selectedStepIndex !== -1 && selectedStepIndex <= project.step) {
        setCurrentStep(selectedStepIndex);
      }
    }
  };

  useEffect(() => {
    if (projectId) {
      fetchProject(projectId);
    }
  }, [projectId])

  useEffect(() => {
    setCurrentStep(project?.step)
  }, [project?.step])
  
  return (
    <Navbar>
      <div className={cl.wrapper}>
        {(currentStep !== undefined) && <Steps handleChangeStep={handleChangeStep} stepIndex={currentStep}></Steps>}
        {(currentStep !== undefined) && steps[currentStep].node}
    </div>
    </Navbar>
  )
}
