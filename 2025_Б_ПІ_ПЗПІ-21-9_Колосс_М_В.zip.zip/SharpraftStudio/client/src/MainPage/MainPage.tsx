import React, { useContext, useState } from 'react'
import { Navbar } from '../components/Navbar/Navbar'
import cl from './MainPage.module.css';
import HTMLReactParser from 'html-react-parser';
import { ClientTextInfoContext } from '..';
import { Loader } from '../components/Loader/Loader';
import { mainTextKey } from '../consts';

export const MainPage = () => {
  const {clientTextInfo} = useContext(ClientTextInfoContext)!;
  const [loading, setLoading] = useState<boolean>(false);

  const renderText = () => {
    const text = clientTextInfo.find(({key}) => key === mainTextKey)
    return HTMLReactParser(text?.engLabel || '')
  }

  return (
   <>
   <Loader loading={loading}></Loader>
    <Navbar>
      <div className={cl.container}>
        {renderText()}
      </div>
    </Navbar>
   </>
  )
}
