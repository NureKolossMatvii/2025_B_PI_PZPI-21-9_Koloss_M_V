import { createContext } from "react";
import ReactDOM from "react-dom/client";
import { App } from "./App";
import { IClientTextInfoContextProps } from "./interfaces/Hooks/IClientTextInfoContextProps";
import { IContextMenuHookProps } from "./interfaces/Hooks/IContextMenuHookProps";
import { IDiagramHookProps } from "./interfaces/Hooks/IDiagramHookProps";
import { IProjectHookProps } from "./interfaces/Hooks/IProjectHookProps";
import { IUserSessionHookProps } from "./interfaces/Hooks/IUserSessionHookProps";

const root = ReactDOM.createRoot(
  document.getElementById("root") as HTMLElement
);

export const UserSessionContext = createContext<IUserSessionHookProps | null>(null);
export const DiagramContext = createContext<IDiagramHookProps | null>(null);
export const ProjectContext = createContext<IProjectHookProps | null>(null);
export const ContextMenuContext = createContext<IContextMenuHookProps | null>(null);
export const ClientTextInfoContext = createContext<IClientTextInfoContextProps | null>(null);

root.render(
  <App />
);
