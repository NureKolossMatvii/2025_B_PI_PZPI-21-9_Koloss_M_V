import React, { useState, useEffect, useMemo } from 'react'
import { Button } from '../../../components/UI/Button/Button';
import { Modal } from '../../../components/UI/Modal/Modal';
import { UMLDiagram } from '../../../interfaces/Models/UMLDiagram';
import { ProjectCreateForm } from '../../components/ProjectCreateForm/ProjectCreateForm';
import { ProjectItem } from '../../components/ProjectItem/ProjectItem';
import cl from './ProjectViewer.module.css';
import { IProject } from '../../../interfaces/Models/IProject';
import { ProjectService } from '../../../Services/ProjectService';
import { MouseEvent } from 'react';
import { Loader } from '../../../components/Loader/Loader';
import { removeProject } from '../../../http/projectApi';
import { iconAddDark } from '../../../assets'
import { Navbar } from '../../../components/Navbar/Navbar';
import { ProjectFiltration } from '../../components/ProjectFiltration/ProjectFiltration';

export const ProjectViewer = () => {
    const [userProjects, setUserProjects] = useState<IProject[]>([]);
    const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
    const [loading, setLoading] = useState<boolean>(false);
    const projectService = new ProjectService();
    const [searchText, setSearchText] = useState<string>("");
    
    const filteredProjects = useMemo(() => {
      return userProjects.filter((project) =>
        project.name.toLowerCase().includes(searchText.toLowerCase())
      );
    }, [userProjects, searchText]);

    const handleCloseCreateModal = () => setShowCreateModal(false);
    const handleShowCreateModal = () => setShowCreateModal(true);

    const fetchProjects = async () => {
      setLoading(true);
      await projectService.getAll().then((data) => setUserProjects(data)).catch((error) => console.error(error)).finally(() => setLoading(false))
    };

    const remove = async (event: MouseEvent, projectId: string) => {
      setLoading(true);
      event.preventDefault();
      await removeProject(projectId)
      .then(() => fetchProjects())
      .finally(() => setLoading(false));
    }

    useEffect(() => {
      fetchProjects();
    }, [])
    
  return (
   <Navbar>
   <Loader loading={loading}/>
    <div className={cl.container}>
      <Modal
        onClose={handleCloseCreateModal}
        show={showCreateModal}
        title="Create new project"
      >
        <ProjectCreateForm
          fetchItems={fetchProjects}
          handleCloseCreateModal={handleCloseCreateModal}
        ></ProjectCreateForm>
      </Modal>
      <ProjectFiltration searchText={searchText} setSearchText={setSearchText} />
      <div className={cl.items}>
        {filteredProjects .map((project) => 
          <ProjectItem key={project.projectConfigurationId} project={project} remove={(e) => remove(e, project.projectConfigurationId)}></ProjectItem>
        )}
        <div className={cl.creator} onClick={handleShowCreateModal}><img src={iconAddDark} alt="" /></div>
      </div>
    </div>
   </Navbar>
  )
}
