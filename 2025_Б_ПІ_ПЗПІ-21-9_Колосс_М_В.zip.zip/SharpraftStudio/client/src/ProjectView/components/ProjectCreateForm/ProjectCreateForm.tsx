import React, { useContext } from "react";
import { useForm } from "react-hook-form";
import uuid from "react-uuid";
import { ProjectContext } from "../../..";
import { FormLayout } from "../../../components/FormLayout/FormLayout";
import { Button } from "../../../components/UI/Button/Button";
import { Input } from "../../../components/UI/Input/Input";
import { saveUmlDiagram } from "../../../http/umlApi";
import { IProjectCreationDto } from "../../../interfaces/Dto/IProjectCreationDto";
import { isValidNamespace } from "../../../utils/isValidNamespace";

interface IProps {
  fetchItems: () => void;
  handleCloseCreateModal: () => void;
}

export const ProjectCreateForm = ({
  fetchItems,
  handleCloseCreateModal,
}: IProps) => {
  const {
    handleSubmit,
    control,
    formState: { errors },
  } = useForm<IProjectCreationDto>();
  const {createNewProject} = useContext(ProjectContext)!;

  const createProject = async (data: IProjectCreationDto) => {
    const newProject: IProjectCreationDto = {
      ...data,
      projectConfigurationId: uuid(),
    };

    await createNewProject(newProject).then(() => {
      fetchItems();
      handleCloseCreateModal();
    }).catch((error) => console.error(error));
  };

  return (
    <div>
      <FormLayout onSubmit={handleSubmit(createProject)}>
        <Input
          control={control}
          label="Project name"
          inputType="text"
          name="name"
          errorMessage={errors.name?.message}
          rules={{
            validate: {
              isValidNamespace: (value) =>
                isValidNamespace(value) || "Invalid project name. Check the naming rules.",
            },
            required: "Name is required",
            maxLength: {
              value: 20,
              message: "Max length should be under 20 chars",
            },
          }}
        ></Input>
        <Button type="submit">Create</Button>
      </FormLayout>
    </div>
  );
};
