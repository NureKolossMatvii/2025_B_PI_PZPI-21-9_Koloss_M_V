import React, { MouseEvent } from 'react'
import { NavLink } from 'react-router-dom';
import { Button } from '../../../components/UI/Button/Button';
import { IProject } from '../../../interfaces/Models/IProject';
import { PROJECT_CREATOR_ROUTE } from '../../../routesConsts';
import { projectCreationSteps } from '../../../types/ProjectCreationStep';
import { normalizeDate } from '../../../utils/normalizeDate';
import cl from './ProjectItem.module.css';

interface IProps {
    project: IProject,
    remove: (e: MouseEvent) => void
}

export const ProjectItem = ({project, remove}: IProps) => {
  return (
    <NavLink to={PROJECT_CREATOR_ROUTE + `/${project.projectConfigurationId}`} className={cl.item}>
        <div className={cl.title}>{project.name}</div>
        <div className={cl.tables}>Tables: {project.diagram?.tables.length}</div>
        <div className={cl.step}>Step: {projectCreationSteps[project.step].label}</div>
        <div className={cl.date}>Created: {normalizeDate(project.creationDate)}</div>
        <div className={cl.remove}><Button theme='red' onClick={(e) => remove(e)} type="button">Remove</Button></div>
    </NavLink>
  )
}
