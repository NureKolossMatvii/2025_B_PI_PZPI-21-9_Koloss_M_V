import React, { useState } from 'react'
import { DefaultInput } from '../../../components/UI/Input/DefaultInput'
import cl from './ProjectFiltration.module.css';

interface IProps {
    searchText: string;
    setSearchText: (value: string) => void;
  }

export const ProjectFiltration = ({searchText, setSearchText}:IProps) => {
  return (
    <div className={cl.content}>
        <DefaultInput label="Project name" value={searchText} setValue={setSearchText} inputType='text'/>
    </div>
  )
}
