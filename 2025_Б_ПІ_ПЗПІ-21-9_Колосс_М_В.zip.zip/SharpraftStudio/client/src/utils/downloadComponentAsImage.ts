
import html2canvas from 'html2canvas';
import {ReactElement} from 'react';
import { renderToString } from 'react-dom/server'
import { toJpeg } from "html-to-image";

export const downloadComponentAsImage = async (element: ReactElement, projectName: string = 'project'): Promise<string> => {
    try {
      const dataUrl = await toJpeg(element.props.areaRef.current, { cacheBust: false });
      return dataUrl;
    } catch (err) {
      console.error('Error generating image:', err);
      throw err;
    }
  };