export const reservedKeywords = new Set([
    "abstract", "as", "base", "bool", "break", "byte", "case", "catch",
    "char", "checked", "class", "const", "continue", "decimal", "default",
    "delegate", "do", "double", "else", "enum", "event", "explicit",
    "extern", "false", "finally", "fixed", "float", "for", "foreach",
    "goto", "if", "implicit", "in", "int", "interface", "internal",
    "is", "lock", "long", "namespace", "new", "null", "object", "operator",
    "out", "override", "params", "private", "protected", "public", "readonly",
    "ref", "return", "sbyte", "sealed", "short", "sizeof", "stackalloc", "static",
    "string", "struct", "switch", "this", "throw", "true", "try", "typeof",
    "uint", "ulong", "unchecked", "unsafe", "ushort", "using", "virtual",
    "void", "volatile", "while"
  ]);

  export const isValidNamespace = (value: string): boolean => {
    if (!value || value.length === 0) return false; // Проверка на пустую строку
  
    // Проверка, что название начинается с буквы или "_"
    const startsWithValidChar = /^[a-zA-Z_]/.test(value);
    if (!startsWithValidChar) return false;
  
    // Проверка, что все символы допустимы (буквы, цифры, "_")
    const containsOnlyValidChars = /^[a-zA-Z0-9_]+$/.test(value);
    if (!containsOnlyValidChars) return false;
  
    // Проверка, что название не является зарезервированным словом
    if (reservedKeywords.has(value.toLocaleLowerCase())) return false;
  
    return true; // Все проверки пройдены
  };