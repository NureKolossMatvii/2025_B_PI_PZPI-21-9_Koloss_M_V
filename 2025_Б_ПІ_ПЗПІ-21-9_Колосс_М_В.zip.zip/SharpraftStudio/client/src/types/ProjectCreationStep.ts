import { IProjectStepViewer } from "../interfaces/IProjectStepViewer";

export type ProjectCreationStep = "FeaturesEnabling" | "UmlCreation" | "TableViewConfiguration" | "Validation" | "ColorsSelection" | "Receiving";
export const projectCreationSteps:IProjectStepViewer[] = [
    {step: "FeaturesEnabling", label: "Enabling features"},
    {step: "UmlCreation", label: "Creating UML diagram"},
    {step: "TableViewConfiguration", label: "Table view configuration"},
    {step: "Validation", label: "Validation"},
    {step: "ColorsSelection", label: "Select colors"},
    {step: "Receiving", label: "Receiving"},
]