export type UMLConnectionType = "OneToMany" | "ManyToOne";
export const сonnectionType: UMLConnectionType[] = ["OneToMany", "ManyToOne"];