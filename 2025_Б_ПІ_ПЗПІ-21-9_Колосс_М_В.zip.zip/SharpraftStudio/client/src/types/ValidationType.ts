
export type ValidationType = "Required" | "MinLength" | "MaxLength" | "Email" | "PhoneNumber" | "Range";
export const validationTypes:ValidationType[] = ["Required", "MinLength", "MaxLength", "Email", "PhoneNumber", "Range"]