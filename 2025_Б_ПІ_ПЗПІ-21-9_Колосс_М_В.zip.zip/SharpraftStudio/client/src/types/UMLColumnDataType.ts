export type UMLColumnDataType = "String" | "Int" | "DateTime" | "Double" | "Boolean";
export const columnDataTypes: UMLColumnDataType[] = ["String", "Int", "DateTime", "Double", "Boolean"];