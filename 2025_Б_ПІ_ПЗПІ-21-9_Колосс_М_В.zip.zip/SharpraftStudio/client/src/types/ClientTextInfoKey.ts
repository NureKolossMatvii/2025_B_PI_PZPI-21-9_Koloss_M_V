import {howToDownloadTextKey, mainTextKey} from '../consts'

export type ClientTextInfoKey = typeof howToDownloadTextKey | typeof mainTextKey