﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Data.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.UML.Services
{
    internal class UMLDiagramService : IUMLDiagramService
    {
        private readonly IMapper _mapper;
        private readonly IUMLDiagramRepository _diagramRepository;
        private readonly IUMLConnectionRepository _connectionRepository;
        private UserManager<User> _userManager;

        public UMLDiagramService(IMapper mapper, IUMLDiagramRepository repository, UserManager<User> userManager, IUMLConnectionRepository connectionRepository)
        {
            _mapper = mapper;
            _diagramRepository = repository;
            _userManager = userManager;
            _connectionRepository = connectionRepository;
        }
        public async Task<OperationResult> SaveAsync(UMLDiagramSaveDto diagram, string userName)
        {
            var user = await _userManager.FindByNameAsync(userName);

            if (user == null)
            {
                return OperationResultFactory.FailuredWithGeneralError("Invalid user name.");
            }

            var diagramFromDb = await _diagramRepository.GetAsync(diagram.DiagramId);
            var newDiagram = _mapper.Map<UMLDiagram>(diagram);

            if (diagramFromDb != null)
            {
                if (diagramFromDb.Owner.UserName != userName)
                {
                    return OperationResultFactory.FailuredWithGeneralError("User havent permissions.");
                }

                await _connectionRepository.RemoveAsync(diagramFromDb.Connections);
                await _diagramRepository.RemoveAsync(diagramFromDb);
                await _diagramRepository.CreateAsync(newDiagram);
            }
            else
            {
                await _diagramRepository.CreateAsync(newDiagram);
            }

            return OperationResultFactory.Successed();
        }
    }
}
