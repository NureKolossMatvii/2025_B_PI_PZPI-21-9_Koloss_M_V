﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpCraftStudio.UML.Services;
using SharpCraftStudio.UML.Interfaces;
using SharpCraftStudio.UML.Repositories;

namespace SharpCraftStudio.UML
{
    public static class UmlServiceRegister
    {
        public static void Register(IServiceCollection services)
        {
            services.AddScoped<IUMLDiagramService, UMLDiagramService>();
            services.AddScoped<IUMLDiagramRepository, UMLDiagramRepository>();
            services.AddScoped<IUMLConnectionRepository, UMLConnectionRepository>();
        }
    }
}
