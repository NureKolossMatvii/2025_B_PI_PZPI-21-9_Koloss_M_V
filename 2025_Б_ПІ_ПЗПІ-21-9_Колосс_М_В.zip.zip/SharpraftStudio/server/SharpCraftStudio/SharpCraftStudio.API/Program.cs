using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using SharpCraftStudio.Authorization;
using SharpCraftStudio.ClientConfiguration;
using SharpCraftStudio.CodeGeneration;
using SharpCraftStudio.Core.Interfaces;
using SharpCraftStudio.Data;
using SharpCraftStudio.Mapping;
using SharpCraftStudio.Project;
using System.Text;

internal class Program
{
    private static async Task Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        RegisterServices(builder.Services, builder.Configuration);

        var app = builder.Build();

        await InitializeDefaultData(app.Services);

        if (app.Environment.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI();
        }


        app.UseCors("_myAllowSpecificOrigins");
        app.UseHttpsRedirection();

        app.UseAuthentication();
        app.UseAuthorization();

        app.MapControllers();

        app.Run();
    }

    private static void RegisterServices(IServiceCollection services, IConfiguration configuration)
    {
        AuthorizationServiceRegister.Register(services);
        MappingServiceRegister.Register(services);
        DataServiceRegister.Register(services, configuration);
        ProjectServiceRegister.Register(services);
        CodeGenerationServiceRegister.Register(services);
        ClientConfigurationServiceRegister.Register(services);

        services.AddCors(options =>
        {
            options.AddPolicy(name: "_myAllowSpecificOrigins",
                              policy =>
                              {
                                  policy.AllowAnyHeader();
                                  policy.AllowAnyMethod();
                                  policy.SetIsOriginAllowed((host) => true);
                              });
        });

        services.AddControllers();
        services.AddEndpointsApiExplorer();
        services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
        }).AddJwtBearer(options =>
        {
            options.SaveToken = true;
            options.RequireHttpsMetadata = false;
            options.TokenValidationParameters = new TokenValidationParameters()
            {
                ValidateIssuer = false,
                ValidateAudience = false,
                IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(configuration["Jwt:Key"])),
                ValidateLifetime = false,
            };
        });
        services.AddSwaggerGen(c =>
        {
            c.SwaggerDoc("v1", new OpenApiInfo { Title = "JobSearch.API", Version = "v1" });
            var jwtSecurityScheme = new OpenApiSecurityScheme
            {
                BearerFormat = "JWT",
                Name = "JWT Authentication",
                In = ParameterLocation.Header,
                Type = SecuritySchemeType.Http,
                Scheme = JwtBearerDefaults.AuthenticationScheme,
                Description = "Put **_ONLY_** your JWT Bearer token on textbox below!",

                Reference = new OpenApiReference
                {
                    Id = JwtBearerDefaults.AuthenticationScheme,
                    Type = ReferenceType.SecurityScheme
                }
            };

            c.AddSecurityDefinition(jwtSecurityScheme.Reference.Id, jwtSecurityScheme);

            c.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
                { jwtSecurityScheme, Array.Empty<string>() }
            });
        });
    }

    private static async Task InitializeDefaultData(IServiceProvider serviceProvider)
    {
        using var scope = serviceProvider.CreateScope();
        var initializers = scope.ServiceProvider.GetRequiredService<IEnumerable<IDefaultDataInitializer>>();

        foreach (var initializer in initializers)
        {
            await initializer.InitializeAsync();
        }
    }
}