﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Models.UML;

namespace SharpCraftStudio.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class UserUMLController : Controller
    {
        private readonly IUMLDiagramService _diagramService;

        public UserUMLController(IUMLDiagramService diagramService)
        {
            _diagramService = diagramService;
        }

        [HttpPost("save")]
        public async Task<IActionResult> Save([FromBody] UMLDiagramSaveDto diagram)
        {
            var result = await _diagramService.SaveAsync(diagram, User.Identity.Name);

            if(result.Success)
            {
                return Ok();
            }


            return BadRequest(result.Errors);
        }
    }
}
