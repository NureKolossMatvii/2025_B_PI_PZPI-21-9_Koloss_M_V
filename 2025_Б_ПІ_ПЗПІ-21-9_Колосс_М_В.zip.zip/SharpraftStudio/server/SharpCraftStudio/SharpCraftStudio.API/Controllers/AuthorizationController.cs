﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SharpCraftStudio.Authorization.Interfaces;
using SharpCraftStudio.Authorization.Models;

namespace SharpCraftStudio.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthorizationController : Controller
    {
        private readonly IUserRegister _userRegister;
        private readonly ISignInService _signInService;

        public AuthorizationController(IUserRegister userRegister, ISignInService signInService)
        {
            _userRegister = userRegister;
            _signInService = signInService;
        }

        [HttpPost("register")]
        public async Task<IActionResult> Register(UserRegisterDto userRegisterDto, CancellationToken cancellationToken)
        {
            var operationResult = await _userRegister.Register(userRegisterDto, cancellationToken);

            if (operationResult.Success)
            {
                return Ok(operationResult.Result);
            }

            return BadRequest(operationResult.Errors);
        }

        [HttpPost("signIn")]
        public async Task<IActionResult> SignIn(UserSignInDto userSignInDto)
        {
            var operationResult = await _signInService.SignIn(userSignInDto);

            if (operationResult.Success)
            {
                return Ok(operationResult.Result);
            }

            return BadRequest(operationResult.Errors);
        }

        [Authorize]
        [HttpPost("checkToken")]
        public IActionResult CheckToken()
        {
            return Ok();
        }
    }
}
