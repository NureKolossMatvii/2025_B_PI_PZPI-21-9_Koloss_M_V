﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SharpCraftStudio.Authorization.Models;
using SharpCraftStudio.Data.Models.Project.ColorTemplates;
using SharpCraftStudio.Project.Interfaces;

namespace SharpCraftStudio.API.Controllers
{
    [ApiController]
    [Authorize(Roles = Roles.ADMIN)]
    [Route("api/[controller]")]
    public class ColorTemplatesController : Controller
    {
        private readonly IColorTemplatesService _colorTemplatesService;

        public ColorTemplatesController(IColorTemplatesService colorTemplatesService)
        {
            _colorTemplatesService = colorTemplatesService;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var templates = await _colorTemplatesService.GetAllAsync();
            return Ok(templates);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(Guid id)
        {
            var template = await _colorTemplatesService.GetAsync(id);
            return Ok(template);
        }


        [HttpPost]
        public async Task<IActionResult> Create(ColorTemplate template)
        {
            var result = await _colorTemplatesService.AddAsync(template);

            if(result.Success)
            {
                return Ok();
            }

            return BadRequest();
        }

        [HttpPatch]
        public async Task<IActionResult> Patch(ColorTemplate template)
        {
            var result = await _colorTemplatesService.EditAsync(template);

            if (result.Success)
            {
                return Ok();
            }

            return BadRequest();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var result = await _colorTemplatesService.RemoveAsync(id);

            if (result.Success)
            {
                return Ok();
            }

            return BadRequest();
        }
    }
}
