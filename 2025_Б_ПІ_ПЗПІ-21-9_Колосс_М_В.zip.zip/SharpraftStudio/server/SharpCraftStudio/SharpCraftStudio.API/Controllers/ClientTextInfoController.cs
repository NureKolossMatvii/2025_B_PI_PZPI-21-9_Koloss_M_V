﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SharpCraftStudio.Authorization.Models;
using SharpCraftStudio.ClientConfiguration.Interfaces;
using SharpCraftStudio.Data.Models.ClientConfiguration;
using SharpCraftStudio.Project.Interfaces;
using Xunit.Abstractions;

namespace SharpCraftStudio.API.Controllers
{
    [ApiController]
    [Authorize(Roles = Roles.ADMIN)]
    [Route("api/[controller]")]
    public class ClientTextInfoController : ControllerBase
    {
        private readonly IClientTextInfoService _clientTextInfoService;

        public ClientTextInfoController(IClientTextInfoService clientTextInfoService)
        {
            _clientTextInfoService = clientTextInfoService;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var result = await _clientTextInfoService.GetAllAsync();

            if (result.Success)
            {
                return Ok(result.Result);
            }

            return BadRequest(result.Errors);
        }

        [HttpPost]
        public async Task<IActionResult> Post(ClientTextInfoItem item)
        {
            var result = await _clientTextInfoService.AddOrUpdateAsync(item);

            if (result.Success)
            {
                return Ok();
            }

            return BadRequest(result.Errors);
        }

        [HttpDelete("{key}")]
        public async Task<IActionResult> Delete(string key)
        {
            var result = await _clientTextInfoService.RemoveAsync(key);

            if (result.Success)
            {
                return Ok();
            }

            return BadRequest(result.Errors);
        }
    }
}
