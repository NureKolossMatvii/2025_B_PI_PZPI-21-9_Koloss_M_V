﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Models.UML;

namespace SharpCraftStudio.API.Controllers
{
    [Authorize]
    [Route("api/ProjectConfiguration/{projectConfigurationId}/[controller]")]
    public class ViewConfigurationController : Controller
    {
        private readonly IViewConfigService _viewConfigService;

        public ViewConfigurationController(IViewConfigService viewConfigService)
        {
            _viewConfigService = viewConfigService;
        }

        [HttpGet]
        public async Task<IActionResult> Get([FromQuery] Guid projectConfigurationId)
        {
            var result = await _viewConfigService.GetViewConfigAsync(projectConfigurationId);

            if (result.Success)
            {
                return Ok(result.Result!);
            }

            return BadRequest(result.Errors);
        }

        [HttpPost("save")]
        public async Task<IActionResult> Save([FromBody] ViewConfigDto viewConfig, [FromRoute] Guid projectConfigurationId)
        {
            var result = await _viewConfigService.SetViewConfigAsync(viewConfig, projectConfigurationId);

            if (result.Success)
            {
                return Ok();
            }

            return BadRequest(result.Errors);
        }

        [HttpPost("setDefault")]
        public async Task<IActionResult> SetDefault([FromQuery] Guid projectConfigurationId)
        {
            var result = await _viewConfigService.SetDefaultViewConfigAsync(projectConfigurationId);

            if (result.Success)
            {
                return Ok();
            }

            return BadRequest(result.Errors);
        }
    }
}
