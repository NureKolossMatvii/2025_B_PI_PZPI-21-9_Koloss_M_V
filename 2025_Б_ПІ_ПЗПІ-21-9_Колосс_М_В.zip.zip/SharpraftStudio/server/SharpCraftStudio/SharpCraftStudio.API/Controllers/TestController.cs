﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Data.Models.Project.Validation;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System.IO.Compression;

namespace SharpCraftStudio.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TestController : Controller
    {
        private readonly IResultGenerator _resultGenerator;
        private readonly IDefaultViewConfigExtractor _viewConfigExtractor;
        private readonly IDefaultValidationConfigExtractor _validationConfigExtractor;
        private readonly IMapper _mapper;

        public TestController(IResultGenerator resultGenerator, IDefaultViewConfigExtractor extractor, IDefaultValidationConfigExtractor validationConfigExtractor, IMapper mapper)
        {
            _resultGenerator = resultGenerator;
            _viewConfigExtractor = extractor;
            _validationConfigExtractor = validationConfigExtractor;
            _mapper = mapper;
        }

        [HttpGet("GetDefaultViewConfig")]
        public IActionResult TestExtractor()
        {
            var project = CreateSampleProjectConfiguration();

            var result = _viewConfigExtractor.Extract(project.Diagram);

            return Ok(result);
        }

        [HttpGet("GetTestResult")]
        public IActionResult GetTestResult()
        {
            var project = CreateSampleProjectConfiguration();
            var resultFolder = _resultGenerator.Generate(project);

            using (var archiveStream = new MemoryStream())
            {
                using (var archive = new ZipArchive(archiveStream, ZipArchiveMode.Create, true))
                {
                    resultFolder.AddToZip(archive);
                }

                archiveStream.Position = 0;
                return File(archiveStream.ToArray(), "application/zip", "result.zip");
            }
        }

        private ProjectConfigurationDto CreateSampleProjectConfiguration()
        {
            var diagram = CreateSampleUMLDiagram();
            var viewConfig = _viewConfigExtractor.Extract(diagram);
            var usersTableConfig = viewConfig.TableViewConfigs.First(c => c.Label == "Users");
            var firstNameCfg = usersTableConfig.ColumnViewConfigs.First(c => c.Label == "FirstName");
            var lastNameCfg = usersTableConfig.ColumnViewConfigs.First(c => c.Label == "LastName");
            var creationDate = usersTableConfig.ColumnViewConfigs.First(c => c.Label == "CreationDate");
            var age = usersTableConfig.ColumnViewConfigs.First(c => c.Label == "Age");
            var isAdmin = usersTableConfig.ColumnViewConfigs.First(c => c.Label == "IsAdmin");

            firstNameCfg.DatasetSelectorRules = new()
            {
                SearchingEnabled = true,
                SortingEnabled = true,
            };

            lastNameCfg.DatasetSelectorRules = new()
            {
                SearchingEnabled = true,
                SortingEnabled = true,
            };

            creationDate.DatasetSelectorRules = new()
            {
                FilteringEnabled = true,
                SortingEnabled = true,
            };

            age.DatasetSelectorRules = new()
            {
                FilteringEnabled = true,
                SortingEnabled = true,
            };

            

            isAdmin.DatasetSelectorRules = new()
            {
                FilteringEnabled = true,
                SortingEnabled = true,
            };

            var validationConfig = _validationConfigExtractor.Extract(_mapper.Map<UMLDiagram>(diagram));

            var val_usersTableConfig = validationConfig.TableValidationConfigs.First(c => c.UmlTableId == usersTableConfig.UMLTableId);
            var val_firstNameCfg = val_usersTableConfig.ColumnValidationConfigs.First(c => c.UmlColumnId == firstNameCfg.UMLColumnId);
            var val_lastNameCfg = val_usersTableConfig.ColumnValidationConfigs.First(c => c.UmlColumnId == lastNameCfg.UMLColumnId);
            var val_creationDate = val_usersTableConfig.ColumnValidationConfigs.First(c => c.UmlColumnId == creationDate.UMLColumnId);
            var val_age = val_usersTableConfig.ColumnValidationConfigs.First(c => c.UmlColumnId == age.UMLColumnId);
            var val_isAdmin = val_usersTableConfig.ColumnValidationConfigs.First(c => c.UmlColumnId == isAdmin.UMLColumnId);

            val_firstNameCfg.Validation.Add(new Validation()
            {
                Type = ValidationType.Email,
                Message = "email",
            });

            val_firstNameCfg.Validation.Add(new Validation()
            {
                Type = ValidationType.MinLength,
                Message = "range",
                FirstParameter = "5"
            });

            val_age.Validation.Add(new Validation()
            {
                Type = ValidationType.Range,
                Message = "should be in range from 10 to 150",
                FirstParameter = "5",
                SecondParameter = "150"
            });




            return new ProjectConfigurationDto()
            {
                Diagram = diagram,
                Name = "TestProjectName",
                ViewConfig = viewConfig,
                ValidationConfig = validationConfig
            };
        }


        private UMLDiagramDto CreateSampleUMLDiagram()
        {
            var usersTable = new UMLTableDto
            {
                TableId = Guid.NewGuid(),
                Name = "Users",
                Columns = new List<UMLTableColumnDto>
        {
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "UserID",
                IsPrimaryKey = true,
                IsForeignKey = false,
                DataType = UMLColumnDataType.Int,
            },
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "FirstName",
                IsPrimaryKey = false,
                IsForeignKey = false,
                DataType = UMLColumnDataType.String
            },
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "LastName",
                IsPrimaryKey = false,
                IsForeignKey = false,
                DataType = UMLColumnDataType.String
            },
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "CreationDate",
                IsPrimaryKey = false,
                IsForeignKey = false,
                DataType = UMLColumnDataType.DateTime
            },
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "Age",
                IsPrimaryKey = false,
                IsForeignKey = false,
                DataType = UMLColumnDataType.Int
            },
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "IsAdmin",
                IsPrimaryKey = false,
                IsForeignKey = false,
                DataType = UMLColumnDataType.Boolean
            }
        }
            };
            usersTable.LabelColumnTableId = usersTable.Columns.First(c => c.Name == "FirstName").TableColumnId;

            var projectsTable = new UMLTableDto
            {
                TableId = Guid.NewGuid(),
                Name = "Projects",
                Columns = new List<UMLTableColumnDto>
        {
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "ProjectID",
                IsPrimaryKey = true,
                IsForeignKey = false,
                DataType = UMLColumnDataType.Int
            },
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "ProjectName",
                IsPrimaryKey = false,
                IsForeignKey = false,
                DataType = UMLColumnDataType.String
            }
        }
            };
            projectsTable.LabelColumnTableId = projectsTable.Columns.First(c => c.Name == "ProjectName").TableColumnId;

            var tasksTable = new UMLTableDto
            {
                TableId = Guid.NewGuid(),
                Name = "Tasks",
                Columns = new List<UMLTableColumnDto>
        {
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "TaskID",
                IsPrimaryKey = true,
                IsForeignKey = false,
                DataType = UMLColumnDataType.Int
            },
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "ProjectID",
                IsPrimaryKey = false,
                IsForeignKey = true,
                DataType = UMLColumnDataType.Int
            },
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "TaskName",
                IsPrimaryKey = false,
                IsForeignKey = false,
                DataType = UMLColumnDataType.String
            },
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "UserID",
                IsPrimaryKey = false,
                IsForeignKey = true,
                DataType = UMLColumnDataType.Int
            }
        }
            };
            tasksTable.LabelColumnTableId = tasksTable.Columns.First(c => c.Name == "TaskName").TableColumnId;

            var projectUsersTable = new UMLTableDto
            {
                TableId = Guid.NewGuid(),
                Name = "ProjectUsers",
                Columns = new List<UMLTableColumnDto>
        {
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "ProjectUserID",
                IsPrimaryKey = true,
                IsForeignKey = false,
                DataType = UMLColumnDataType.Int
            },
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "ProjectID",
                IsPrimaryKey = false,
                IsForeignKey = true,
                DataType = UMLColumnDataType.Int
            },
            new UMLTableColumnDto
            {
                TableColumnId = Guid.NewGuid(),
                Name = "UserID",
                IsPrimaryKey = false,
                IsForeignKey = true,
                DataType = UMLColumnDataType.Int
            }
        }
            };
            projectUsersTable.LabelColumnTableId = projectUsersTable.Columns.First(c => c.Name == "ProjectUserID").TableColumnId;

            // Connections
            var projectToTaskConnection = new UMLTableConnectionDto
            {
                TableConnectionId = Guid.NewGuid(),
                LeftTableId = projectsTable.TableId,
                RightTableId = tasksTable.TableId,
                ForeignKeyColumnId = tasksTable.Columns.First(c => c.Name == "ProjectID").TableColumnId,
                ConnectionType = UMLConnectionType.OneToMany,
            };

            var projectToUserConnection = new UMLTableConnectionDto
            {
                TableConnectionId = Guid.NewGuid(),
                LeftTableId = projectsTable.TableId,
                RightTableId = projectUsersTable.TableId,
                ForeignKeyColumnId = projectUsersTable.Columns.First(c => c.Name == "ProjectID").TableColumnId,
                ConnectionType = UMLConnectionType.OneToMany,
            };

            var userToProjectConnection = new UMLTableConnectionDto
            {
                TableConnectionId = Guid.NewGuid(),
                LeftTableId = usersTable.TableId,
                RightTableId = projectUsersTable.TableId,
                ForeignKeyColumnId = projectUsersTable.Columns.First(c => c.Name == "UserID").TableColumnId,
                ConnectionType = UMLConnectionType.OneToMany,
            };

            var taskToUserConnection = new UMLTableConnectionDto
            {
                TableConnectionId = Guid.NewGuid(),
                LeftTableId = tasksTable.TableId,
                RightTableId = usersTable.TableId,
                ForeignKeyColumnId = tasksTable.Columns.First(c => c.Name == "UserID").TableColumnId,
                ConnectionType = UMLConnectionType.ManyToOne,
            };

            var umlDiagram = new UMLDiagramDto
            {
                Tables = new List<UMLTableDto> { usersTable, projectsTable, tasksTable, projectUsersTable },
                Connections = new List<UMLTableConnectionDto> { projectToTaskConnection, projectToUserConnection, userToProjectConnection, taskToUserConnection }
            };

            return umlDiagram;
        }
    }
}
