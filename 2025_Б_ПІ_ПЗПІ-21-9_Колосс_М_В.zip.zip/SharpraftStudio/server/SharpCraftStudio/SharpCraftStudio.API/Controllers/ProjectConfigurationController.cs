﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces;
using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Data.Models.Project.Validation;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Models;
using System.IO.Compression;

namespace SharpCraftStudio.API.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    public class ProjectConfigurationController : Controller
    {
        private readonly IProjectService _projectService;
        private readonly IProjectStepMoveService _stepMoveService;
        private readonly IResultGenerator _resultGenerator;

        public ProjectConfigurationController(IProjectService projectService, IProjectStepMoveService stepMoveService, IResultGenerator resultGenerator)
        {
            _projectService = projectService;
            _stepMoveService = stepMoveService;
            _resultGenerator = resultGenerator;
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var diagrams = await _projectService.GetForUserAsync(User.Identity.Name);

            return Ok(diagrams);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(Guid id)
        {
            var diagram = await _projectService.GetByIdForUserAsync(id, User.Identity.Name);

            if (diagram == null)
            {
                return NotFound();
            }

            return Ok(diagram);
        }


        [HttpGet("{id}/result/mvc")]
        public async Task<IActionResult> GetMvcResult(Guid id)
        {
            var project = await _projectService.GetResultAsync(id, User.Identity.Name);

            if (!project.Success)
            {
                return NotFound();
            }

            var resultFolder = _resultGenerator.Generate(project.Result);
            using var archiveStream = new MemoryStream();
            using (var archive = new ZipArchive(archiveStream, ZipArchiveMode.Create, true))
            {
                resultFolder.AddToZip(archive);
            }

            archiveStream.Position = 0;
            return File(archiveStream.ToArray(), "application/zip", "result.zip");
        }

        [HttpPatch("step/{projectId}")]
        public async Task<IActionResult> MoveToNextStep(Guid projectId)
        {
            var result = await _stepMoveService.MoveToNextStepAsync(projectId, User.Identity.Name);

            if (result.Success)
            {
                return Ok();
            }

            return BadRequest(result.Errors);
        }

        [HttpPatch("saveEnabledFeatures")]
        public async Task<IActionResult> SaveEnabledFeatures([FromBody]SetupEnabledFeaturesDto setupEnabledFeaturesDto)
        {
            var result = await _projectService.SaveEnabledFeaturesAsync(setupEnabledFeaturesDto, User.Identity.Name);

            if (result.Success)
            {
                return Ok();
            }

            return BadRequest(result.Errors);
        }

        [HttpPatch("{projectConfigurationId}/saveColorTemplate/{colorTemplateId}")]
        public async Task<IActionResult> SaveColorTemplate([FromRoute] Guid projectConfigurationId, [FromRoute] Guid colorTemplateId)
        {
            var result = await _projectService.SaveColorTemplate(projectConfigurationId, colorTemplateId, User.Identity.Name);

            if (result.Success)
            {
                return Ok();
            }

            return BadRequest(result.Errors);
        }

        [HttpPatch("{projectConfigurationId}/saveValidation")]
        public async Task<IActionResult> SaveValidation([FromRoute] Guid projectConfigurationId, [FromBody] ValidationConfig config)
        {
            var result = await _projectService.SaveValidation(projectConfigurationId, config, User.Identity.Name);

            if (result.Success)
            {
                return Ok();
            }

            return BadRequest(result.Errors);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] ProjectCreationDto projectCreationDto)
        {
            var result = await _projectService.CreateAsync(projectCreationDto, User.Identity.Name);

            if (result.Success)
            {
                return Ok();
            }

            return BadRequest(result.Errors);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(Guid id)
        {
            var result = await _projectService.DeleteAsync(id, User.Identity.Name);

            if (result.Success)
            {
                return Ok();
            }

            return BadRequest(result.Errors);
        }
    }
}
