﻿using MongoDB.Bson.Serialization.Attributes;
using System;
using System.ComponentModel.DataAnnotations;

namespace SharpCraftStudio.Data.Models.ClientConfiguration
{
    public class ClientTextInfoItem : IEntity
    {
        [BsonId]
        public string Key { get; set; }
        public string EngLabel { get; set; }
        public string RuLabel { get; set; }
    }
}
