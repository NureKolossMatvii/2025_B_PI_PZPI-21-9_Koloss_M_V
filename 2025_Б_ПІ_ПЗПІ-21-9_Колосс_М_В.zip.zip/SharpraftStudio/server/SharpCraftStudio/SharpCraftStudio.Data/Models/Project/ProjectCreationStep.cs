﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project
{
    public enum ProjectCreationStep
    {
        FeaturesEnabling,
        UmlCreation,
        TableViewConfiguration,
        ValidationEnabling,
        ColorsSelection,
        Receiving,
    }
}
