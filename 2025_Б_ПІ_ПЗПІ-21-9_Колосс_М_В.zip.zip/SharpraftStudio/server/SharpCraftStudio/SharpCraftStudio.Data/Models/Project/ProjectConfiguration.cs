﻿using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Data.Models.Project.Validation;

namespace SharpCraftStudio.Data.Models.Project
{
    public class ProjectConfiguration : IEntity
    {
        public Guid ProjectConfigurationId { get; set; }

        public string Name { get; set; }

        public DateTime CreationDate { get; set; }

        public ProjectCreationStep Step { get; set; }

        public string OwnerUserName { get; set; }

        public Guid? ColorTemplateId { get; set; }

        public EnabledFeatures? EnabledFeatures { get; set; } = new();

        public UMLDiagram? Diagram { get; set; } = new();

        public ViewConfig? ViewConfig { get; set; } = new();

        public ValidationConfig? ValidationConfig { get; set; } = new();
    }
}
