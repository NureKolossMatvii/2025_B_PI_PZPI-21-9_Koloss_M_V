﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.TableView
{
    public class ColumnViewConfig
    {
        public Guid ColumnViewConfigurationId { get; set; }
        public Guid UMLColumnId { get; set; }

        public string Label { get; set; }
        public DatasetSelectorRules DatasetSelectorRules { get; set; }
    }
}
