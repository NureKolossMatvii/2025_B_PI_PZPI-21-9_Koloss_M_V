﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.TableView
{
    public class TableViewConfig
    {
        public Guid TableViewConfigurationId { get; set; }
        public Guid UMLTableId { get; set; }
        public string Label { get; set; }

        public List<ColumnViewConfig> ColumnViewConfigs { get; set; } = new();
    }
}
