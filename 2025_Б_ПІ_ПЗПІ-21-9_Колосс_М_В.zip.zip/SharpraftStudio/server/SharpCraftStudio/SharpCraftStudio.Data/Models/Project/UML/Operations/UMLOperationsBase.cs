﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.UML.Operations
{
    public class UMLOperationsBase
    {
        public bool RemoveEnabled { get; set; } = true;
        public bool NameChangeEnabled { get; set; } = true;
    }
}
