﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.UML
{
    public class UMLTableConnection : IEntity
    {
        public Guid TableConnectionId { get; set; }

        public Guid LeftTableId { get; set; }

        public Guid RightTableId { get; set; }

        public Guid ForeignKeyColumnId { get; set; }

        public UMLConnectionType ConnectionType { get; set; }
    }
}
