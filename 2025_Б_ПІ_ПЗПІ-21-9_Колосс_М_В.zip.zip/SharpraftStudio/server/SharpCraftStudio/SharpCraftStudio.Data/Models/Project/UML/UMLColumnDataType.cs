﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.UML
{
    public enum UMLColumnDataType
    {
        String,
        Int,
        DateTime,
        Double,
        Boolean,
    }

    public static class UMLColumnDataTypeExtensions
    {
        public static string GetCSString(this UMLColumnDataType columnDataType)
        {
            switch (columnDataType)
            {
                case UMLColumnDataType.String:
                    return "string";
                case UMLColumnDataType.Int:
                    return "int";
                case UMLColumnDataType.DateTime:
                    return "DateTime";
                case UMLColumnDataType.Double:
                    return "double";
                case UMLColumnDataType.Boolean:
                    return "bool";
            }

            throw new NotImplementedException();
        }
    }
}
