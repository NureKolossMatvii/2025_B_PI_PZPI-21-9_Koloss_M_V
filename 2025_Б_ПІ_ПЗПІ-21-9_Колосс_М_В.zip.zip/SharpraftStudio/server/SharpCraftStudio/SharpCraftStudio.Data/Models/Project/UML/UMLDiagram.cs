﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.UML
{
    public class UMLDiagram : IEntity
    {
        public List<UMLTable> Tables { get; set; }

        public List<UMLTableConnection> Connections { get; set; }
    }
}
