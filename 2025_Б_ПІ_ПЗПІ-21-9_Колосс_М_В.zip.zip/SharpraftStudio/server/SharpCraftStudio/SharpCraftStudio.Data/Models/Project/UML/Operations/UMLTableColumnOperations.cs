﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.UML.Operations
{
    public class UMLTableColumnOperations : UMLOperationsBase
    {
        public bool DataTypeChangeAvailable { get; set; } = true;

        public bool RestrictionChangeAvailable { get; set; } = true;
    }
}
