﻿using SharpCraftStudio.Data.Models.Project.UML.Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.UML
{
    public class UMLTableColumn : IEntity
    {
        public Guid TableColumnId { get; set; }

        public string Name { get; set; }

        public bool IsForeignKey { get; set; }

        public bool IsPrimaryKey { get; set; }

        public UMLTableColumnOperations Operations { get; set; }

        public UMLColumnDataType DataType { get; set; }
    }
}
