﻿using SharpCraftStudio.Data.Models.Project.UML.Operations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.UML
{
    public class UMLTable : IEntity
    {
        public Guid TableId { get; set; }

        public string Name { get; set; }

        public Position Position { get; set; }

        public UMLTableOperations Operations { get; set; }

        public List<UMLTableColumn> Columns { get; set; }

        public Guid LabelColumnTableId { get; set; }
    }
}
