﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.UML.Operations
{
    public class UMLTableOperations : UMLOperationsBase
    {
        public bool ColumnCreationAvailable { get; set; } = true;
    }
}
