﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.Validation
{
    public class ValidationConfig
    {
        public List<TableValidationConfig> TableValidationConfigs { get; set; } = new();
    }
}
