﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.Validation
{
    public enum ValidationType
    {
        Required,
        MinLength,
        MaxLength,
        Email,
        PhoneNumber,
        Range
    }
}
