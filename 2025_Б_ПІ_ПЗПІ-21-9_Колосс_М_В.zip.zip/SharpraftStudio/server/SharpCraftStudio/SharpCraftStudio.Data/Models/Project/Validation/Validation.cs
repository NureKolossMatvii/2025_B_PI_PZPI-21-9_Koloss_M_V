﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.Validation
{
    public class Validation
    {
        public ValidationType Type { get; set; }

        public string Message { get; set; }

        public string? FirstParameter { get; set; }

        public string? SecondParameter { get; set; }
    }
}
