﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.Validation
{
    public class TableValidationConfig
    {
        public Guid TableValidationConfigurationId { get; set; }
        public Guid UmlTableId { get; set; }

        public List<ColumnValidationConfig> ColumnValidationConfigs { get; set; } = new();
    }
}
