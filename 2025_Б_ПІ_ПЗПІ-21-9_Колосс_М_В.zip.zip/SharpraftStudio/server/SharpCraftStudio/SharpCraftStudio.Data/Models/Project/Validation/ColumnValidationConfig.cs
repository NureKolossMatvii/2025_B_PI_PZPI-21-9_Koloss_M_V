﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.Validation
{
    public class ColumnValidationConfig
    {
        public Guid ColumnValidationConfigurationId { get; set; }
        public Guid UmlColumnId { get; set; }
        public List<Validation> Validation { get; set; } = new();
    }
}
