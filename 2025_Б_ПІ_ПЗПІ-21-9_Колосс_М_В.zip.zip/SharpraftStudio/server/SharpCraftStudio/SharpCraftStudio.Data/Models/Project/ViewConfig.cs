﻿using SharpCraftStudio.Data.Models.Project.TableView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project
{
    public class ViewConfig
    {
        public List<TableViewConfig> TableViewConfigs { get; set; } = new();
    }
}
