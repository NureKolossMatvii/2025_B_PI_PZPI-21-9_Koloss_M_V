﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.ColorTemplates
{
    public class AppColors
    {
        public string BackgroundColor { get; set; }
        public string Color { get; set; }
        public string BorderColor { get; set; }

        public ButtonColors DefaultButtonColor { get; set; }
        public ButtonColors DeleteButtonColor { get; set; }
        public ButtonColors EditButtonColor { get; set; }
        public ButtonColors CancelButtonColor { get; set; }

        public TableColors TableColor { get; set; }
    }
}
