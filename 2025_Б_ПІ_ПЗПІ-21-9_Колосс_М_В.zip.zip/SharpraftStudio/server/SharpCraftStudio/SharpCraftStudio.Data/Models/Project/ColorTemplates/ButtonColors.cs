﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project.ColorTemplates
{
    public class ButtonColors
    {
        public string Background { get; set; }
        public string Color { get; set; }
    }
}
