﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data.Models.Project
{
    public class EnabledFeatures
    {
        public bool AuthorizationEnabled { get; set; }

        public string? UserTableName { get; set; }
    }
}
