﻿using Microsoft.AspNetCore.Identity;

namespace SharpCraftStudio.Data.Models.Project
{
    public class User : IdentityUser, IEntity
    {
    }
}
