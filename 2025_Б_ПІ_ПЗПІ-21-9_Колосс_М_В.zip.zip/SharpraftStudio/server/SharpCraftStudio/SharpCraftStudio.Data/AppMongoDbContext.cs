﻿using Microsoft.EntityFrameworkCore;
using MongoDB.Driver;
using MongoDB.EntityFrameworkCore.Extensions;
using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Data.Models.ClientConfiguration;
using SharpCraftStudio.Data.Models.Project;
using SharpCraftStudio.Data.Models.Project.ColorTemplates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Data
{
    public class AppMongoDbContext : DbContext, IAppDbContext<AppMongoDbContext>
    {
        public DbSet<ProjectConfiguration> ProjectConfigurations { get; init; }
        public DbSet<ColorTemplate> ColorTemplates { get; init; }
        public DbSet<ClientTextInfoItem> ClientLabelInfos { get; init; }

        public static AppMongoDbContext Create(IMongoDatabase database) =>
            new(new DbContextOptionsBuilder<AppMongoDbContext>()
                .UseMongoDB(database.Client, database.DatabaseNamespace.DatabaseName)
                .Options);
        public AppMongoDbContext(DbContextOptions options)
            : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<ProjectConfiguration>().ToCollection("ProjectConfigurations");
            modelBuilder.Entity<ColorTemplate>().ToCollection("ColorTemplates");
        }

        public DbSet<TEntity> GetSet<TEntity>() where TEntity : class, IEntity
        {
            return Set<TEntity>();
        }
    }
}
