﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Data.Models.Project;

namespace SharpCraftStudio.Data
{
    internal class AppDbContext : IdentityDbContext<User>, IAppDbContext<AppDbContext>
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
            //Database.EnsureDeleted();
            Database.EnsureCreated();
        }

        public DbSet<User> Users { get; set; }

        public DbSet<TEntity> GetSet<TEntity>() where TEntity : class, IEntity
        {
            return Set<TEntity>();
        }
    }
}
