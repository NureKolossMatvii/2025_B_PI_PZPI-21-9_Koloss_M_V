﻿using Microsoft.EntityFrameworkCore;
using SharpCraftStudio.Data.Models;

namespace SharpCraftStudio.Data
{
    public interface IAppDbContext<TDbContext> where TDbContext : DbContext
    {
        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);

        DbSet<TEntity> GetSet<TEntity>() where TEntity : class, IEntity;
    }
}
