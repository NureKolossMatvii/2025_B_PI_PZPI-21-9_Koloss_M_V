﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using MongoDB.Driver;
using SharpCraftStudio.Data.Models.Project;
using SharpCraftStudio.Data.Settings;

namespace SharpCraftStudio.Data
{
    public static class DataServiceRegister
    {
        public static void Register(IServiceCollection services, IConfiguration configuration)
        {
            services.AddDbContext<IAppDbContext<AppDbContext>, AppDbContext>(options =>
            {
                options.UseSqlServer(configuration.GetConnectionString("Default"));
            });

            services.AddIdentity<User, IdentityRole>()
                .AddEntityFrameworkStores<AppDbContext>();

            var mongoDbSettings = new MongoDbSettings()
            {
                DatabaseName = configuration["MongoDb:DatabaseName"],
                ConnectionString = configuration["MongoDb:ConnectionString"],
            };

            services.AddSingleton(mongoDbSettings);

            services.AddSingleton<IMongoClient, MongoClient>(sp =>
            {
                return new MongoClient(mongoDbSettings.ConnectionString);
            });

            services.AddScoped(sp =>
            {
                var settings = sp.GetRequiredService<MongoDbSettings>();
                var client = sp.GetRequiredService<IMongoClient>();
                return client.GetDatabase(settings.DatabaseName);
            });

            services.AddScoped<IAppDbContext<AppMongoDbContext>>(sp =>
            {
                var database = sp.GetRequiredService<IMongoDatabase>();
                return AppMongoDbContext.Create(database);
            });
        }
    }
}
