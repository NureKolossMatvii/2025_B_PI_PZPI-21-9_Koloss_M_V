﻿using SharpCraftStudio.CodeGeneration.Builders.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Builders
{
    internal class CodeClassInfoBuilder : ICodeClassInfoBuilder, IIgnoreInjection
    {
        private readonly string _name;
        private readonly AccessModifier _accessModifier;

        private string? _baseClassName;
        private readonly List<CodeAttribute> _attributes = new();
        private readonly List<string> _implementedInterfaces = new();
        private readonly List<CodeMethodInfo> _methodInfos = new();
        private readonly List<CodeDataInfo> _dataInfos = new();
        private readonly List<string> _constructors = new();
        private readonly List<string> _genericArgs = new();

        public CodeClassInfoBuilder(string name, AccessModifier accessModifier)
        {
            _name = name;
            _accessModifier = accessModifier;
        }

        public ICodeClassInfoBuilder AddAttribute(CodeAttribute attribute)
        {
            _attributes.Add(attribute);
            return this;
        }

        public ICodeClassInfoBuilder AddConstructor(string constructor)
        {
            _constructors.Add(constructor);
            return this;
        }

        public ICodeClassInfoBuilder AddGenericArg(string genericArg)
        {
            _genericArgs.Add(genericArg);
            return this;
        }


        public ICodeClassInfoBuilder AddMethod(CodeMethodInfo method)
        {
            _methodInfos.Add(method);
            return this;
        }

        public ICodeClassInfoBuilder AddDataInfo(CodeDataInfo dataInfo)
        {
            _dataInfos.Add(dataInfo);
            return this;
        }

        public ICodeClassInfoBuilder AddImplementedInterface(string interfaceName)
        {
            _implementedInterfaces.Add(interfaceName);
            return this;
        }

        public ICodeClassInfoBuilder SetBaseClass(string baseClassName)
        {
            _baseClassName = baseClassName;
            return this;
        }

        public CodeClassInfo Build()
        {
            return new CodeClassInfo(
                _name,
                _accessModifier,
                _dataInfos.ToArray(),
                _methodInfos.ToArray(),
                _baseClassName,
                _implementedInterfaces.ToArray(),
                _attributes.ToArray(),
                _constructors.ToArray(),
                _genericArgs.ToArray()
            );
        }
    }
}
