﻿using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;

namespace SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces
{
    internal interface IDbContextRequestBuilder
    {
        IDbContextSetRequestBuilder ForDbSet(ProjectConfigurationDto projectInfo, UMLTableDto targetTable);

        IDbContextQueryableBuilder ForQuery(ProjectConfigurationDto projectInfo, UMLTableDto targetTable, string variableName);

        string SaveChangesAsync();
    }
}
