﻿using SharpCraftStudio.Project.Models.UML;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces
{
    internal interface IDbContextQueryableBuilder
    {
        public ProjectConfigurationDto ProjectConfiguration { get; }
        public UMLTableDto UMLTable { get; }

        IDbContextIncludeQueryableBuilder Include(string navPropertyName);

        IDbContextQueryableBuilder Where(string clause);

        IDbContextQueryableBuilder OrderBy(string propertyName);

        IDbContextQueryableBuilder OrderByDescending(string propertyName);

        IDbContextQueryableBuilder Select(string clause);

        string ToListAsync();

        string FirstOrDefaultAsync(string clause);
    }
}
