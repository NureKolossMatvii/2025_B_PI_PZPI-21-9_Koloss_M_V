﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces
{
    internal interface IDbContextIncludeQueryableBuilder : IDbContextQueryableBuilder
    {
        IDbContextIncludeQueryableBuilder ThenInclude(string navPropertyName);
    }
}
