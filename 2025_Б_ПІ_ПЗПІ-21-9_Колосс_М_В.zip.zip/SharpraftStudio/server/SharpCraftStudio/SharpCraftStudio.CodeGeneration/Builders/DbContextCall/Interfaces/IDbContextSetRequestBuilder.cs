﻿namespace SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces
{
    internal interface IDbContextSetRequestBuilder : IDbContextQueryableBuilder
    {
        string Add(string variableName);

        string Remove(string variableName);

        string Update(string variableName);
    }
}
