﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.Core.Interfaces;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;

namespace SharpCraftStudio.CodeGeneration.Builders.DbContextCall
{
    internal class DbContextQueryableBuilder : IDbContextQueryableBuilder, IIgnoreInjection
    {
        protected readonly string Query;

        public ProjectConfigurationDto ProjectConfiguration { get; }

        public UMLTableDto UMLTable { get; }

        public DbContextQueryableBuilder(string initStringCall, ProjectConfigurationDto projectConfiguration, UMLTableDto uMLTable)
        {
            Query = initStringCall;
            ProjectConfiguration = projectConfiguration;
            UMLTable = uMLTable;
        }

        public override string ToString()
        {
            return Query;
        }

        public string FirstOrDefaultAsync(string clause)
        {
            var newQuery = Query + $".FirstOrDefaultAsync({clause})";
            return newQuery;
        }

        public IDbContextIncludeQueryableBuilder Include(string navPropertyName)
        {
            var newQuery = Query + $".Include(c => c.{navPropertyName})";
            return new DbContextIncludeQueryableBuilder(newQuery, ProjectConfiguration, UMLTable);
        }

        public string ToListAsync()
        {
            var newQuery = Query + $".ToListAsync()";
            return newQuery;
        }

        public IDbContextQueryableBuilder Where(string clause)
        {
            var newQuery = Query + $".Where({clause})";
            return new DbContextQueryableBuilder(newQuery, ProjectConfiguration, UMLTable);
        }

        public IDbContextQueryableBuilder Select(string clause)
        {
            var newQuery = Query + $".Select({clause})";
            return new DbContextQueryableBuilder(newQuery, ProjectConfiguration, UMLTable);
        }

        public IDbContextQueryableBuilder OrderBy(string propertyName)
        {
            var newQuery = Query + $".OrderBy(c => c.{propertyName})";
            return new DbContextQueryableBuilder(newQuery, ProjectConfiguration, UMLTable);
        }

        public IDbContextQueryableBuilder OrderByDescending(string propertyName)
        {
            var newQuery = Query + $".OrderByDescending(c => c.{propertyName})";
            return new DbContextQueryableBuilder(newQuery, ProjectConfiguration, UMLTable);
        }
    }
}
