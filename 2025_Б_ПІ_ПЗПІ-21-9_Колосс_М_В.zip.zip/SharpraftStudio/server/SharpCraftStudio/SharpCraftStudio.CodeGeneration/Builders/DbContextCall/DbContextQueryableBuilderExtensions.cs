﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.CodeGeneration.Models;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.TableView;
using SharpCraftStudio.Project.Models.UML;

namespace SharpCraftStudio.CodeGeneration.Builders.DbContextCall
{
    internal static class DbContextQueryableBuilderExtensions
    {
        public static IDbContextQueryableBuilder IncludeAll(this IDbContextQueryableBuilder builder)
        {
            var table = builder.UMLTable;
            var projectConfig = builder.ProjectConfiguration;
            var connections = projectConfig.Diagram.Connections;

            var tablesToInclude = connections.Where(c => c.IsForTableWithId(table.TableId));

            foreach ( var connection in tablesToInclude )
            {
                var anotherTableName = connection.GetAnotherTable(table, projectConfig.Diagram.Tables).Name;
                builder = builder.Include(NavProperty.GetName(anotherTableName));
            }

            return builder;
        }

        public static IDbContextQueryableBuilder ApplyDataSelection(this IDbContextQueryableBuilder builder, IEnumerable<MethodDataSelectionParameterBase> parameters)
        {
            var table = builder.UMLTable;
            var searchStringParam = parameters.OfType<MethodDataSelectionSearchParameter>().FirstOrDefault();

            if (searchStringParam != null)
            {
                var clauseCases = new List<string>();
                foreach (var umlColumnId in searchStringParam.ApplyToUmlColumnIdes)
                {
                    var column = table.Columns.FirstOrDefault(c => c.TableColumnId == umlColumnId);
                    if(column == null)
                    {
                        continue;
                    }


                    clauseCases.Add($"c.{column.Name}.ToLower().Contains({searchStringParam.Name}.ToLower())");
                }

                builder = builder.Where($"c => {string.Join(" || ", clauseCases)}");
            }

            var filterParameters = parameters.OfType<MethodDataSelectionFilterParameter>();

            if(filterParameters.Any())
            {
                var clauseFilterCases = new List<string>();
                foreach (var filterParameter in filterParameters)
                {
                    var column = table.Columns.FirstOrDefault(c => c.TableColumnId == filterParameter.ApplyToUmlColumnId);
                    if (column == null)
                    {
                        continue;
                    }

                    var equalityComparer = string.Empty;

                    switch (filterParameter.ParameterApplyType)
                    {
                        case MethodDataSelectionFilterParameter.ApplyType.EqualTo:
                            equalityComparer = "==";
                            break;
                        case MethodDataSelectionFilterParameter.ApplyType.LowerThen:
                            equalityComparer = "<=";
                            break;
                        case MethodDataSelectionFilterParameter.ApplyType.MoreThen:
                            equalityComparer = ">=";
                            break;
                    }

                    clauseFilterCases.Add($"({filterParameter.Name} == default ||c.{column.Name} {equalityComparer} {filterParameter.Name})");
                }

                builder = builder.Where($"c => {string.Join(" && ", clauseFilterCases)}");
            }

            return builder;
        }

        public static IDbContextQueryableBuilder SelectForViewConfig(this IDbContextQueryableBuilder builder)
        {
            var table = builder.UMLTable;
            var projectConfig = builder.ProjectConfiguration;

            var tableViewConfig = projectConfig.ViewConfig.TableViewConfigs.First(c => c.UMLTableId == table.TableId);

            var clause = $$"""x => new {{tableViewConfig.GetTypeName()}}(){{{GetSelectForViewConfigArgs(tableViewConfig, table, projectConfig)}}}""";

            return builder.Select(clause);
        }

        private static string GetSelectForViewConfigArgs(TableViewConfigDto tableViewConfig, UMLTableDto targetTable, ProjectConfigurationDto projectConfiguration)
        {
            var result = new List<string>();

            var tables = projectConfiguration.Diagram.Tables;
            var targetTableConnections = projectConfiguration.Diagram.Connections
                .Where(c => c.IsForTableWithId(targetTable.TableId)).ToArray();
            var connectedTables = targetTableConnections
                .Select(c => c.GetAnotherTable(targetTable, tables)).ToArray();
            var columns = projectConfiguration.Diagram.Tables.SelectMany(c => c.Columns).ToArray();

            foreach (var columnViewConfig in tableViewConfig.ColumnViewConfigs)
            {
                var column = columns.First(c => c.TableColumnId == columnViewConfig.UMLColumnId);
                var table = tables.First(c => c.Columns.Contains(column));

                if (targetTable.TableId == table.TableId)
                {
                    var assignClause = $"{columnViewConfig.GetViewModelPropertyName()} = x.{column.Name}";
                    result.Add(assignClause);
                }
                else
                {
                    var connectedTable = connectedTables
                        .First(c => c.Columns.Contains(column));

                    var assignConnectedClause = $"{columnViewConfig.GetViewModelPropertyName()} = x.{NavProperty.GetName(connectedTable.Name)}.{column.Name}";
                    result.Add(assignConnectedClause);
                }
            }

            return string.Join(", ", result);
        }
    }
}
