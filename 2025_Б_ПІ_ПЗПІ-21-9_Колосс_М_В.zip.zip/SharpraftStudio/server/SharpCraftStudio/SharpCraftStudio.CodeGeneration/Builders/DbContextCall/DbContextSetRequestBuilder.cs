﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.Core.Interfaces;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Builders.DbContextCall
{
    internal class DbContextSetRequestBuilder : DbContextQueryableBuilder, IDbContextSetRequestBuilder, IIgnoreInjection
    {
        public DbContextSetRequestBuilder(string initStringCall, ProjectConfigurationDto projectConfiguration, UMLTableDto targetTable) : base(initStringCall, projectConfiguration, targetTable)
        {
        }

        public string Add(string variableName)
        {
            return Query + $".Add({variableName})";
        }

        public string IncludeAll()
        {
            throw new NotImplementedException();
        }

        public string Remove(string variableName)
        {
            return Query + $".Remove({variableName})";
        }

        public string Update(string variableName)
        {
            return Query + $".Update({variableName})";
        }
    }
}
