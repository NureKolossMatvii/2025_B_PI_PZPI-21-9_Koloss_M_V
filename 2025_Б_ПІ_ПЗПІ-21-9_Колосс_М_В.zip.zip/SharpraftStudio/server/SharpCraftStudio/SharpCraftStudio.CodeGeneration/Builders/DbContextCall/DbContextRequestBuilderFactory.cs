﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Builders.DbContextCall
{
    internal class DbContextRequestBuilderFactory : IDbContextRequestBuilderFactory
    {
        public IDbContextRequestBuilder CreateBuilder(string contextVariableName)
        {
            return new DbContextRequestBuilder(contextVariableName);
        }
    }
}
