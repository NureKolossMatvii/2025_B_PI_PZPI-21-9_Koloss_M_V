﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.Core.Interfaces;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Builders.DbContextCall
{
    internal class DbContextIncludeQueryableBuilder : DbContextQueryableBuilder, IDbContextIncludeQueryableBuilder, IIgnoreInjection
    {
        public DbContextIncludeQueryableBuilder(string initStringCall, ProjectConfigurationDto projectConfiguration, UMLTableDto uMLTable) : base(initStringCall, projectConfiguration, uMLTable)
        {
        }

        public IDbContextIncludeQueryableBuilder ThenInclude(string navPropertyName)
        {
            var newQuery = Query + $".ThenInclude(c => c.{navPropertyName})";
            return new DbContextIncludeQueryableBuilder(newQuery, ProjectConfiguration, UMLTable);
        }
    }
}
