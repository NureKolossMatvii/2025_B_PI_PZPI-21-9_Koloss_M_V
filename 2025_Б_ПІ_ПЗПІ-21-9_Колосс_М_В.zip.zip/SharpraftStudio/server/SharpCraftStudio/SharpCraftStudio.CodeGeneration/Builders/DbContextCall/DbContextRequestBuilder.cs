﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.Project.Models.UML;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpCraftStudio.Core.Interfaces;

namespace SharpCraftStudio.CodeGeneration.Builders.DbContextCall
{
    internal class DbContextRequestBuilder : IDbContextRequestBuilder, IIgnoreInjection
    {
        private readonly string _contextVariableName;

        public DbContextRequestBuilder(string contextVariableName)
        {
            _contextVariableName = contextVariableName;
        }

        public IDbContextSetRequestBuilder ForDbSet(ProjectConfigurationDto projectInfo, UMLTableDto targetTable)
        {
            return new DbContextSetRequestBuilder(_contextVariableName + "." + targetTable.Name, projectInfo, targetTable);
        }

        public IDbContextQueryableBuilder ForQuery(ProjectConfigurationDto projectInfo, UMLTableDto targetTable, string variableName)
        {
            return new DbContextSetRequestBuilder(variableName, projectInfo, targetTable);
        }

        public string SaveChangesAsync()
        {
            return _contextVariableName + ".SaveChangesAsync()";
        }
    }
}
