﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Builders.Interfaces
{
    internal interface ICodeClassInfoBuilder : IBuilder<CodeClassInfo>
    {
        ICodeClassInfoBuilder SetBaseClass(string baseClassName);

        ICodeClassInfoBuilder AddImplementedInterface(string interfaceName);

        ICodeClassInfoBuilder AddAttribute(CodeAttribute attribute);

        ICodeClassInfoBuilder AddDataInfo(CodeDataInfo dataInfo);

        ICodeClassInfoBuilder AddMethod(CodeMethodInfo method);

        ICodeClassInfoBuilder AddConstructor(string constructor);

        ICodeClassInfoBuilder AddGenericArg(string genericArg);
    }
}
