﻿using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Builders.Interfaces
{
    internal interface ICodeClassInfoBuilderFactory
    {
        ICodeClassInfoBuilder GetCodeClassInfoBuilder(string className, AccessModifier accessModifier);
    }
}
