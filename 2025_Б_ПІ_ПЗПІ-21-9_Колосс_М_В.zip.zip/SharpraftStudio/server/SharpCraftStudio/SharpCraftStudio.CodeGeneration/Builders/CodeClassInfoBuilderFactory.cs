﻿using SharpCraftStudio.CodeGeneration.Builders.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Builders
{
    internal class CodeClassInfoBuilderFactory : ICodeClassInfoBuilderFactory
    {
        public ICodeClassInfoBuilder GetCodeClassInfoBuilder(string className, AccessModifier accessModifier)
        {
            return new CodeClassInfoBuilder(className, accessModifier);
        }
    }
}
