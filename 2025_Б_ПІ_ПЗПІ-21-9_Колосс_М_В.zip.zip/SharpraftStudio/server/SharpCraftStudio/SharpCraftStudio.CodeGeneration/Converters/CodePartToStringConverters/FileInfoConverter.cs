﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters
{
    internal class FileInfoConverter : IFileInfoConverter
    {
        private readonly IUsingInfoConverter _usingConverter;
        private readonly INamespaceConverter _namespaceConverter;

        public FileInfoConverter(IUsingInfoConverter usingConverter, INamespaceConverter namespaceConverter)
        {
            _usingConverter = usingConverter;
            _namespaceConverter = namespaceConverter;
        }

        public string ConvertToString(CodeFileInfo source)
        {
            var usingsString = _usingConverter.ConvertToString(source.UsingInfos);
            var namespaceString = _namespaceConverter.ConvertToString(source.Namespace);

            var result = usingsString + CodePartSymbols.NEXT_LINE + namespaceString;
            return result;
        }
    }
}
