﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces
{
    internal interface IFieldInfoConverter : ICodePartToStringConverter<CodeDataInfo>
    {
        string ConvertToString(IEnumerable<CodeDataInfo> source);
    }
}
