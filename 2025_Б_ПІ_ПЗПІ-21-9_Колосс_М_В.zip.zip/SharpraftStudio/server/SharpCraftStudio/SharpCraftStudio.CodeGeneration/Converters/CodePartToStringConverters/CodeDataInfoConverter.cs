﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters
{
    internal class CodeDataInfoConverter : ICodeDataInfoConverter
    {
        private readonly IFieldInfoConverter _fieldInfoConverter;
        private readonly IPropertyInfoConverter _propertyInfoConverter;

        public CodeDataInfoConverter(IFieldInfoConverter fieldInfoConverter, IPropertyInfoConverter propertyInfoConverter)
        {
            _fieldInfoConverter = fieldInfoConverter;
            _propertyInfoConverter = propertyInfoConverter;
        }

        public string ConvertToString(CodeDataInfo codeDataInfo)
        {
            if (codeDataInfo.DataInfoTypeModifier == DataInfoTypeModifier.Property)
            {
                return _propertyInfoConverter.ConvertToString(codeDataInfo);
            }

            if (codeDataInfo.DataInfoTypeModifier == DataInfoTypeModifier.Field)
            {
                return _fieldInfoConverter.ConvertToString(codeDataInfo);
            }

            throw new NotImplementedException();
        }

        public string ConvertToString(IEnumerable<CodeDataInfo> source)
        {
            return string.Join(CodePartSymbols.NEXT_LINE, source.Select(ConvertToString));
        }
    }
}
