﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters
{
    internal class MethodInfoConverter : IMethodInfoConverter
    {
        private readonly IAttributeConverter _attributeConverter;

        public MethodInfoConverter(IAttributeConverter attributeConverter)
        {
            _attributeConverter = attributeConverter;
        }

        public string ConvertToString(CodeMethodInfo codeDataInfo)
        {
            var result = $$"""
                {{_attributeConverter.ConvertToString(codeDataInfo.Attributes)}}
                {{codeDataInfo.AccessModifier.ConvertToString()}} {{GetExecutionProcessModifierIfExist(codeDataInfo)}} {{codeDataInfo.ReturnType}} {{codeDataInfo.MethodName}}({{GetParameters(codeDataInfo)}})
                {
                {{codeDataInfo.Code}}
                }
                """;

            return result;
        }

        public string ConvertToString(IEnumerable<CodeMethodInfo> source)
        {
            return string.Join(CodePartSymbols.NEXT_LINE, source.Select(ConvertToString));
        }

        private string GetExecutionProcessModifierIfExist(CodeMethodInfo codeDataInfo)
        {
            return codeDataInfo.ExecutionProcessModifier == ExecutionProcessModifier.Synchronous ? string.Empty : "async";
        }

        private string GetParameters(CodeMethodInfo codeDataInfo)
        {
            return string.Join(", ", codeDataInfo.Parameters.Select(c => c.Type + (c.Nullable ? "?" : string.Empty)+ " " + c.Name));
        }
    }
}
