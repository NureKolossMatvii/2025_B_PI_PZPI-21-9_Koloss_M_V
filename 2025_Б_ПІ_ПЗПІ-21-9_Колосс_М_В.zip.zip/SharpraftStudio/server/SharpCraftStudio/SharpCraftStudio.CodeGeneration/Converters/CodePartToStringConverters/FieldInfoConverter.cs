﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters
{
    internal class FieldInfoConverter : IFieldInfoConverter
    {
        public string ConvertToString(CodeDataInfo codeDataInfo)
        {
            return $"{codeDataInfo.AccessModifier.ConvertToString()} {codeDataInfo.TypeName} {codeDataInfo.Name};";
        }

        public string ConvertToString(IEnumerable<CodeDataInfo> source)
        {
            return string.Join(CodePartSymbols.NEXT_LINE, source.Select(ConvertToString));
        }
    }
}
