﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters
{
    internal class AttributeConverter : IAttributeConverter
    {
        public string ConvertToString(CodeAttribute source)
        {
            return $"[{source.Name}{GetParamsIfExist(source)}]";
        }

        public string ConvertToString(IEnumerable<CodeAttribute> source)
        {
            return string.Join(CodePartSymbols.NEXT_LINE, source.Select(ConvertToString).ToArray());
        }


        private string GetParamsIfExist(CodeAttribute source)
        {
            if (source.Params is null)
            {
                return string.Empty;
            }

            return $"({source.Params})";
        }
    }
}
