﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters
{
    internal class PropertyInfoConverter : IPropertyInfoConverter
    {
        private readonly IAttributeConverter _attributeConverter;

        public PropertyInfoConverter(IAttributeConverter attributeConverter)
        {
            _attributeConverter = attributeConverter;
        }

        public string ConvertToString(CodeDataInfo codeDataInfo)
        {
            return GetAttributesIfExist(codeDataInfo) +
                 $"{codeDataInfo.AccessModifier.ConvertToString()} {codeDataInfo.TypeName} {codeDataInfo.Name}" + " { get; set; }";
        }

        private string GetAttributesIfExist(CodeDataInfo codeDataInfo)
        {
            return codeDataInfo.Attributes.Any() ? _attributeConverter.ConvertToString(codeDataInfo.Attributes) + CodePartSymbols.NEXT_LINE : string.Empty;
        }

        public string ConvertToString(IEnumerable<CodeDataInfo> source)
        {
            return string.Join(CodePartSymbols.NEXT_LINE, source.Select(ConvertToString));
        }
    }
}
