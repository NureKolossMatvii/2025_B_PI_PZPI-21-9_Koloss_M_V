﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters
{
    internal class UsingInfoConverter : IUsingInfoConverter
    {
        public string ConvertToString(CodeUsingInfo source)
        {
            return $"using {source.AssemblyName}{CodePartSymbols.SEMICOLON}";
        }

        public string ConvertToString(IEnumerable<CodeUsingInfo> source)
        {
            return string.Join(CodePartSymbols.NEXT_LINE, source.Select(ConvertToString));
        }
    }
}
