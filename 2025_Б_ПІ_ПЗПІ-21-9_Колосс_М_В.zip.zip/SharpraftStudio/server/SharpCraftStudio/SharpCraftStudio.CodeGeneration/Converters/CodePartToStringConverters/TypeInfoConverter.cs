﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters
{
    internal class TypeInfoConverter : ITypeInfoConverter
    {
        private readonly IClassConverter _classConverter;
        private readonly IEnumInfoConverter _enumConverter;

        public TypeInfoConverter(IClassConverter classConverter, IEnumInfoConverter enumConverter)
        {
            _classConverter = classConverter;
            _enumConverter = enumConverter;
        }

        public string ConvertToString(CodeTypeInfo source)
        {
            if (source is CodeClassInfo classInfo)
            {
                return _classConverter.ConvertToString(classInfo);
            }

            if (source is CodeEnumInfo codeEnum)
            {
                return _enumConverter.ConvertToString(codeEnum);
            }

            throw new NotImplementedException();
        }
    }
}
