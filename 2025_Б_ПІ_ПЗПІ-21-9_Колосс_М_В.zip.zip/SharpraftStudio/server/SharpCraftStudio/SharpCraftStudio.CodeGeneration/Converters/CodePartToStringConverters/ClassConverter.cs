﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters
{
    internal class ClassConverter : IClassConverter
    {
        private readonly IAttributeConverter _attributeConverter;
        private readonly ICodeDataInfoConverter _codeDataInfoConverter;
        private readonly IMethodInfoConverter _methodConverter;

        public ClassConverter(IAttributeConverter attributeConverter, ICodeDataInfoConverter codeDataInfoConverter, IMethodInfoConverter methodConverter)
        {
            _attributeConverter = attributeConverter;
            _codeDataInfoConverter = codeDataInfoConverter;
            _methodConverter = methodConverter;
        }

        public string ConvertToString(CodeClassInfo source)
        {
            return $"""
                {GetClassHead(source)}
                {CodePartSymbols.OPEN_BRACE}
                {GetConstructorsIfExist(source)}
                {_codeDataInfoConverter.ConvertToString(source.DataInfos.Where(c => c.DataInfoTypeModifier == DataInfoTypeModifier.Field))}

                {_codeDataInfoConverter.ConvertToString(source.DataInfos.Where(c => c.DataInfoTypeModifier == DataInfoTypeModifier.Property))}

                {_methodConverter.ConvertToString(source.MethodInfos)}
                {CodePartSymbols.CLOSE_BRACE}
                """;
        }

        private string GetClassHead(CodeClassInfo source)
        {
            return GetAttributesIfExist(source) + $"{source.AccessModifier.ConvertToString()} class {source.Name}" + GetGenericArgsIfExist(source) + GetParentModifierIfExist(source);
        }

        public string GetGenericArgsIfExist(CodeClassInfo source)
        {
            if (!source.GenericArgs.Any())
            {
                return string.Empty;
            }

            return $"<{string.Join(", ", source.GenericArgs)}>";
        }


        public string GetConstructorsIfExist(CodeClassInfo source)
        {
            if (!source.Constractors.Any())
            {
                return string.Empty;
            }

            return string.Join(CodePartSymbols.NEXT_LINE, source.Constractors);
        }

        public string GetAttributesIfExist(CodeClassInfo source)
        {
            if (!source.Attributes.Any())
            {
                return string.Empty;
            }

            return _attributeConverter.ConvertToString(source.Attributes) + CodePartSymbols.NEXT_LINE;
        }

        private string GetParentModifierIfExist(CodeClassInfo source)
        {
            if (source.ImplementedInterfaces.Length == 0 && source.BaseClassName == null)
            {
                return string.Empty;
            }

            if (source.ImplementedInterfaces.Length == 0)
            {
                return $" : {source.BaseClassName}";
            }

            if (source.BaseClassName == null)
            {
                return $" : {string.Join(", ", source.ImplementedInterfaces)}";
            }

            return $" : {source.BaseClassName}, {string.Join(", ", source.ImplementedInterfaces)}";
        }
    }
}
