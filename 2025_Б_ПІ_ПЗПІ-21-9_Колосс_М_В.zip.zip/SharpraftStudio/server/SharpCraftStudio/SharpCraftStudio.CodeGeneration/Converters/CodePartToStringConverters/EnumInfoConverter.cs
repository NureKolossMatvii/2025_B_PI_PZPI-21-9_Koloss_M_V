﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters
{
    internal class EnumInfoConverter : IEnumInfoConverter
    {
        public string ConvertToString(CodeEnumInfo source)
        {
            return $$"""
                {{source.AccessModifier.ConvertToString()}} enum {{source.Name}}
                {
                    {{GetItems(source)}}
                }
                """;
        }

        public static string GetItems(CodeEnumInfo source)
        {
            var result = new StringBuilder();

            foreach (var item in source.Items)
            {
                result.AppendLine(item + ",");
            }

            return result.ToString();
        }

    }
}
