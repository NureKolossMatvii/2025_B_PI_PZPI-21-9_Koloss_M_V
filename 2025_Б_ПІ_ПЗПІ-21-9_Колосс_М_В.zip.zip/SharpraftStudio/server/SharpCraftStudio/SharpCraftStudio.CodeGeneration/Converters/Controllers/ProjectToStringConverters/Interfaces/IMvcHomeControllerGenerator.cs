﻿using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToStringConverters.Interfaces
{
    internal interface IMvcHomeControllerGenerator
    {
        ProjectFileInfo Generate(ProjectConfigurationDto projectConfiguration);
    }
}
