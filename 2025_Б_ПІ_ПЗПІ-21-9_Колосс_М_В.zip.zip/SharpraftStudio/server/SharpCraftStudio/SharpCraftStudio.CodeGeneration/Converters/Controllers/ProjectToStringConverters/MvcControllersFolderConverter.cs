﻿using SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToStringConverters
{
    internal class MvcControllersFolderConverter : IMvcControllersFolderConverter
    {
        private readonly IMvcControllerFileContentConverter _modelConverter;
        private readonly IMvcHomeControllerGenerator _homeControllerGenerator;

        public MvcControllersFolderConverter(IMvcControllerFileContentConverter modelConverter, IMvcHomeControllerGenerator homeControllerGenerator)
        {
            _modelConverter = modelConverter;
            _homeControllerGenerator = homeControllerGenerator;
        }

        public ProjectFolderInfo ConvertToFolder(ProjectConfigurationDto projectConfiguration)
        {
            var result = new ProjectFolderInfo("Controllers");

            foreach (var table in projectConfiguration.Diagram.Tables)
            {
                var fileContent = _modelConverter.ConvertToString(projectConfiguration, _ => table);
                var fileInfo = new ProjectFileInfo(table.Name + "Controller", FileExtension.CS, fileContent);

                result.AddItem(fileInfo);
            }

            result.AddItem(_homeControllerGenerator.Generate(projectConfiguration));

            return result;
        }
    }
}
