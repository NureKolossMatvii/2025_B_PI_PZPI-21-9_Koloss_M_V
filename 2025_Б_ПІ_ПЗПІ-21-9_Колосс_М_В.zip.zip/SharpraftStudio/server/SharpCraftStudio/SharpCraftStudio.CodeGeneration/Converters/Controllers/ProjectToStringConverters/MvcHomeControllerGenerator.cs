﻿using SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToStringConverters
{
    internal class MvcHomeControllerGenerator : IMvcHomeControllerGenerator
    {
        public ProjectFileInfo Generate(ProjectConfigurationDto projectConfiguration)
        {
            var content = $$"""
                using Microsoft.AspNetCore.Mvc;

                namespace {{NamespaceNames.GetControllersNamespace(projectConfiguration.Name)}}
                {
                    public class HomeController : Controller
                    {
                        public IActionResult Index()
                        {
                            return View();
                        }
                    }
                }
                """;

            return new ProjectFileInfo("HomeController", FileExtension.CS, content);
        }
    }
}
