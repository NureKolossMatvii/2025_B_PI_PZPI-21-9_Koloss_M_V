﻿using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToStringConverters
{
    internal class MvcControllerFileContentConverter : IMvcControllerFileContentConverter
    {
        private readonly IMvcControllerFileInfoConverter _fileInfoConverter;
        private readonly IFileInfoConverter _toStringConverter;

        public MvcControllerFileContentConverter(IMvcControllerFileInfoConverter fileInfoConverter, IFileInfoConverter toStringConverter)
        {
            _fileInfoConverter = fileInfoConverter;
            _toStringConverter = toStringConverter;
        }

        public string ConvertToString(ProjectConfigurationDto projectConfiguration, Func<IEnumerable<UMLTableDto>, UMLTableDto> getUmlTable)
        {
            var codeInfo = _fileInfoConverter.GetCodeClassInfo(projectConfiguration, getUmlTable);
            var fileContent = _toStringConverter.ConvertToString(codeInfo);

            return fileContent;
        }
    }
}
