﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToCodePartConverters
{
    internal class MvcControllerFileInfoConverter : IMvcControllerFileInfoConverter
    {
        private readonly IMvcControllerClassPartConverter _classCreator;

        public MvcControllerFileInfoConverter(IMvcControllerClassPartConverter classCreator)
        {
            _classCreator = classCreator;
        }

        public CodeFileInfo GetCodeClassInfo(ProjectConfigurationDto projectConfiguration, Func<IEnumerable<UMLTableDto>, UMLTableDto> getUmlTable)
        {
            var classInfo = _classCreator.GetCodeClassInfo(projectConfiguration, getUmlTable);
            var projectName = projectConfiguration.Name;

            var namespaceInfo = new CodeNamespaceInfo(NamespaceNames.GetControllersNamespace(projectName), classInfo);

            var usings = new CodeUsingInfo[]
            {
                new CodeUsingInfo(NamespaceNames.GetEFCoreModelsNamespace(projectName)),
                new CodeUsingInfo(NamespaceNames.GetEFCoreContextNamespace(projectName)),
                new CodeUsingInfo(NamespaceNames.GetViewModelsNamespace(projectName)),
                CodeUsingInfo.ENTITY_FRAMEWORK_CORE,
                CodeUsingInfo.ASPNETCORE_MVC,
                CodeUsingInfo.ASPNETCORE_MVC_RENDERING,
                CodeUsingInfo.SYSTEM_LINQ,
                CodeUsingInfo.SYSTEM_TASKS,
                CodeUsingInfo.SYSTEM
            };

            var fileInfo = new CodeFileInfo(namespaceInfo, usings);

            return fileInfo;
        }
    }
}
