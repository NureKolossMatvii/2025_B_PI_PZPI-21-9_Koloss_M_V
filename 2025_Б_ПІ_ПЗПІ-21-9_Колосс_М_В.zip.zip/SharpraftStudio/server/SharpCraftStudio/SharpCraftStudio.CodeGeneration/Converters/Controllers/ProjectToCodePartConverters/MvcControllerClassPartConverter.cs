﻿using SharpCraftStudio.CodeGeneration.Builders.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.ControllerMethods.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToCodePartConverters
{
    internal class MvcControllerClassPartConverter : IMvcControllerClassPartConverter
    {
        private readonly ICodeClassInfoBuilderFactory _codeClassInfoBuilderFactory;
        private readonly IEnumerable<IMvcControllerMethodInfoConverter> _methodCreators;

        public MvcControllerClassPartConverter(ICodeClassInfoBuilderFactory codeClassInfoBuilderFactory, IEnumerable<IMvcControllerMethodInfoConverter> methodCreators)
        {
            _codeClassInfoBuilderFactory = codeClassInfoBuilderFactory;
            _methodCreators = methodCreators;
        }

        public CodeClassInfo GetCodeClassInfo(ProjectConfigurationDto projectConfiguration, Func<IEnumerable<UMLTableDto>, UMLTableDto> getUmlTable)
        {
            var table = getUmlTable(projectConfiguration.Diagram.Tables);
            var constructorClassName = table.Name + "Controller";
            var classBuilder = _codeClassInfoBuilderFactory.GetCodeClassInfoBuilder(constructorClassName, AccessModifier.Public);

            classBuilder.SetBaseClass("Controller");
            classBuilder.AddConstructor($$"""
                public {{constructorClassName}}({{GlobalClassNames.DBCONTEXT_CLASSNAME}} context)
                {
                    _context = context;
                }
                """);

            classBuilder.AddDataInfo(new CodeDataInfo("_context", AccessModifier.Private, GlobalClassNames.DBCONTEXT_CLASSNAME, DataInfoTypeModifier.Field, new()));

            var methodInfos = _methodCreators.Select(c => c.Convert(projectConfiguration, table, "_context"));
            foreach(var methodInfo in methodInfos)
            {
                classBuilder.AddMethod(methodInfo);
            }

            return classBuilder.Build();
        }
    }
}
