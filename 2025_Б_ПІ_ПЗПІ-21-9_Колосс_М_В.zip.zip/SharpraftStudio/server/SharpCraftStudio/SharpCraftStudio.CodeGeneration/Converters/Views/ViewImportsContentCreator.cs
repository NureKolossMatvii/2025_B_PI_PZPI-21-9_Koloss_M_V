﻿using SharpCraftStudio.CodeGeneration.Converters.Views.Interfaces;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Views
{
    internal class ViewImportsContentCreator : IViewImportsContentCreator
    {
        public string GetViewContent(ProjectConfigurationDto project)
        {
            return $$"""
                @using {{NamespaceNames.GetEFCoreModelsNamespace(project.Name)}}
                @using {{project.Name}}
                @addTagHelper *, Microsoft.AspNetCore.Mvc.TagHelpers
                """;
        }
    }
}
