﻿using SharpCraftStudio.CodeGeneration.Converters.Views.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Views
{
    internal class ViewStartContentCreator : IViewStartContentCreator
    {
        public string GetViewContent()
        {
            return """
                @{
                    Layout = "_Layout";
                }
                """;
        }
    }
}
