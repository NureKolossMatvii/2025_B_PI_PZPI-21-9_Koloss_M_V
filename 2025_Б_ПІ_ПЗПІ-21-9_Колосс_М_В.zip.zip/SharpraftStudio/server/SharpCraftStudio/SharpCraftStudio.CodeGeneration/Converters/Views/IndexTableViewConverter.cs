﻿using SharpCraftStudio.CodeGeneration.Converters.DataSelection.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.Views.Interfaces;
using SharpCraftStudio.CodeGeneration.Models;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.TableView;
using SharpCraftStudio.Project.Models.UML;
using System.Text;

namespace SharpCraftStudio.CodeGeneration.Converters.Views
{
    internal class IndexTableViewConverter : ITableViewConverter
    {
        private IDataSelectionParametersGenerator _parameterGenerator;

        public IndexTableViewConverter(IDataSelectionParametersGenerator parameterGenerator)
        {
            _parameterGenerator = parameterGenerator;
        }

        public string ViewName => "Index";

        public string GetViewContent(ProjectConfigurationDto project, UMLTableDto table)
        {
            var tableViewConfig = project.ViewConfig.TableViewConfigs.First(c => c.UMLTableId == table.TableId);
            var primaryKeyColumn = table.Columns.First(c => c.IsPrimaryKey);
            var parameters = _parameterGenerator.GenerateForTable(project, table.TableId);

            var result = $$"""
                @model IEnumerable<{{NamespaceNames.GetViewModelsNamespace(project.Name)}}.{{tableViewConfig.GetTypeName()}}>
                @{
                    ViewData["Title"] = "{{tableViewConfig.Label}}";
                }

                <h1 class="scs-color">{{tableViewConfig.Label}}</h1>


                <p>
                    <a asp-action="Create"><button class="btn scs-default-button-background-color scs-default-button-text-color">Create New</button></a>
                </p>
                
                {{GetFilterForm(parameters)}}
                <table class="customTable scs-background-color">
                    <thead class="scs-table-border-bottom-color">
                        <tr class="scs-color">
                            {{GetTableColumnNames(tableViewConfig)}}
                            <th></th>
                        </tr>
                    </thead>
                    <tbody class="scs-color">
                        @foreach (var item in Model) {
                            <tr class="scs-table-border-bottom-color">
                                {{GetTableColumnValues(tableViewConfig)}}
                                <td>
                                    <a asp-action="Edit" asp-route-id="@item.{{primaryKeyColumn.Name}}"><button class="btn scs-edit-button-background-color scs-edit-button-text-color">Edit</button></a>
                                    <a asp-action="Details" asp-route-id="@item.{{primaryKeyColumn.Name}}"><button class="btn scs-default-button-background-color scs-default-button-text-color">Details</button></a>
                                    <a asp-action="Delete" asp-route-id="@item.{{primaryKeyColumn.Name}}"><button class="btn scs-delete-button-background-color scs-delete-button-text-color">Delete</button></a>
                                </td>
                            </tr>
                        }
                    </tbody>
                </table>
                
                """;

            return result;
        }

        private string GetFilterForm(IEnumerable<MethodDataSelectionParameterBase> parameters)
        {
            if (!parameters.Any())
            {
                return string.Empty;
            }

            return $"""
                <div class="table__search">
                    <form asp-action="Index">
                        {GetSearchBlock(parameters.OfType<MethodDataSelectionSearchParameter>().FirstOrDefault())}
                        <div class="table__search__block">
                            {GetSortItem(parameters.OfType<MethodDataSelectionSortParameter>().FirstOrDefault())}
                            {GetFilterItems(parameters.OfType<MethodDataSelectionFilterParameter>())}
                        </div>
                           <div class="searchSubmit">
                                <button type="submit" class="btn scs-default-button-background-color scs-default-button-text-color">Search</button>
                           </div>
                    </form>
                </div>
                """;
        }

        private string GetSearchBlock(MethodDataSelectionSearchParameter? searchParameter)
        {
            if (searchParameter is null)
            {
                return string.Empty;
            }

            return $$"""
                        
                <div class="table__search__item">
                    <div class="input-group-prepend">
                        <span class="input-group-text scs-default-button-background-color scs-default-button-color" id="inputGroup-sizing-default">Search</span>
                    </div>
                    <input type="text" class="form-control scs-input scs-background-color scs-color scs-border-color" aria-label="Default" value="@ViewBag.{{searchParameter.Name}}" name="{{searchParameter.Name}}" aria-describedby="inputGroup-sizing-default">
                </div>
                """;
        }

        private string GetSortItem(MethodDataSelectionSortParameter? sortParameter)
        {
            if (sortParameter is null)
            {
                return string.Empty;
            }

            var options = new StringBuilder();

            for (int i = 0; i < sortParameter.EnumValues.Count; i++)
            {
                var enumValue = sortParameter.EnumValues[i];
                options.AppendLine($"<option selected=\"@((int)ViewBag.{sortParameter.Name} == {i})\" value={i}>{enumValue.EnumValueName}</option>");
            }

            return $"""
                <div class="table__search__item">
                    <div class="input-group-prepend">
                        <span class="input-group-text scs-default-button-background-color scs-default-button-color" id="inputGroup-sizing-default">{sortParameter.Label}</span>
                    </div>
                    <select class="custom-select scs-input scs-background-color scs-color scs-border-color" name="{sortParameter.Name}">
                        {options.ToString()}
                    </select>
                </div>
                """;
        }

        private string GetFilterItems(IEnumerable<MethodDataSelectionFilterParameter> filterParameters)
        {
            if (!filterParameters.Any())
            {
                return string.Empty;
            }

            var result = new StringBuilder();

            foreach (var filterParameter in filterParameters)
            {
                result.AppendLine($"""
                    <div class="table__search__item">
                        <div class="input-group-prepend">
                            <span class="input-group-text scs-default-button-background-color scs-default-button-color" id="inputGroup-sizing-default">{filterParameter.Label}</span>
                        </div>
                        {GetFilterInput(filterParameter)}
                    </div>
                    """);
            }

            return result.ToString();
        }

        private string GetFilterInput(MethodDataSelectionFilterParameter filterParameter)
        {
            switch (filterParameter.Type)
            {
                case "bool":
                    return $"""
                        <select class="custom-select scs-input scs-background-color scs-color scs-border-color" name="{filterParameter.Name}">
                            <option selected="@(ViewBag.{filterParameter.Name} == null)" >Any</option>
                            <option selected="@(ViewBag.{filterParameter.Name} == true)" value="true">True</option>
                            <option selected="@(ViewBag.{filterParameter.Name} == false)" value="false">False</option>
                        </select>
                        """;
                default:
                    return $"<input type=\"{GetFilterInputType(filterParameter.Type)}\" class=\"form-control scs-input scs-background-color scs-color scs-border-color\" aria-label=\"Default\" {GetFilterValueTag(filterParameter)} name=\"{filterParameter.Name}\" aria-describedby=\"inputGroup-sizing-default\">";
            }
        }

        private string GetFilterValueTag(MethodDataSelectionFilterParameter filterParameter)
        {
            switch (filterParameter.Type)
            {
                case "int":
                case "double":
                    return $"value = \"@ViewBag.{filterParameter.Name}\"";
                case "DateTime":
                    return $"value = \"@ViewBag.{filterParameter.Name}.ToString(\"yyyy-MM-dd\")\"";
            }

            throw new NotImplementedException();
        }

        private string GetFilterInputType(string type)
        {
            switch (type)
            {
                case "DateTime":
                    return "date";
                case "int":
                case "double":
                    return "number";
            }

            throw new NotImplementedException();
        }


        private string GetTableColumnNames(TableViewConfigDto tableViewConfig)
        {
            var columnViewConfigs = tableViewConfig.ColumnViewConfigs;
            var result = new StringBuilder();

            foreach (var column in columnViewConfigs)
            {
                result.Append($$"""
                    <th>
                        {{column.Label}}
                    </th>
                    """);
            }

            return result.ToString();
        }

        private string GetTableColumnValues(TableViewConfigDto tableViewConfig)
        {
            var columnViewConfigs = tableViewConfig.ColumnViewConfigs;
            var result = new StringBuilder();


            foreach (var columnViewConfig in columnViewConfigs)
            {
                result.Append($$"""
                    <td>
                        @Html.DisplayFor(modelItem => item.{{columnViewConfig.GetViewModelPropertyName()}})
                    </td>
                    """);
            }

            return result.ToString();
        }
    }
}
