﻿using SharpCraftStudio.CodeGeneration.Converters.Views.Interfaces;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Views
{
    internal class LayoutViewConverter : ILayoutViewConverter
    {
        public string GetViewContent(UMLDiagramDto diagram, string projectName)
        {
            var navigationLinks = GenerateNavigationLinks(diagram.Tables);

            var content = $$"""
                <!DOCTYPE html>
                <html lang="en">
                <head>
                    <meta charset="utf-8" />
                    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
                    <title>@ViewData["Title"] - {{projectName}}</title>
                    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
                    <link rel="stylesheet" href="~/main.css" />
                </head>
                <body class="scs-background-color">
                    <header class="scs-background-color">
                        <nav class="navbar navbar-expand-sm navbar-toggleable-sm mb-3 scs-border-bottom-color">
                            <div class="container">
                                <a class="navbar-brand scs-color" asp-area="" asp-controller="Home" asp-action="Index">{{projectName}}</a>
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target=".navbar-collapse" aria-controls="navbarSupportedContent"
                                        aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="navbar-toggler-icon"></span>
                                </button>
                                <div class="navbar-collapse collapse d-sm-inline-flex justify-content-between">
                                    <ul class="navbar-nav flex-grow-1">
                                        {{navigationLinks}}
                                    </ul>
                                </div>
                            </div>
                        </nav>
                    </header>
                    <div class="container">
                        <main role="main" class="pb-3">
                            @RenderBody()
                        </main>
                    </div>

                    <script src="~/lib/jquery/dist/jquery.min.js"></script>
                    <script src="~/lib/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
                    <script src="~/js/site.js" asp-append-version="true"></script>
                    @await RenderSectionAsync("Scripts", required: false)
                </body>
                </html>
                """;

            return content;
        }

        private string GenerateNavigationLinks(IEnumerable<UMLTableDto> tables)
        {
            var links = new StringBuilder();

            foreach (var table in tables)
            {
                links.Append($$"""
                    <li class="nav-item">
                        <a class="nav-link scs-color" asp-area="" asp-controller="{{table.Name}}" asp-action="Index">{{table.Name}}</a>
                    </li>
                """);
            }

            return links.ToString();
        }
    }
}
