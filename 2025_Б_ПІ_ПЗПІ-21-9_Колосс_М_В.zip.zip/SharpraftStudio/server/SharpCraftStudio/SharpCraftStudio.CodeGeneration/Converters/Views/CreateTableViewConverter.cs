﻿using SharpCraftStudio.CodeGeneration.Converters.Views.Interfaces;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Views
{
    internal class CreateTableViewConverter : ITableViewConverter
    {
        public string ViewName => "Create";

        public string GetViewContent(ProjectConfigurationDto project, UMLTableDto table)
        {
            var viewConfig = project.ViewConfig.TableViewConfigs.First(c => c.UMLTableId == table.TableId);
            var result = $$"""
                @model {{NamespaceNames.GetEFCoreModelsNamespace(project.Name)}}.{{table.Name}}
                @{
                    ViewData["Title"] = "Create";
                }

                <h1 class="scs-color">Create</h1>

                <h4 class="scs-color">{{viewConfig.Label}}</h4>
                <hr />
                <div class="row">
                    <div class="col-md-4">
                        <form asp-action="Create">
                            <div asp-validation-summary="ModelOnly" class="text-danger"></div>
                            {{GetInputs(project, table)}}
                            <div class="form-group">
                                <button type="submit" class="btn scs-default-button-background-color scs-default-button-text-color">Create</button>
                            </div>
                        </form>
                    </div>
                </div>

                <div>
                    <a asp-action="Index"><button class="btn scs-default-button-background-color scs-default-button-text-color">Back to List</button></a>
                </div>
                """;

            return result;
        }


        private string GetInputs(ProjectConfigurationDto project, UMLTableDto table)
        {
            var result = new StringBuilder();
            var columns = table.Columns.Where(c => !c.IsPrimaryKey);

            foreach (var column in columns)
            {
                if (column.IsForeignKey)
                {
                    result.Append($"""
                        <div class="form-group">
                              <label asp-for="{column.Name}" class="control-label scs-color"></label>
                              <select asp-for="{column.Name}" class="form-control scs-background-color scs-color scs-border-color scs-input" asp-items="ViewBag.{column.Name}"></select>
                        </div>
                        """);
                }
                else
                {
                    switch (column.DataType)
                    {
                        case UMLColumnDataType.Boolean:
                            result.Append($"""
                        <div class="form-group">
                            <label asp-for="{column.Name}" class="scs-checkbox-container scs-color">
                                <div class="scs-checkbox-label">{column.Name}</div>
                                <input asp-for="{column.Name}" class="form-control scs-background-color scs-color scs-border-color scs-input" />
                                <span class="scs-checkmark"></span>
                            </label>
                            <span asp-validation-for="{column.Name}" class="text-danger"></span>
                        </div>
                        """);
                        break;
                        default:
                            result.Append($"""
                        <div class="form-group">
                            <label asp-for="{column.Name}" class="control-label scs-color"></label>
                            <input asp-for="{column.Name}" class="form-control scs-background-color scs-color scs-border-color scs-input" />
                            <span asp-validation-for="{column.Name}" class="text-danger"></span>
                        </div>
                        """);
                            break;
                    }
                }
            }

            return result.ToString();
        }
    }
}
