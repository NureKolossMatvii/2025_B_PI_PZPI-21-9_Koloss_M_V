﻿using SharpCraftStudio.CodeGeneration.Converters.Views.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Views
{
    internal class ViewFolderConverter : IViewFolderConverter
    {
        private readonly ILayoutViewConverter _layoutViewConverter;
        private readonly IViewStartContentCreator _viewStartContentCreator;
        private readonly IViewImportsContentCreator _viewImportsContentCreator;
        private readonly IViewTableEntityFolderConverter _viewTableEntityFolderConverter;
        private readonly IHomeViewConverter _homeViewConverter;

        public ViewFolderConverter(ILayoutViewConverter layoutViewConverter, IViewStartContentCreator viewStartContentCreator, IViewImportsContentCreator viewImportsContentCreator, IViewTableEntityFolderConverter viewTableEntityFolderConverter, IHomeViewConverter homeViewConverter)
        {
            _layoutViewConverter = layoutViewConverter;
            _viewStartContentCreator = viewStartContentCreator;
            _viewImportsContentCreator = viewImportsContentCreator;
            _viewTableEntityFolderConverter = viewTableEntityFolderConverter;
            _homeViewConverter = homeViewConverter;
        }

        public ProjectFolderInfo ConvertToFolder(ProjectConfigurationDto project)
        {
            var resultFolder = new ProjectFolderInfo("Views");

            var sharedFolder = new ProjectFolderInfo("Shared");
            sharedFolder.AddItem(new ProjectFileInfo("_Layout", FileExtension.CSHtml, _layoutViewConverter.GetViewContent(project.Diagram, project.Name)));
            var homeFolder = new ProjectFolderInfo("Home");
            homeFolder.AddItem(new ProjectFileInfo("Index", FileExtension.CSHtml, _homeViewConverter.GetViewContent(project)));

            resultFolder.AddItem(sharedFolder);
            resultFolder.AddItem(homeFolder);

            foreach (var table in project.Diagram.Tables)
            {
                resultFolder.AddItem(_viewTableEntityFolderConverter.GetFolder(project, table));
            }


            resultFolder.AddItem(new ProjectFileInfo("_ViewImports", FileExtension.CSHtml, _viewImportsContentCreator.GetViewContent(project)));
            resultFolder.AddItem(new ProjectFileInfo("_ViewStart", FileExtension.CSHtml, _viewStartContentCreator.GetViewContent()));

            return resultFolder;
        }
    }
}
