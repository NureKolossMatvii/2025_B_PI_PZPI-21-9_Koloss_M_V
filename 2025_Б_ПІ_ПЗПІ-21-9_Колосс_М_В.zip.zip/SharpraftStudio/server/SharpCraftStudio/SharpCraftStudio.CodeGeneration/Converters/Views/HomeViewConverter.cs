﻿using SharpCraftStudio.CodeGeneration.Converters.Views.Interfaces;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Views
{
    internal class HomeViewConverter : IHomeViewConverter
    {
        public string GetViewContent(ProjectConfigurationDto projectConfigurationDto)
        {
            return $$"""
                @{
                    ViewData["Title"] = "{{projectConfigurationDto.Name}}";
                }
                """;
        }
    }
}
