﻿using SharpCraftStudio.CodeGeneration.Converters.Views.Interfaces;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Views
{
    internal class DetailsTableViewConverter : ITableViewConverter
    {
        public string ViewName => "Details";

        public string GetViewContent(ProjectConfigurationDto project, UMLTableDto table)
        {
            var viewConfig = project.ViewConfig.TableViewConfigs.First(c => c.UMLTableId == table.TableId);
            return $$"""
                @model {{NamespaceNames.GetEFCoreModelsNamespace(project.Name)}}.{{table.Name}}
                @{
                    ViewData["Title"] = "Details";
                }
                
                <h1 class="scs-color">Item info</h1>
                <div>
                    <h4 class="scs-color">{{viewConfig.Label}}</h4>
                    <hr />
                    <dl class="row">
                        {{GetLabels(project, table)}}
                    </dl>

                    <a asp-action="Index"><button class="btn scs-default-button-background-color scs-default-button-text-color">Back to List</button></a>
                </div>
                
                """;
        }

        private string GetLabels(ProjectConfigurationDto project, UMLTableDto table)
        {
            var result = new StringBuilder();
            var columns = table.Columns.Where(c => !c.IsPrimaryKey);

            foreach (var column in columns)
            {
                if (column.IsForeignKey)
                {
                    var connection = project.Diagram.Connections.First(c => c.ForeignKeyColumnId == column.TableColumnId);
                    var otherTable = connection.GetAnotherTable(table, project.Diagram.Tables);
                    var otherTableLabelColumnName = otherTable.Columns.First(c => c.TableColumnId == otherTable.LabelColumnTableId).Name;
                    var navPropertyName = NavProperty.GetName(otherTable.Name);

                    result.Append($"""
                        <dt class = "col-sm-2 scs-color">
                            {otherTableLabelColumnName}
                        </dt>
                        <dd class = "col-sm-10 scs-color">
                            @Html.DisplayFor(model => model.{navPropertyName}.{otherTableLabelColumnName})
                        </dd>
                        """);
                }
                else
                {
                    result.Append($"""
                        <dt class = "col-sm-2 scs-color">
                            @Html.DisplayNameFor(model => model.{column.Name})
                        </dt>
                        <dd class = "col-sm-10 scs-color">
                            @Html.DisplayFor(model => model.{column.Name})
                        </dd>
                        """);
                }
            }

            return result.ToString();
        }
    }
}
