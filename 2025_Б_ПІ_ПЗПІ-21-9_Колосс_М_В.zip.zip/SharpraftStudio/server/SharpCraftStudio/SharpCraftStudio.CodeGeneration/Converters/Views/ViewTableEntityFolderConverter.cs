﻿using SharpCraftStudio.CodeGeneration.Converters.Views.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Views
{
    internal class ViewTableEntityFolderConverter : IViewTableEntityFolderConverter
    {
        private readonly IEnumerable<ITableViewConverter> _indexTableViewConverters;

        public ViewTableEntityFolderConverter(IEnumerable<ITableViewConverter> indexTableViewConverters)
        {
            _indexTableViewConverters = indexTableViewConverters;
        }

        public ProjectFolderInfo GetFolder(ProjectConfigurationDto project, UMLTableDto table)
        {
            var folder = new ProjectFolderInfo(table.Name);


            foreach(var converter in _indexTableViewConverters)
            {
                var file = new ProjectFileInfo(converter.ViewName, FileExtension.CSHtml, converter.GetViewContent(project, table));
                folder.AddItem(file);
            }

            return folder;
        }
    }
}
