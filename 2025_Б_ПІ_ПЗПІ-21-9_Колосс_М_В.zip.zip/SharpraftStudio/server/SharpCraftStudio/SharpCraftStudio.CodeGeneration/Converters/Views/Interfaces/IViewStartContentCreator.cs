﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.Views.Interfaces
{
    internal interface IViewStartContentCreator
    {
        string GetViewContent();
    }
}
