﻿using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models;

namespace SharpCraftStudio.CodeGeneration.Converters.Views.Interfaces
{
    internal interface IViewFolderConverter
    {
        ProjectFolderInfo ConvertToFolder(ProjectConfigurationDto project);
    }
}
