﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall;
using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.ControllerMethods.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.ControllerMethods
{
    internal class MvcControllerPostDeleteMethodInfoConverter : IMvcControllerMethodInfoConverter
    {
        private readonly IDbContextRequestBuilderFactory _dbContextRequestBuilderFactory;

        public MvcControllerPostDeleteMethodInfoConverter(IDbContextRequestBuilderFactory dbContextRequestBuilderFactory)
        {
            _dbContextRequestBuilderFactory = dbContextRequestBuilderFactory;
        }

        public CodeMethodInfo Convert(ProjectConfigurationDto projectConfiguration, UMLTableDto table, string dbContextFieldName)
        {
            var builder = _dbContextRequestBuilderFactory.CreateBuilder(dbContextFieldName);
            var primaryKeyColumn = table.Columns.Single(c => c.IsPrimaryKey);

            var code = $$"""
                var item = await {{builder.ForDbSet(projectConfiguration, table).FirstOrDefaultAsync($"c => c.{primaryKeyColumn.Name} == id")}};
                {{builder.ForDbSet(projectConfiguration, table).Remove("item")}};
                await {{builder.SaveChangesAsync()}};
                return RedirectToAction(nameof(Index));
                """;

            var methodInfo = new CodeMethodInfo(
                "DeleteConfirmed",
                "Task<IActionResult>",
                AccessModifier.Public,
                ExecutionProcessModifier.Asynchronous,
                code
            );

            methodInfo.AddParameter(new(primaryKeyColumn.DataType.GetCSString(), "id"));
            methodInfo.AddAttribute(new("ActionName", "\"Delete\""));
            methodInfo.AddAttribute(new("HttpPost", string.Empty));

            return methodInfo;
        }
    }
}
