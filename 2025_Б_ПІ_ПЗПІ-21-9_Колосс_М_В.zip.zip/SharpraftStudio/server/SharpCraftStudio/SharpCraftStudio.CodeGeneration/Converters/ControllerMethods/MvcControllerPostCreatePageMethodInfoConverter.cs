﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.ControllerMethods.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;

namespace SharpCraftStudio.CodeGeneration.Converters.ControllerMethods
{
    internal class MvcControllerPostCreatePageMethodInfoConverter : IMvcControllerMethodInfoConverter
    {
        private readonly IDbContextRequestBuilderFactory _dbContextRequestBuilderFactory;
        private readonly IDropdownDataFillCodeGenerator _dropdownDataFiller;

        public MvcControllerPostCreatePageMethodInfoConverter(IDbContextRequestBuilderFactory dbContextRequestBuilderFactory, IDropdownDataFillCodeGenerator dropdownDataFiller)
        {
            _dbContextRequestBuilderFactory = dbContextRequestBuilderFactory;
            _dropdownDataFiller = dropdownDataFiller;
        }

        public CodeMethodInfo Convert(ProjectConfigurationDto projectConfiguration, UMLTableDto table, string dbContextFieldName)
        {
            var builder = _dbContextRequestBuilderFactory.CreateBuilder(dbContextFieldName);
            var primaryKeyColumn = table.Columns.Single(c => c.IsPrimaryKey);
            var relatedDataCode = _dropdownDataFiller.GenerateRelatedDataCode(projectConfiguration, table, dbContextFieldName);

            var code = $$"""
                if (ModelState.IsValid)
                {
                    {{builder.ForDbSet(projectConfiguration, table).Add("item")}};
                    await {{builder.SaveChangesAsync()}};
                    return RedirectToAction(nameof(Index));
                }
                {{relatedDataCode}}
                return View(item);
                """;

            var methodInfo = new CodeMethodInfo(
                "Create",
                "Task<IActionResult>",
                AccessModifier.Public,
                ExecutionProcessModifier.Asynchronous,
                code
            );

            methodInfo.AddParameter(new(table.Name, "item"));
            methodInfo.AddAttribute(new("HttpPost", string.Empty));

            return methodInfo;
        }
    }
}
