﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall;
using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.ControllerMethods.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpCraftStudio.CodeGeneration.Converters.ControllerMethods
{
    internal class MvcControllerGetEditPageMethodInfoConverter : IMvcControllerMethodInfoConverter
    {
        private readonly IDbContextRequestBuilderFactory _dbContextRequestBuilderFactory;
        private readonly IDropdownDataFillCodeGenerator _dropdownDataFiller;

        public MvcControllerGetEditPageMethodInfoConverter(IDbContextRequestBuilderFactory dbContextRequestBuilderFactory, IDropdownDataFillCodeGenerator dropdownDataFiller)
        {
            _dbContextRequestBuilderFactory = dbContextRequestBuilderFactory;
            _dropdownDataFiller = dropdownDataFiller;
        }

        public CodeMethodInfo Convert(ProjectConfigurationDto projectConfiguration, UMLTableDto table, string dbContextFieldName)
        {
            var code = GenerateMethodCode(projectConfiguration, table, dbContextFieldName);
            var methodInfo = new CodeMethodInfo("Edit", "Task<IActionResult>", AccessModifier.Public, ExecutionProcessModifier.Asynchronous, code);
            var primaryKeyColumn = table.Columns.Single(c => c.IsPrimaryKey);

            methodInfo.AddParameter(new(primaryKeyColumn.DataType.GetCSString(), "id"));

            return methodInfo;
        }

        private string GenerateMethodCode(ProjectConfigurationDto projectConfiguration, UMLTableDto table, string dbContextFieldName)
        {
            var builder = _dbContextRequestBuilderFactory.CreateBuilder(dbContextFieldName);
            var relatedDataCode = _dropdownDataFiller.GenerateRelatedDataCode(projectConfiguration, table, dbContextFieldName);
            var primaryKeyColumn = table.Columns.Single(c => c.IsPrimaryKey);

            return $$"""
                if (id == default)
                {
                    return NotFound();
                }
                
                var result = await {{builder.ForDbSet(projectConfiguration, table).IncludeAll().FirstOrDefaultAsync($"c => c.{primaryKeyColumn.Name} == id")}};
                if (result == null)
                {
                    return NotFound();
                }
                {{relatedDataCode}}
                return View(result);
                """;

        }
    }
}
