﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall;
using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.ControllerMethods.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.DataSelection.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.CodeGeneration.Models;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SharpCraftStudio.CodeGeneration.Models.MethodDataSelectionSortParameter;

namespace SharpCraftStudio.CodeGeneration.Converters.ControllerMethods
{
    internal class MvcControllerGetAllMethodInfoConverter : IMvcControllerMethodInfoConverter
    {
        private readonly IDbContextRequestBuilderFactory _dbContextRequestBuilderFactory;
        private readonly IDataSelectionParametersGenerator _dataSelectionParametersGenerator;

        public MvcControllerGetAllMethodInfoConverter(IDbContextRequestBuilderFactory dbContextRequestBuilderFactory, IDataSelectionParametersGenerator dataSelectionParametersGenerator)
        {
            _dbContextRequestBuilderFactory = dbContextRequestBuilderFactory;
            _dataSelectionParametersGenerator = dataSelectionParametersGenerator;
        }

        public CodeMethodInfo Convert(ProjectConfigurationDto projectConfiguration, UMLTableDto table, string dbContextFieldName)
        {
            var parameters = _dataSelectionParametersGenerator.GenerateForTable(projectConfiguration, table.TableId);
            var sortParameter = parameters.OfType<MethodDataSelectionSortParameter>().FirstOrDefault();

            var builder = _dbContextRequestBuilderFactory.CreateBuilder(dbContextFieldName);
            var code = $$"""
                {{SetDefaultParameters(parameters)}}
                var query = {{builder.ForDbSet(projectConfiguration, table).IncludeAll().ApplyDataSelection(parameters).SelectForViewConfig()}};
                {{AppplySortingParam(sortParameter, table)}}
                var result = await {{builder.ForQuery(projectConfiguration, table, "query").ToListAsync()}};
                {{AddParametersToViewData(parameters)}}
                return View(result);
                """;

            var methodInfo = new CodeMethodInfo("Index", "Task<IActionResult>", AccessModifier.Public, ExecutionProcessModifier.Asynchronous, code);

            
            foreach( var parameter in parameters )
            {
                methodInfo.AddParameter(new CodeParameterInfo(parameter.Type, parameter.Name, parameter.Type == "bool"));
            }

            return methodInfo;
        }

        private string AddParametersToViewData(IEnumerable<MethodDataSelectionParameterBase> parameters)
        {
            var builder = new StringBuilder();

            foreach( var parameter in parameters )
            {
                builder.AppendLine($"ViewData[\"{parameter.Name}\"] = {parameter.Name};");
            }

            return builder.ToString();
        }

        private string SetDefaultParameters(IEnumerable<MethodDataSelectionParameterBase> parameters)
        {
            var result = new StringBuilder();
            var searchParameter = parameters.OfType<MethodDataSelectionSearchParameter>().FirstOrDefault();

            if(searchParameter != null)
            {
                result.AppendLine($$"""
                    if ({{searchParameter.Name}} == null)
                    {
                        {{searchParameter.Name}} = string.Empty;
                    }
                    """);
            }

            return result.ToString();
        }

        private string AppplySortingParam(MethodDataSelectionSortParameter? sortParameter, UMLTableDto table)
        {
            if(sortParameter == null)
            {
                return string.Empty;
            }

            var cases = new List<string>();

            foreach (var enumValue in sortParameter.EnumValues)
            {
                var column = table.Columns.FirstOrDefault(c => c.TableColumnId == enumValue.ColumnApplyId);
                if(column == null)
                {
                    continue;
                }

                cases.Add($"""
                        {sortParameter.EnumName}.{enumValue.EnumValueName} => query.{GetOrderByMethodName(enumValue.IsDesc)}(c => c.{column.Name})
                    """);
            }

            return $$"""
                query = sortingParameter switch
                {
                    {{string.Join("," + CodePartSymbols.NEXT_LINE, cases)}}
                };
                """;
        }

        private string GetOrderByMethodName(bool isDesc)
        {
            return isDesc ? "OrderByDescending" : "OrderBy";
        }
    }
}
