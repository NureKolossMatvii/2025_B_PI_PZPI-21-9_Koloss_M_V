﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.ControllerMethods.Interfaces;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.ControllerMethods
{
    internal class DropdownDataFillCodeGenerator : IDropdownDataFillCodeGenerator
    {
        private readonly IDbContextRequestBuilderFactory _dbContextRequestBuilderFactory;

        public DropdownDataFillCodeGenerator(IDbContextRequestBuilderFactory dbContextRequestBuilderFactory)
        {
            _dbContextRequestBuilderFactory = dbContextRequestBuilderFactory;
        }

        public string GenerateRelatedDataCode(ProjectConfigurationDto projectConfiguration, UMLTableDto table, string dbContextFieldName)
        {
            var tableConnections = projectConfiguration.Diagram.Connections;
            var result = new StringBuilder();

            foreach (var foreignKey in table.Columns.Where(c => c.IsForeignKey))
            {
                var connection = tableConnections.FirstOrDefault(c => c.ForeignKeyColumnId == foreignKey.TableColumnId);
                if (connection == null) continue;

                var relatedTable = connection.GetAnotherTable(table, projectConfiguration.Diagram.Tables);
                var primaryKeyColumn = relatedTable.Columns.First(c => c.IsPrimaryKey);
                var displayColumn = relatedTable.Columns.First(c => c.TableColumnId == relatedTable.LabelColumnTableId);

                var elementsQuery = _dbContextRequestBuilderFactory
                    .CreateBuilder(dbContextFieldName)
                    .ForDbSet(projectConfiguration, relatedTable)
                    .ToListAsync();

                result.AppendLine($"ViewData[\"{foreignKey.Name}\"] = new SelectList(await {elementsQuery}, \"{primaryKeyColumn.Name}\", \"{displayColumn.Name}\");");
            }

            return result.ToString();
        }
    }
}
