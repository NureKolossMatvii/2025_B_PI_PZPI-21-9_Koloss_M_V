﻿using SharpCraftStudio.Project.Models.UML;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.ControllerMethods.Interfaces
{
    internal interface IDropdownDataFillCodeGenerator
    {
        string GenerateRelatedDataCode(ProjectConfigurationDto projectConfiguration, UMLTableDto table, string dbContextFieldName);
    }
}
