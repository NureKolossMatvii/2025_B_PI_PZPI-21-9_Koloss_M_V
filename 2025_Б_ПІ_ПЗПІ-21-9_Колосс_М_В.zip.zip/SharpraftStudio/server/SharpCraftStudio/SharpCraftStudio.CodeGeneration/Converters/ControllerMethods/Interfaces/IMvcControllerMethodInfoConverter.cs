﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.ControllerMethods.Interfaces
{
    internal interface IMvcControllerMethodInfoConverter
    {
        CodeMethodInfo Convert(ProjectConfigurationDto projectConfiguration, UMLTableDto table, string dbContextFieldName);
    }
}
