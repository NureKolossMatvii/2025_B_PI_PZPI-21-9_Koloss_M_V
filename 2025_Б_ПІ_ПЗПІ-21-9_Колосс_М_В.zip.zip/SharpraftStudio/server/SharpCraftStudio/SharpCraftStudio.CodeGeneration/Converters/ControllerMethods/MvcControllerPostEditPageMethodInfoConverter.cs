﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall;
using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.ControllerMethods.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.ControllerMethods
{
    internal class MvcControllerPostEditPageMethodInfoConverter : IMvcControllerMethodInfoConverter
    {
        private readonly IDropdownDataFillCodeGenerator _dropdownDataFiller;
        private readonly IDbContextRequestBuilderFactory _dbContextRequestBuilderFactory;

        public MvcControllerPostEditPageMethodInfoConverter(IDbContextRequestBuilderFactory dbContextRequestBuilderFactory, IDropdownDataFillCodeGenerator dropdownDataFiller)
        {
            _dbContextRequestBuilderFactory = dbContextRequestBuilderFactory;
            _dropdownDataFiller = dropdownDataFiller;
        }

        public CodeMethodInfo Convert(ProjectConfigurationDto projectConfiguration, UMLTableDto table, string dbContextFieldName)
        {
            var builder = _dbContextRequestBuilderFactory.CreateBuilder(dbContextFieldName);
            var primaryKeyColumn = table.Columns.Single(c => c.IsPrimaryKey);
            var relatedDataCode = _dropdownDataFiller.GenerateRelatedDataCode(projectConfiguration, table, dbContextFieldName);


            var code = $$"""
                if (id != item.{{primaryKeyColumn.Name}})
                {
                    return NotFound();
                }

                if (ModelState.IsValid)
                {
                    try
                    {
                        {{builder.ForDbSet(projectConfiguration, table).Update("item")}};
                        await {{builder.SaveChangesAsync()}};
                    }
                    catch (DbUpdateConcurrencyException)
                    {
                        return NotFound();
                    }
                    return RedirectToAction(nameof(Index));
                }

                {{relatedDataCode}}

                return View(item);
                """;

            var methodInfo = new CodeMethodInfo(
                "Edit",
                "Task<IActionResult>",
                AccessModifier.Public,
                ExecutionProcessModifier.Asynchronous,
                code
            );

            methodInfo.AddParameter(new(primaryKeyColumn.DataType.GetCSString(), "id"));
            methodInfo.AddParameter(new(table.Name, "item"));
            methodInfo.AddAttribute(new("HttpPost", string.Empty));

            return methodInfo;
        }
    }
}
