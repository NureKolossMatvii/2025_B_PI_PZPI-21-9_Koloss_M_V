﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall;
using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.ControllerMethods.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.ControllerMethods
{
    internal class MvcControllerGetDeleteMethodInfoConverter : IMvcControllerMethodInfoConverter
    {
        private readonly IDbContextRequestBuilderFactory _dbContextRequestBuilderFactory;

        public MvcControllerGetDeleteMethodInfoConverter(IDbContextRequestBuilderFactory dbContextRequestBuilderFactory)
        {
            _dbContextRequestBuilderFactory = dbContextRequestBuilderFactory;
        }

        public CodeMethodInfo Convert(ProjectConfigurationDto projectConfiguration, UMLTableDto table, string dbContextFieldName)
        {
            var builder = _dbContextRequestBuilderFactory.CreateBuilder(dbContextFieldName);
            var primaryKeyColumn = table.Columns.Single(c => c.IsPrimaryKey);

            var code = $$"""
                if (id == default)
                {
                    return NotFound();
                }

                var result = await {{builder.ForDbSet(projectConfiguration, table).IncludeAll().FirstOrDefaultAsync($"c => c.{primaryKeyColumn.Name} == id")}};
                if (result == null)
                {
                    return NotFound();
                }

                return View(result);
                """;

            var methodInfo = new CodeMethodInfo(
                "Delete",
                "Task<IActionResult>",
                AccessModifier.Public,
                ExecutionProcessModifier.Asynchronous,
                code
            );

            methodInfo.AddParameter(new(primaryKeyColumn.DataType.GetCSString(), "id"));

            return methodInfo;
        }
    }
}
