﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.ControllerMethods.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SharpCraftStudio.CodeGeneration.Converters.ControllerMethods
{
    internal class MvcControllerGetCreatePageMethodInfoConverter : IMvcControllerMethodInfoConverter
    {
        private readonly IDbContextRequestBuilderFactory _dbContextRequestBuilderFactory;
        private readonly IDropdownDataFillCodeGenerator _dropdownDataFiller;

        public MvcControllerGetCreatePageMethodInfoConverter(IDbContextRequestBuilderFactory dbContextRequestBuilderFactory, IDropdownDataFillCodeGenerator dropdownDataFiller)
        {
            _dbContextRequestBuilderFactory = dbContextRequestBuilderFactory;
            _dropdownDataFiller = dropdownDataFiller;
        }

        public CodeMethodInfo Convert(ProjectConfigurationDto projectConfiguration, UMLTableDto table, string dbContextFieldName)
        {
            var code = GenerateMethodCode(projectConfiguration, table, dbContextFieldName);
            return new CodeMethodInfo("Create", "Task<IActionResult>", AccessModifier.Public, ExecutionProcessModifier.Asynchronous, code);
        }

        private string GenerateMethodCode(ProjectConfigurationDto projectConfiguration, UMLTableDto table, string dbContextFieldName)
        {
            var relatedDataCode = _dropdownDataFiller.GenerateRelatedDataCode(projectConfiguration, table, dbContextFieldName);
            return $"{relatedDataCode}return View();";
        }
    }
}
