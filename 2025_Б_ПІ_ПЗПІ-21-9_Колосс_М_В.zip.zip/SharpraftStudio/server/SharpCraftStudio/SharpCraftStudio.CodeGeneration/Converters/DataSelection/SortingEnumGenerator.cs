﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.DataSelection.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.CodeGeneration.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.DataSelection
{
    internal class SortingEnumGenerator : ISortingEnumGenerator
    {
        private readonly IFileInfoConverter _fileInfoConverter;

        public SortingEnumGenerator(IFileInfoConverter fileInfoConverter)
        {
            _fileInfoConverter = fileInfoConverter;
        }

        public ProjectFileInfo Generate(MethodDataSelectionSortParameter sortParameter, string projectName)
        {
            var enumType = new CodeEnumInfo(sortParameter.EnumName, AccessModifier.Public);
            enumType.Items.AddRange(sortParameter.EnumValues.Select(c => c.EnumValueName));

            var namespaceInfo = new CodeNamespaceInfo(NamespaceNames.GetEFCoreModelsNamespace(projectName), enumType);
            var fileInfo = new CodeFileInfo(namespaceInfo, []);

            var fileContent = _fileInfoConverter.ConvertToString(fileInfo);

            return new ProjectFileInfo(sortParameter.EnumName, FileExtension.CS, fileContent);
        }
    }
}
