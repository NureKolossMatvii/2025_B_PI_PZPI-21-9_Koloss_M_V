﻿using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.CodeGeneration.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.DataSelection.Interfaces
{
    internal interface ISortingEnumGenerator
    {
        ProjectFileInfo Generate(MethodDataSelectionSortParameter sortParameter, string projectName);
    }
}
