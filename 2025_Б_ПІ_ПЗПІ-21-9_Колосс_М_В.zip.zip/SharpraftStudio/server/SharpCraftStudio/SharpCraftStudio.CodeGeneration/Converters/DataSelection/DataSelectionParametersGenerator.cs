﻿using SharpCraftStudio.CodeGeneration.Converters.DataSelection.Interfaces;
using SharpCraftStudio.CodeGeneration.Models;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.TableView;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SharpCraftStudio.CodeGeneration.Converters.DataSelection
{
    internal class DataSelectionParametersGenerator : IDataSelectionParametersGenerator
    {
        public List<MethodDataSelectionParameterBase> GenerateForTable(ProjectConfigurationDto projectConfiguration, Guid umlTableId)
        {
            var table = GetTable(projectConfiguration, umlTableId);
            var tableViewConfig = GetTableViewConfig(projectConfiguration, umlTableId);

            var result = new List<MethodDataSelectionParameterBase>();
            var columnsForSearch = new List<Guid>();
            var columnsForSorting = new List<UMLTableColumnDto>();

            foreach (var columnConfig in tableViewConfig.ColumnViewConfigs)
            {
                var column = TryGetColumn(table, columnConfig.UMLColumnId);

                if(column == null)
                {
                    continue;
                }

                AddSearchParameters(column, columnConfig, columnsForSearch);
                AddSortingParameters(column, columnConfig, columnsForSorting);
                AddFilteringParameters(result, column, columnConfig);
            }

            AddSearchStringParameter(result, columnsForSearch);
            AddSortingParameter(result, columnsForSorting, table);

            return result;
        }

        private UMLTableDto GetTable(ProjectConfigurationDto config, Guid tableId) =>
            config.Diagram.Tables.First(c => c.TableId == tableId);

        private TableViewConfigDto GetTableViewConfig(ProjectConfigurationDto config, Guid tableId) =>
            config.ViewConfig.TableViewConfigs.First(c => c.UMLTableId == tableId);

        private UMLTableColumnDto TryGetColumn(UMLTableDto table, Guid columnId) =>
            table.Columns.FirstOrDefault(c => c.TableColumnId == columnId);

        private void AddSearchParameters(UMLTableColumnDto column, ColumnViewConfigDto columnConfig, List<Guid> columnsForSearch)
        {
            if (columnConfig.DatasetSelectorRules.SearchingEnabled)
            {
                if (column.DataType != UMLColumnDataType.String)
                    throw new ArgumentException("Data type for searching should be string");

                columnsForSearch.Add(column.TableColumnId);
            }
        }

        private void AddSortingParameters(UMLTableColumnDto column, ColumnViewConfigDto columnConfig, List<UMLTableColumnDto> columnsForSorting)
        {
            if (columnConfig.DatasetSelectorRules.SortingEnabled)
                columnsForSorting.Add(column);
        }

        private void AddFilteringParameters(List<MethodDataSelectionParameterBase> result, UMLTableColumnDto column, ColumnViewConfigDto columnConfig)
        {
            if (columnConfig.DatasetSelectorRules.FilteringEnabled)
            {
                switch (column.DataType)
                {
                    case UMLColumnDataType.DateTime:
                    case UMLColumnDataType.Int:
                    case UMLColumnDataType.Double:
                        result.Add(CreateFilterParameter($"min{column.Name}FilterParam", column.DataType.GetCSString(), "Min " + columnConfig.Label, column.TableColumnId, MethodDataSelectionFilterParameter.ApplyType.MoreThen));
                        result.Add(CreateFilterParameter($"max{column.Name}FilterParam", column.DataType.GetCSString(), "Max " + columnConfig.Label, column.TableColumnId, MethodDataSelectionFilterParameter.ApplyType.LowerThen));
                        break;

                    case UMLColumnDataType.Boolean:
                        result.Add(CreateFilterParameter($"{column.Name}FilterParam", column.DataType.GetCSString(), columnConfig.Label, column.TableColumnId, MethodDataSelectionFilterParameter.ApplyType.EqualTo));
                        break;

                    default:
                        throw new ArgumentException("Data type for filtering should be date time, int, or double");
                }
            }
        }

        private MethodDataSelectionFilterParameter CreateFilterParameter(string name, string type, string label, Guid columnId, MethodDataSelectionFilterParameter.ApplyType applyType) =>
            new MethodDataSelectionFilterParameter(name, type, label, columnId, applyType);

        private void AddSearchStringParameter(List<MethodDataSelectionParameterBase> result, List<Guid> columnsForSearch)
        {
            if (columnsForSearch.Any())
                result.Add(new MethodDataSelectionSearchParameter("searchStringParameter", UMLColumnDataType.String.GetCSString(), "Search", columnsForSearch.ToArray()));
        }

        private void AddSortingParameter(List<MethodDataSelectionParameterBase> result, List<UMLTableColumnDto> columnsForSorting, UMLTableDto table)
        {
            if (columnsForSorting.Any())
            {
                var sortEnumValues = columnsForSorting.SelectMany(c => new[]
                {
                    new MethodDataSelectionSortParameter.EnumValue($"{c.Name}Asc", false, c.TableColumnId),
                    new MethodDataSelectionSortParameter.EnumValue($"{c.Name}Desc", true, c.TableColumnId)
                }).ToList();

                result.Add(new MethodDataSelectionSortParameter("sortingParameter", sortEnumValues, $"{table.Name}SortingEnum", "Order by"));
            }
        }
    }
}
