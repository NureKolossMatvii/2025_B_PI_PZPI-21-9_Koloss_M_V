﻿using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToStringConverters
{
    internal class EFCoreModelsFolderConverter : IEFCoreModelsFolderConverter
    {
        private readonly IEFCoreModelFileContentConverter _modelConverter;

        public EFCoreModelsFolderConverter(IEFCoreModelFileContentConverter modelConverter)
        {
            _modelConverter = modelConverter;
        }

        public ProjectFolderInfo ConvertToFolder(ProjectConfigurationDto project)
        {
            var result = new ProjectFolderInfo("Models");
            
            foreach(var table in project.Diagram.Tables)
            {
                var fileContent = _modelConverter.ConvertToString(project, table);
                var fileInfo = new ProjectFileInfo(table.Name, FileExtension.CS, fileContent);

                result.AddItem(fileInfo);
            }

            return result;
        }
    }
}
