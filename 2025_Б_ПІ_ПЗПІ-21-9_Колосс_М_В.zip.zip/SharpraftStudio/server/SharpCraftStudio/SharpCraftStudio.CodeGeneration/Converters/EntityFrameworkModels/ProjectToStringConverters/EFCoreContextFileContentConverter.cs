﻿using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToStringConverters
{
    internal class EFCoreContextFileContentConverter : IEFCoreContextFileContentConverter
    {
        private readonly IEFCoreContextFileInfoCreator _fileInfoCreator;
        private readonly IFileInfoConverter _toStringConverter;

        public EFCoreContextFileContentConverter(IEFCoreContextFileInfoCreator fileInfoCreator, IFileInfoConverter toStringConverter)
        {
            _fileInfoCreator = fileInfoCreator;
            _toStringConverter = toStringConverter;
        }

        public string ConvertToString(string projectName, UMLDiagramDto diagram)
        {
            var codeInfo = _fileInfoCreator.GetCodeClassInfo(projectName, diagram);
            var fileContent = _toStringConverter.ConvertToString(codeInfo);

            return fileContent;
        }
    }
}
