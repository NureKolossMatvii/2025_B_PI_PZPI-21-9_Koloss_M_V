﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToStringConverters
{
    internal class EFCoreModelFileContentConverter : IEFCoreModelFileContentConverter
    {
        private readonly IEFCoreModelCodeFileInfoCreator _fileInfoCreator;
        private readonly IFileInfoConverter _toStringConverter;

        public EFCoreModelFileContentConverter(IEFCoreModelCodeFileInfoCreator fileInfoCreator, IFileInfoConverter toStringConverter)
        {
            _fileInfoCreator = fileInfoCreator;
            _toStringConverter = toStringConverter;
        }

        public string ConvertToString(ProjectConfigurationDto project, UMLTableDto table)
        {
            var codeInfo = _fileInfoCreator.GetCodeFileInfo(project, table);
            var fileContent  = _toStringConverter.ConvertToString(codeInfo);

            return fileContent;
        }
    }
}
