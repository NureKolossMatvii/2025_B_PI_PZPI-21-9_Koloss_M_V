﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToCodePartConverters
{
    internal class EFCoreContextFileInfoCreator : IEFCoreContextFileInfoCreator
    {
        private readonly IEFCoreContextClassPartCreator _classCreator;

        public EFCoreContextFileInfoCreator(IEFCoreContextClassPartCreator classCreator)
        {
            _classCreator = classCreator;
        }

        public CodeFileInfo GetCodeClassInfo(string projectName, UMLDiagramDto diagram)
        {
            var classInfo = _classCreator.GetCodeClassInfo(diagram);

            var namespaceInfo = new CodeNamespaceInfo(NamespaceNames.GetEFCoreContextNamespace(projectName), classInfo);

            var usings = new CodeUsingInfo[]
            {
                new CodeUsingInfo(NamespaceNames.GetEFCoreModelsNamespace(projectName)),
                CodeUsingInfo.ENTITY_FRAMEWORK_CORE,
            };

            var fileInfo = new CodeFileInfo(namespaceInfo, usings);

            return fileInfo;

            throw new NotImplementedException();
        }
    }
}
