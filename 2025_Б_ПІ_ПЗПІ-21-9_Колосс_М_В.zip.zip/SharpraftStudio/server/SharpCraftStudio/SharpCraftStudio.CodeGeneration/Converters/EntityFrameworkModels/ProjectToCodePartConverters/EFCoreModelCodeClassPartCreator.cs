﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using SharpCraftStudio.CodeGeneration.Builders.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Data.Models.Project.Validation;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToCodePartConverters
{

    internal class EFCoreModelCodeClassPartCreator : IEFCoreModelCodeClassPartCreator
    {
        private readonly ICodeClassInfoBuilderFactory _classBuilderFactory;
        private const string TableAttributeName = "Table";
        private const string ColumnAttributeName = "Column";
        private const string KeyAttributeName = "Key";
        private const string ForeignKeyAttributeName = "ForeignKey";

        public EFCoreModelCodeClassPartCreator(ICodeClassInfoBuilderFactory classBuilderFactory)
        {
            _classBuilderFactory = classBuilderFactory;
        }

        public CodeClassInfo GetCodeClassInfo(ProjectConfigurationDto project, UMLTableDto table)
        {
            var classBuilder = _classBuilderFactory.GetCodeClassInfoBuilder(table.Name, AccessModifier.Public);

            AddTableAttribute(classBuilder, table);
            AddColumnsToClass(classBuilder, project, table);
            AddNavigationProperties(classBuilder, project.Diagram, table);

            return classBuilder.Build();
        }

        private void AddTableAttribute(ICodeClassInfoBuilder classBuilder, UMLTableDto table)
        {
            var classAttribute = new CodeAttribute(TableAttributeName, $"\"{table.Name}\"");
            classBuilder.AddAttribute(classAttribute);
        }

        private void AddColumnsToClass(ICodeClassInfoBuilder classBuilder, ProjectConfigurationDto project, UMLTableDto table)
        {
            var tableValidationConfig = project.ValidationConfig.TableValidationConfigs.First(c => c.UmlTableId == table.TableId);
            foreach (var column in table.Columns)
            {
                var validationInfo = tableValidationConfig.ColumnValidationConfigs.FirstOrDefault(c => c.UmlColumnId == column.TableColumnId);
                var info = CreatePropertyInfo(column, validationInfo);
                classBuilder.AddDataInfo(info);
            }
        }

        private void AddNavigationProperties(ICodeClassInfoBuilder classBuilder, UMLDiagramDto diagram, UMLTableDto table)
        {
            foreach (var connection in diagram.Connections)
            {
                if (connection.RightTableId == table.TableId || connection.LeftTableId == table.TableId)
                {
                    var currentTableId = connection.LeftTableId == table.TableId ? connection.LeftTableId : connection.RightTableId;
                    var otherTableId = connection.RightTableId == table.TableId ? connection.LeftTableId : connection.RightTableId;

                    var currentTable = diagram.Tables.First(c => c.TableId == currentTableId);
                    var otherTable = diagram.Tables.First(c => c.TableId == otherTableId);

                    var isCollection = connection.ConnectionType == UMLConnectionType.OneToMany && currentTableId == connection.LeftTableId
                        || connection.ConnectionType == UMLConnectionType.ManyToOne && currentTableId == connection.RightTableId;

                    var propertyType = isCollection ? $"List<{otherTable.Name}>" : otherTable.Name;

                    AddNavigationProperty(classBuilder, currentTable, otherTable, propertyType, connection, isCollection);
                }
            }
        }

        private void AddNavigationProperty(ICodeClassInfoBuilder classBuilder, UMLTableDto table, UMLTableDto otherTable, string propertyType, UMLTableConnectionDto connection, bool isCollection)
        {
            var foreignKeyTable = isCollection ? otherTable : table;

            var info = new CodeDataInfo(
                NavProperty.GetName(otherTable.Name),
                AccessModifier.Public,
                propertyType,
                DataInfoTypeModifier.Property,
                isCollection ? GetForeignKeyAttributes(foreignKeyTable.Columns.First(c => c.TableColumnId == connection.ForeignKeyColumnId).Name) : []
            );
            classBuilder.AddDataInfo(info);
        }

        private static CodeDataInfo CreatePropertyInfo(UMLTableColumnDto column, ColumnValidationConfig? columnValidationConfig)
        {
            return new CodeDataInfo(
                column.Name,
                AccessModifier.Public,
                column.DataType.GetCSString(),
                DataInfoTypeModifier.Property,
                GetColumnAttributes(column, columnValidationConfig)
            );
        }

        private static List<CodeAttribute> GetColumnAttributes(UMLTableColumnDto column, ColumnValidationConfig? columnValidationConfig)
        {
            var attributes = new List<CodeAttribute>
            {
                new CodeAttribute(ColumnAttributeName, $"\"{column.Name}\"")
            };

            if (column.IsPrimaryKey)
            {
                attributes.Add(new CodeAttribute(KeyAttributeName, string.Empty));
            }

            if(columnValidationConfig is null)
            {
                return attributes;
            }

            foreach(var valRule in columnValidationConfig.Validation)
            {
                switch(valRule.Type)
                {
                    case ValidationType.MinLength:
                        attributes.Add(new CodeAttribute("MinLength", $"{valRule.FirstParameter}, ErrorMessage=\"{valRule.Message}\""));
                        break;
                    case ValidationType.MaxLength:
                        attributes.Add(new CodeAttribute("MaxLength", $"{valRule.FirstParameter}, ErrorMessage=\"{valRule.Message}\""));
                        break;
                    case ValidationType.Email:
                        attributes.Add(new CodeAttribute("EmailAddress", $"ErrorMessage=\"{valRule.Message}\""));
                        break;
                    case ValidationType.PhoneNumber:
                        attributes.Add(new CodeAttribute("Phone", $"ErrorMessage=\"{valRule.Message}\""));
                        break;
                    case ValidationType.Required:
                        attributes.Add(new CodeAttribute("Required", $"ErrorMessage=\"{valRule.Message}\""));
                        break;
                    case ValidationType.Range:
                        attributes.Add(new CodeAttribute("Range", $"{valRule.FirstParameter}, {valRule.SecondParameter}, ErrorMessage=\"{valRule.Message}\""));
                        break;
                    default:
                        throw new NotImplementedException("Not implemented attribute converter for validation type");
                }
            }

            return attributes;
        }

        private static List<CodeAttribute> GetForeignKeyAttributes(string foreignKeyColumnName)
        {
            return new List<CodeAttribute>
            {
                new CodeAttribute(ForeignKeyAttributeName, $"\"{foreignKeyColumnName}\"")
            };
        }
    }

}
