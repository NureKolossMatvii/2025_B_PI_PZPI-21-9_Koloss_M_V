﻿using Microsoft.EntityFrameworkCore;
using SharpCraftStudio.CodeGeneration.Builders.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToCodePartConverters
{
    internal class EFCoreContextClassPartCreator : IEFCoreContextClassPartCreator
    {
        private readonly ICodeClassInfoBuilderFactory _classBuilderFactory;

        public EFCoreContextClassPartCreator(ICodeClassInfoBuilderFactory classBuilderFactory)
        {
            _classBuilderFactory = classBuilderFactory;
        }

        public CodeClassInfo GetCodeClassInfo(UMLDiagramDto diagram)
        {
            var classInfoBuilder = _classBuilderFactory.GetCodeClassInfoBuilder(GlobalClassNames.DBCONTEXT_CLASSNAME, AccessModifier.Public);

            classInfoBuilder.SetBaseClass("DbContext");
            classInfoBuilder.AddConstructor($$"""
                public {{GlobalClassNames.DBCONTEXT_CLASSNAME}}(DbContextOptions options) : base(options)
                {
                    // Database.EnsureDeleted();
                    Database.EnsureCreated();
                }
                """);

            foreach(var table in diagram.Tables)
            {
                var propertyInfo = new CodeDataInfo(
                    table.Name,
                    AccessModifier.Public,
                    $"DbSet<{table.Name}>",
                    DataInfoTypeModifier.Property,
                    new()
                );

                classInfoBuilder.AddDataInfo(propertyInfo);
            }

            return classInfoBuilder.Build();
        }
    }
}
