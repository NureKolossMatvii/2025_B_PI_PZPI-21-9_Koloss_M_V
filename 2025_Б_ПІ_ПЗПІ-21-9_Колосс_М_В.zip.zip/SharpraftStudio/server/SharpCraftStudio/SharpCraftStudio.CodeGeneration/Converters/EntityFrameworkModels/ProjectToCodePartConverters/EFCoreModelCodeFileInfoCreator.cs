﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToCodePartConverters
{
    internal class EFCoreModelCodeFileInfoCreator : IEFCoreModelCodeFileInfoCreator
    {
        private readonly IEFCoreModelCodeClassPartCreator _classCreator;

        public EFCoreModelCodeFileInfoCreator(IEFCoreModelCodeClassPartCreator classCreator)
        {
            _classCreator = classCreator;
        }

        public CodeFileInfo GetCodeFileInfo(ProjectConfigurationDto project, UMLTableDto table)
        {
            var classInfo = _classCreator.GetCodeClassInfo(project, table);

            var namespaceInfo = new CodeNamespaceInfo(NamespaceNames.GetEFCoreModelsNamespace(project.Name), classInfo);

            var usings = new CodeUsingInfo[]
            {
                CodeUsingInfo.SYSTEM,
                CodeUsingInfo.SYSTEM_COLLECTIONS_GENERIC,
                CodeUsingInfo.DATAANATATIONS,
                CodeUsingInfo.DATAANATATIONS_SCHEMA
            };

            var fileInfo = new CodeFileInfo(namespaceInfo, usings);

            return fileInfo;
        }
    }
}
