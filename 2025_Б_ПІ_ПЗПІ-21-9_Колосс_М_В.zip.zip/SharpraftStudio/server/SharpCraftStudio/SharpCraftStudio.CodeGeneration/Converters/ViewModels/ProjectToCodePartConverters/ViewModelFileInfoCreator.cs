﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.ViewModels.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.ViewModels.ProjectToCodePartConverters
{
    internal class ViewModelFileInfoCreator : IViewModelFileInfoCreator
    {
        private readonly IViewModelClassPartCreator _viewModelClassCreator;

        public ViewModelFileInfoCreator(IViewModelClassPartCreator viewModelClassCreator)
        {
            _viewModelClassCreator = viewModelClassCreator;
        }

        public CodeFileInfo GetCodeFileInfo(ProjectConfigurationDto projectConfiguration, Guid umlTableId)
        {
            var classInfo = _viewModelClassCreator.GetCodeClassInfo(projectConfiguration, umlTableId);

            var namespaceInfo = new CodeNamespaceInfo(NamespaceNames.GetViewModelsNamespace(projectConfiguration.Name), classInfo);

            var usings = new CodeUsingInfo[]
            {
                CodeUsingInfo.SYSTEM,
                CodeUsingInfo.SYSTEM_COLLECTIONS_GENERIC,
                CodeUsingInfo.DATAANATATIONS,
                CodeUsingInfo.DATAANATATIONS_SCHEMA,
            };

            var fileInfo = new CodeFileInfo(namespaceInfo, usings);

            return fileInfo;
        }
    }
}
