﻿using SharpCraftStudio.CodeGeneration.Builders.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.Converters.ViewModels.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.MemberModifiers;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.ViewModels.ProjectToCodePartConverters
{
    internal class ViewModelClassPartCreator : IViewModelClassPartCreator
    {
        private readonly ICodeClassInfoBuilderFactory _classBuilderFactory;

        public ViewModelClassPartCreator(ICodeClassInfoBuilderFactory classBuilderFactory)
        {
            _classBuilderFactory = classBuilderFactory;
        }

        public CodeClassInfo GetCodeClassInfo(ProjectConfigurationDto projectConfiguration, Guid umlTableId)
        {
            var umlTable = projectConfiguration.Diagram.Tables
                .First(c => c.TableId == umlTableId);
            var tableViewConfig = projectConfiguration.ViewConfig.TableViewConfigs
                .First(c => c.UMLTableId == umlTableId);

            var classInfo = _classBuilderFactory.GetCodeClassInfoBuilder(tableViewConfig.GetTypeName(), AccessModifier.Public);
            var columns = projectConfiguration.Diagram.Tables.SelectMany(c => c.Columns);

            foreach(var columnViewConfig in tableViewConfig.ColumnViewConfigs)
            {
                var column = columns.First(c => c.TableColumnId == columnViewConfig.UMLColumnId);

                classInfo.AddDataInfo(new CodeDataInfo(
                    columnViewConfig.GetViewModelPropertyName(),
                    AccessModifier.Public,
                    column.DataType.GetCSString(),
                    DataInfoTypeModifier.Property,
                    []
                ));
            }

            return classInfo.Build();
        }
    }
}
