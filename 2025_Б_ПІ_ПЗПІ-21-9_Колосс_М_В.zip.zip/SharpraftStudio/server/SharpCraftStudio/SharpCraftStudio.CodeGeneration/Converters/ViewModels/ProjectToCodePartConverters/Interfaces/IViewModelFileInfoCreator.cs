﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.ViewModels.ProjectToCodePartConverters.Interfaces
{
    internal interface IViewModelFileInfoCreator
    {
        CodeFileInfo GetCodeFileInfo(ProjectConfigurationDto projectConfiguration, Guid umlTableId);
    }
}
