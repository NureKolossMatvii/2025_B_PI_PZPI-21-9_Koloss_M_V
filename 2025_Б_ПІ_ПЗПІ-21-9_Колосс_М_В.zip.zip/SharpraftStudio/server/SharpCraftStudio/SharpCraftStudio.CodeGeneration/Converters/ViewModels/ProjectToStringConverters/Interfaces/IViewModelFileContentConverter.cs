﻿using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.ViewModels.ProjectToStringConverters.Interfaces
{
    internal interface IViewModelFileContentConverter
    {
        string ConvertToString(ProjectConfigurationDto projectConfiguration, Guid umlTableId);
    }
}
