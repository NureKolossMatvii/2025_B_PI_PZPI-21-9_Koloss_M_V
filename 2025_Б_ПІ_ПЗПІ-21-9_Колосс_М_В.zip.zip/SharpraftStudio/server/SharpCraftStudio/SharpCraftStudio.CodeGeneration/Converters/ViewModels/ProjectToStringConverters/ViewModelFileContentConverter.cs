﻿using SharpCraftStudio.CodeGeneration.Converters.CodePartToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.ViewModels.ProjectToCodePartConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.ViewModels.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.ViewModels.ProjectToStringConverters
{
    internal class ViewModelFileContentConverter : IViewModelFileContentConverter
    {
        private readonly IViewModelFileInfoCreator _fileInfoCreator;
        private readonly IFileInfoConverter _toStringConverter;

        public ViewModelFileContentConverter(IViewModelFileInfoCreator fileInfoCreator, IFileInfoConverter toStringConverter)
        {
            _fileInfoCreator = fileInfoCreator;
            _toStringConverter = toStringConverter;
        }

        public string ConvertToString(ProjectConfigurationDto projectConfiguration, Guid umlTableId)
        {
            var codeInfo = _fileInfoCreator.GetCodeFileInfo(projectConfiguration, umlTableId);
            var fileContent = _toStringConverter.ConvertToString(codeInfo);

            return fileContent;
        }
    }
}
