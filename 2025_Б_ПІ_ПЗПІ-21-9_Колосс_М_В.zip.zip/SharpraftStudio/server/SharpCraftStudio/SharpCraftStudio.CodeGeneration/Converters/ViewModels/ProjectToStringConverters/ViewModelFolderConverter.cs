﻿using SharpCraftStudio.CodeGeneration.Converters.ViewModels.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Converters.ViewModels.ProjectToStringConverters
{
    internal class ViewModelFolderConverter : IViewModelFolderConverter
    {
        private readonly IViewModelFileContentConverter _modelConverter;

        public ViewModelFolderConverter(IViewModelFileContentConverter modelConverter)
        {
            _modelConverter = modelConverter;
        }

        public ProjectFolderInfo ConvertToFolder(ProjectConfigurationDto projectConfiguration)
        {
            var result = new ProjectFolderInfo("ViewModels");
            var tables = projectConfiguration.Diagram.Tables;

            foreach (var tableViewConfig in projectConfiguration.ViewConfig.TableViewConfigs)
            {
                var fileContent = _modelConverter.ConvertToString(projectConfiguration, tableViewConfig.UMLTableId);
                var table = tables.First(c => c.TableId == tableViewConfig.UMLTableId);
                var fileInfo = new ProjectFileInfo(tableViewConfig.GetTypeName(), FileExtension.CS, fileContent);

                result.AddItem(fileInfo);
            }

            return result;
        }
    }
}
