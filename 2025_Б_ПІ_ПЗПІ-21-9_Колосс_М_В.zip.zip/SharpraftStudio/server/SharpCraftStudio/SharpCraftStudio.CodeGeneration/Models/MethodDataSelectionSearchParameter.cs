﻿namespace SharpCraftStudio.CodeGeneration.Models
{
    internal class MethodDataSelectionSearchParameter : MethodDataSelectionParameterBase
    {
        public Guid[] ApplyToUmlColumnIdes { get; set; }

        public MethodDataSelectionSearchParameter(string name, string type, string label, Guid[] applyToUmlColumnIdes) : base(name, type, label)
        {
            ApplyToUmlColumnIdes = applyToUmlColumnIdes;
        }
    }
}
