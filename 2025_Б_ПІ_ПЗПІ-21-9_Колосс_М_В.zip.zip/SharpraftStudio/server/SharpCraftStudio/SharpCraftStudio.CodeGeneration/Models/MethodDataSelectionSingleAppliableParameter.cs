﻿namespace SharpCraftStudio.CodeGeneration.Models
{
    internal abstract class MethodDataSelectionSingleAppliableParameter : MethodDataSelectionParameterBase
    {
        protected MethodDataSelectionSingleAppliableParameter(string name, string type, string label) : base(name, type, label)
        {
        }
    }
}
