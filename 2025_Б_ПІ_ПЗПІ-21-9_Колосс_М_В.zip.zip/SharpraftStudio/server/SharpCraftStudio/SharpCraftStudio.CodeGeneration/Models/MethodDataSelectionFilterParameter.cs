﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.Project.Models.TableView;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Models
{
    internal class MethodDataSelectionFilterParameter : MethodDataSelectionSingleAppliableParameter
    {
        public MethodDataSelectionFilterParameter(string name, string type, string label, Guid applyToUmlColumnId, ApplyType applyType) : base(name, type, label)
        {
            ApplyToUmlColumnId = applyToUmlColumnId;
            ParameterApplyType = applyType;
        }

        public Guid ApplyToUmlColumnId { get; set; }
        public ApplyType ParameterApplyType { get; set; }

        public enum ApplyType
        {
            MoreThen,
            LowerThen,
            EqualTo
        }
    }
}
