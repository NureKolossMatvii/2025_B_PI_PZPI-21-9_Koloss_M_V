﻿using SharpCraftStudio.CodeGeneration.Builders.DbContextCall.Interfaces;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.Models
{
    internal class MethodDataSelectionSortParameter : MethodDataSelectionSingleAppliableParameter
    {
        public MethodDataSelectionSortParameter(string name, List<EnumValue> enumValues, string enumName, string label) : base(name, enumName, label)
        {
            EnumValues = enumValues;
            EnumName = enumName;
        }

        public List<EnumValue> EnumValues { get; set; }
        public string EnumName { get; set; }

        public class EnumValue
        {
            public EnumValue(string enumValueName, bool isDesc, Guid columnApplyId)
            {
                EnumValueName = enumValueName;
                IsDesc = isDesc;
                ColumnApplyId = columnApplyId;
            }

            public string EnumValueName { get; set; }

            public bool IsDesc { get; set; }

            public Guid ColumnApplyId { get; set; }
        }
    }
}
