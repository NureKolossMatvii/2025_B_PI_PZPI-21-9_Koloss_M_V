﻿namespace SharpCraftStudio.CodeGeneration.Models
{
    internal abstract class MethodDataSelectionParameterBase
    {
        public MethodDataSelectionParameterBase(string name, string type, string label)
        {
            Name = name;
            Type = type;
            Label = label;
        }

        public string Name { get; set; }
        public string Type { get; set; }
        public string Label { get; set; }
    }
}
