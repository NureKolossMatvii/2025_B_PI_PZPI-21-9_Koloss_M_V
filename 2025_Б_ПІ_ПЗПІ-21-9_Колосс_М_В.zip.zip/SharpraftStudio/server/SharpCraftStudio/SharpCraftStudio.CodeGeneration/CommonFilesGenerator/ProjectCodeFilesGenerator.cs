﻿using SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.Controllers.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.ViewModels.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.Views.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator
{
    internal class ProjectCodeFilesGenerator : IProjectCodeFilesGenerator
    {
        private readonly IViewModelFolderConverter _viewModelFolderConverter;
        private readonly IProgramCsFileGenerator _programCsFileGenerator;
        private readonly IMvcControllersFolderConverter _mvcControllersFolderConverter;
        private readonly IAppSettingsFileGenerator _appSettingsFileGenerator;
        private readonly IViewFolderConverter _viewFolderConverter;
        private readonly IDatabaseFolderGenerator _databaseFolderConverter;
        private readonly IWwwRootFolderGenerator _wwwRootFolderGenerator;

        public ProjectCodeFilesGenerator(IEFCoreModelsFolderConverter contentConverter, IProgramCsFileGenerator programCsFileGenerator, IDbContextFileGenerator dbContextFileGenerator, IMvcControllersFolderConverter mvcControllersFolderConverter, IAppSettingsFileGenerator appSettingsFileGenerator, IViewFolderConverter viewFolderConverter, IViewModelFolderConverter viewModelFolderConverter, IDatabaseFolderGenerator databaseFolderGenerator, IWwwRootFolderGenerator wwwRootFolderGenerator)
        {
            _programCsFileGenerator = programCsFileGenerator;
            _mvcControllersFolderConverter = mvcControllersFolderConverter;
            _appSettingsFileGenerator = appSettingsFileGenerator;
            _viewFolderConverter = viewFolderConverter;
            _viewModelFolderConverter = viewModelFolderConverter;
            _databaseFolderConverter = databaseFolderGenerator;
            _wwwRootFolderGenerator = wwwRootFolderGenerator;
        }

        public IEnumerable<IFolderItem> Generate(ProjectConfigurationDto projectConfiguration)
        {
            return new List<IFolderItem>()
            {
                _databaseFolderConverter.ConvertToFolder(projectConfiguration),
                _viewModelFolderConverter.ConvertToFolder(projectConfiguration),
                _programCsFileGenerator.Generate(projectConfiguration.Name),
                _mvcControllersFolderConverter.ConvertToFolder(projectConfiguration),
                _viewFolderConverter.ConvertToFolder(projectConfiguration),
                _appSettingsFileGenerator.Generate(projectConfiguration),
                _wwwRootFolderGenerator.ConvertToFolder(projectConfiguration),
            };
        }
    }
}
