﻿using SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator
{
    internal class DbContextFileGenerator : IDbContextFileGenerator
    {
        private readonly IEFCoreContextFileContentConverter _fileInfoCreator;

        public DbContextFileGenerator(IEFCoreContextFileContentConverter fileInfoCreator)
        {
            _fileInfoCreator = fileInfoCreator;
        }

        public ProjectFileInfo Generate(string projectName, UMLDiagramDto umlDiagram)
        {
            var content = _fileInfoCreator.ConvertToString(projectName, umlDiagram);
            var info = new ProjectFileInfo(GlobalClassNames.DBCONTEXT_CLASSNAME, FileExtension.CS, content);
            return info;
        }
    }
}
