﻿using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces
{
    public interface IResultGenerator
    {
        ProjectFolderInfo Generate(ProjectConfigurationDto projectConfiguration);
    }
}
