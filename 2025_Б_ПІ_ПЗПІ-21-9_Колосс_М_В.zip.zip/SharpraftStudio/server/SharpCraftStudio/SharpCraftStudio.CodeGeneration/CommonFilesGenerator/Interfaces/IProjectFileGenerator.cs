﻿using SharpCraftStudio.CodeGeneration.FileSystemModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces
{
    internal interface IProjectFileGenerator
    {
        ProjectFileInfo Generate(string projectName);
    }
}
