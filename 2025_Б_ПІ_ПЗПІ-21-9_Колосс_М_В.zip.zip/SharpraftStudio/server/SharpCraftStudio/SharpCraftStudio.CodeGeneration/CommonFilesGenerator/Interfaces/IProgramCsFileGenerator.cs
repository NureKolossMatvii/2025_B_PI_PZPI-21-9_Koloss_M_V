﻿using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces
{
    internal interface IProgramCsFileGenerator
    {
        ProjectFileInfo Generate(string projectName);
    }
}
