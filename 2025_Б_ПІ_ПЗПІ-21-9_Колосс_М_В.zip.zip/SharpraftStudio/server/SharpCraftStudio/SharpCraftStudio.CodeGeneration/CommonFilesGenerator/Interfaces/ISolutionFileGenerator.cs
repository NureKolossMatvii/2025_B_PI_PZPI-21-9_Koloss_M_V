﻿using SharpCraftStudio.CodeGeneration.FileSystemModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SharpCraftStudio.CodeGeneration.CommonFilesGenerator.SolutionFileGenerator;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces
{
    internal interface ISolutionFileGenerator
    {
        ProjectFileInfo Generate(List<ProjectInfo> projects, string solutionName);
    }
}
