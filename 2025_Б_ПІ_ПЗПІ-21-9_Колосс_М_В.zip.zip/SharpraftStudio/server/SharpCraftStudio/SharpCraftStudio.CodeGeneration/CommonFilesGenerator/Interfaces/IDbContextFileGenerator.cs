﻿using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces
{
    internal interface IDbContextFileGenerator
    {
        ProjectFileInfo Generate(string projectName, UMLDiagramDto umlDiagram);
    }
}
