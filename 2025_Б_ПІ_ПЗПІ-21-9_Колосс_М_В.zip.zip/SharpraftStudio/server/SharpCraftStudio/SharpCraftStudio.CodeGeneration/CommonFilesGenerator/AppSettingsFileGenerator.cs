﻿using SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator
{
    internal class AppSettingsFileGenerator : IAppSettingsFileGenerator
    {
        public ProjectFileInfo Generate(ProjectConfigurationDto projectConfiguration)
        {
            var content = $$"""
                {
                  "Logging": {
                    "LogLevel": {
                      "Default": "Information",
                      "Microsoft.AspNetCore": "Warning"
                    }
                  },
                  "AllowedHosts": "*",
                  "ConnectionStrings": {
                    "Default": "Data Source=.;Initial Catalog=database_{{projectConfiguration.Name}};Integrated Security=True;Trust Server Certificate=True"
                  }
                }
                """;

            var info = new ProjectFileInfo("appsettings", FileExtension.Json, content);
            return info;
        }
    }
}
