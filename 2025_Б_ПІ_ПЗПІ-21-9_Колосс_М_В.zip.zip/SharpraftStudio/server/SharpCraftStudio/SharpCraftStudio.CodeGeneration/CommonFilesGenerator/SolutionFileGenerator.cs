﻿using SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator
{
    internal class SolutionFileGenerator : ISolutionFileGenerator
    {
        private const string SolutionFileHeader =
            "Microsoft Visual Studio Solution File, Format Version 12.00\n" +
            "# Visual Studio Version 16\n" +
            "VisualStudioVersion = 16.0.33027.164\n" +
            "MinimumVisualStudioVersion = 10.0.40219.1";

        public ProjectFileInfo Generate(List<ProjectInfo> projects, string solutionName)
        {
            string solutionGuid = Guid.NewGuid().ToString().ToUpper();
            var sb = new StringBuilder();

            sb.AppendLine(SolutionFileHeader);

            foreach (var project in projects)
            {
                sb.AppendLine(
                    $"Project(\"{{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}}\") = \"{project.Name}\", \"{solutionName + "\\" + project.Name + ".csproj"}\", \"{{{project.Guid.ToString().ToUpper()}}}\"");
                sb.AppendLine("EndProject");
            }

            sb.AppendLine("Global");
            sb.AppendLine("\tGlobalSection(SolutionConfigurationPlatforms) = preSolution");
            sb.AppendLine("\t\tDebug|Any CPU = Debug|Any CPU");
            sb.AppendLine("\t\tRelease|Any CPU = Release|Any CPU");
            sb.AppendLine("\tEndGlobalSection");

            sb.AppendLine("\tGlobalSection(ProjectConfigurationPlatforms) = postSolution");
            foreach (var project in projects)
            {
                var projectGuid = project.Guid.ToString().ToUpper();
                sb.AppendLine($"\t\t{{{projectGuid}}}.Debug|Any CPU.ActiveCfg = Debug|Any CPU");
                sb.AppendLine($"\t\t{{{projectGuid}}}.Debug|Any CPU.Build.0 = Debug|Any CPU");
                sb.AppendLine($"\t\t{{{projectGuid}}}.Release|Any CPU.ActiveCfg = Release|Any CPU");
                sb.AppendLine($"\t\t{{{projectGuid}}}.Release|Any CPU.Build.0 = Release|Any CPU");
            }
            sb.AppendLine("\tEndGlobalSection");

            sb.AppendLine("\tGlobalSection(SolutionProperties) = preSolution");
            sb.AppendLine("\t\tHideSolutionNode = FALSE");
            sb.AppendLine("\tEndGlobalSection");

            sb.AppendLine("\tGlobalSection(ExtensibilityGlobals) = postSolution");
            sb.AppendLine($"\t\tSolutionGuid = {{{solutionGuid}}}");
            sb.AppendLine("\tEndGlobalSection");

            sb.AppendLine("EndGlobal");

            var content = sb.ToString();

            return new ProjectFileInfo(solutionName, FileExtension.Sln, content);
        }

        public class ProjectInfo
        {
            public string Name { get; }
            public Guid Guid { get; }

            public ProjectInfo(string name, Guid guid)
            {
                Name = name;
                Guid = guid;
            }
        }
    }
}
