﻿using SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator
{
    internal class WwwRootFolderGenerator : IWwwRootFolderGenerator
    {
        private readonly IColorTemplatesService _colorTemplatesService;

        public WwwRootFolderGenerator(IColorTemplatesService colorTemplatesService)
        {
            _colorTemplatesService = colorTemplatesService;
        }

        public ProjectFolderInfo ConvertToFolder(ProjectConfigurationDto projectConfiguration)
        {
            if (!projectConfiguration.ColorTemplateId.HasValue)
            {
                return new ProjectFolderInfo("wwwroot");
            }
            var colorTemplate = _colorTemplatesService.GetAsync(projectConfiguration.ColorTemplateId.Value).Result;
            var folder = new ProjectFolderInfo("wwwroot");
            var csscontent = $$"""
                .scs-background-color {
                  background-color: {{colorTemplate.Colors.BackgroundColor}};
                }

                .scs-color {
                  color: {{colorTemplate.Colors.Color}};
                }

                .scs-border-bottom-color {
                  border-bottom: 1px solid {{colorTemplate.Colors.BorderColor}};
                }

                .scs-border-top-color {
                  border-top: 1px solid {{colorTemplate.Colors.BorderColor}};
                }

                .scs-border-right-color {
                  border-right: 1px solid {{colorTemplate.Colors.BorderColor}};
                }

                .scs-border-left-color {
                  border-left: 1px solid {{colorTemplate.Colors.BorderColor}};
                }

                .scs-border-color {
                  border: 1px solid {{colorTemplate.Colors.BorderColor}};
                }

                .scs-default-button-background-color {
                  background-color: {{colorTemplate.Colors.DefaultButtonColor.Background}};
                  border-color: {{colorTemplate.Colors.DefaultButtonColor.Background}};
                }

                .scs-default-button-text-color {
                  color: {{colorTemplate.Colors.DefaultButtonColor.Color}};
                }

                .scs-delete-button-background-color {
                  background-color: {{colorTemplate.Colors.DeleteButtonColor.Background}};
                }

                .scs-delete-button-text-color {
                  color: {{colorTemplate.Colors.DeleteButtonColor.Color}};
                }

                .scs-edit-button-background-color {
                  background-color: {{colorTemplate.Colors.EditButtonColor.Background}};
                }

                .scs-cancel-button-text-color {
                  color: {{colorTemplate.Colors.EditButtonColor.Color}};
                }

                .scs-cancel-button-background-color {
                  background-color: {{colorTemplate.Colors.CancelButtonColor.Background}};
                }

                .scs-edit-button-text-color {
                  color: {{colorTemplate.Colors.EditButtonColor.Color}};
                }

                .scs-table-border-color {
                  border: 1px solid {{colorTemplate.Colors.TableColor.BorderColor}};
                }

                .scs-table-border-bottom-color {
                  border-bottom: 1px solid {{colorTemplate.Colors.TableColor.BorderColor}};
                }

                .scs-table-border-top-color {
                  border-top: 1px solid {{colorTemplate.Colors.TableColor.BorderColor}};
                }

                .scs-table-border-right-color {
                  border-right: 1px solid {{colorTemplate.Colors.TableColor.BorderColor}};
                }

                .scs-table-border-left-color {
                  border-left: 1px solid {{colorTemplate.Colors.TableColor.BorderColor}};
                }
                                
                .scs-input:focus{
                    background-color: {{colorTemplate.Colors.BackgroundColor}};
                    border-color: {{colorTemplate.Colors.BorderColor}};
                    color: {{colorTemplate.Colors.Color}};
                    box-shadow: none;
                }

                .customTable {
                  width: 100%;
                  margin-bottom: 1rem;
                  vertical-align: top;
                }

                .customTable > tbody {
                  vertical-align: inherit;
                }
                .customTable > thead {
                  vertical-align: bottom;
                }

                thead,
                tbody,
                tfoot,
                tr,
                td,
                th {
                  border-color: inherit;
                  border-style: solid;
                  border-width: 0;
                }

                th {
                  text-align: inherit;
                  text-align: -webkit-match-parent;
                  padding: 10px 0;
                }

                td {
                  padding: 10px 0;
                }

                .table__search__item {
                  display: flex;
                  gap: 5px;
                }

                .table__search__block {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 10px;
                    margin: 10px 0;
                }

                .searchSubmit {
                    width: 100%;
                    display: flex;
                    justify-content: flex-end;
                }

                .scs-checkbox-container {
                    display: block;
                    position: relative;
                    margin-bottom: 12px;
                    cursor: pointer;
                    -webkit-user-select: none;
                    -moz-user-select: none;
                    -ms-user-select: none;
                    user-select: none;
                }

                    .scs-checkbox-container > input {
                        position: absolute;
                        opacity: 0;
                        cursor: pointer;
                        height: 0;
                        width: 0;
                    }

                .scs-checkbox-label {
                    height: 100%;
                    display: flex;
                    align-items: center;
                    height: 20px;
                    padding-left: 30px;
                    color: {{colorTemplate.Colors.Color}};
                }

                .scs-checkmark {
                    position: absolute;
                    top: 0;
                    left: 0;
                    background-color: {{colorTemplate.Colors.BackgroundColor}};
                    border: 1px solid {{colorTemplate.Colors.Color}};
                    height: 20px;
                    width: 20px;
                }

                .scs-checkbox-container:hover input ~ .scs-checkmark {
                    opacity: .8;
                }

                .scs-checkbox-container input:checked ~ .scs-checkmark {
                    background-color: {{colorTemplate.Colors.BackgroundColor}};
                }

                .scs-checkmark:after {
                    content: "";
                    position: absolute;
                    display: none;
                }

                .scs-checkbox-container > input:checked ~ .scs-checkmark:after {
                    display: block;
                }

                .scs-checkbox-container .scs-checkmark:after {
                    left: 50%;
                    top: 50%;
                    width: 25%;
                    height: 70%;
                    border: solid {{colorTemplate.Colors.Color}};
                    border-width: 0 .1rem .1rem 0;
                    -webkit-transform: translate(-50%, -50%) rotate(45deg);
                    -ms-transform: translate(-50%, -50%) rotate(45deg);
                    transform: translate(-50%, -50%) rotate(45deg);
                }
                """;
            var fileInfo = new ProjectFileInfo("main", FileExtension.Css, csscontent);

            folder.AddItem(fileInfo);

            return folder;
        }
    }
}
