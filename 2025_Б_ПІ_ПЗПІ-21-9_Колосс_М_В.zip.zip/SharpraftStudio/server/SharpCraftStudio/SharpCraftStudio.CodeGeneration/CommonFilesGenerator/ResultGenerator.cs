﻿using SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator
{
    internal class ResultGenerator : IResultGenerator
    {
        private readonly ISolutionFileGenerator _solutionFileGenerator;
        private readonly IProjectFileGenerator _projectFileGenerator;
        private readonly IProjectCodeFilesGenerator _projectFilesGenerator;

        public ResultGenerator(ISolutionFileGenerator solutionFileGenerator, IProjectFileGenerator projectFileGenerator, IProjectCodeFilesGenerator projectFilesGenerator)
        {
            _solutionFileGenerator = solutionFileGenerator;
            _projectFileGenerator = projectFileGenerator;
            _projectFilesGenerator = projectFilesGenerator;
        }

        public ProjectFolderInfo Generate(ProjectConfigurationDto projectConfiguration)
        {
            var resultFolder = new ProjectFolderInfo("result");

            resultFolder.AddItem(_solutionFileGenerator.Generate(new()
            {
                new (projectConfiguration.Name,Guid.NewGuid())
            }, projectConfiguration.Name));

            var projectFolder = new ProjectFolderInfo(projectConfiguration.Name);
            projectFolder.AddItem(_projectFileGenerator.Generate(projectConfiguration.Name));

            var projectFiles = _projectFilesGenerator.Generate(projectConfiguration);

            foreach (var file in projectFiles)
            {
                projectFolder.AddItem(file);
            }

            resultFolder.AddItem(projectFolder);


            return resultFolder;
        }
    }
}
