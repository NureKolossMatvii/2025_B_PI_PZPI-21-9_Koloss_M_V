﻿using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator
{
    internal class ProgramCsFileGenerator : IProgramCsFileGenerator
    {
        public ProjectFileInfo Generate(string projectName)
        {
            var content = $$"""
                using Microsoft.AspNetCore.Builder;
                using Microsoft.EntityFrameworkCore;
                using Microsoft.Extensions.Configuration;
                using Microsoft.Extensions.DependencyInjection;
                using Microsoft.Extensions.Hosting;
                using {{NamespaceNames.GetEFCoreContextNamespace(projectName)}};

                var builder = WebApplication.CreateBuilder(args);

                builder.Services
                    .AddDbContext<{{GlobalClassNames.DBCONTEXT_CLASSNAME}}>(options =>
                    {
                        var connectionString = builder.Configuration.GetConnectionString("Default");
                        options.UseSqlServer(connectionString);
                    });

                builder.Services.AddControllersWithViews();

                var app = builder.Build();

                // Configure the HTTP request pipeline.
                if (app.Environment.IsDevelopment())
                {
                    app.UseDeveloperExceptionPage();
                }
                else
                {
                    app.UseExceptionHandler("/Home/Error");
                    app.UseHsts();
                }

                app.UseHttpsRedirection();
                app.UseStaticFiles();

                app.UseRouting();

                app.UseAuthentication();
                app.UseAuthorization();

                app.MapControllerRoute(
                    name: "default",
                    pattern: "{controller=Home}/{action=Index}/{id?}");

                app.Run();
                """;

            var info = new ProjectFileInfo("Program", FileExtension.CS, content);
            return info;
        }
    }
}
