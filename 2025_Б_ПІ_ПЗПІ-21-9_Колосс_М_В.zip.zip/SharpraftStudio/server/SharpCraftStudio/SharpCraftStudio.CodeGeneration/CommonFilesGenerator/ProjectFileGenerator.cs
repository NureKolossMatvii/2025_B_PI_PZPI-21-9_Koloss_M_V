﻿using SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator
{
    internal class ProjectFileGenerator : IProjectFileGenerator
    {
        public ProjectFileInfo Generate(string projectName)
        {
            return new ProjectFileInfo(projectName, FileExtension.CSProj, """
                <Project Sdk="Microsoft.NET.Sdk.Web">

                  <PropertyGroup>
                    <TargetFramework>net8.0</TargetFramework>
                  </PropertyGroup>

                  <ItemGroup>
                    <PackageReference Include="Microsoft.AspNetCore.Identity.EntityFrameworkCore" Version="8.0.8" />
                    <PackageReference Include="Microsoft.EntityFrameworkCore" Version="8.0.8" />
                    <PackageReference Include="Microsoft.EntityFrameworkCore.SqlServer" Version="8.0.8" />
                    <PackageReference Include="Microsoft.EntityFrameworkCore.Tools" Version="8.0.8">
                      <PrivateAssets>all</PrivateAssets>
                      <IncludeAssets>runtime; build; native; contentfiles; analyzers; buildtransitive</IncludeAssets>
                    </PackageReference>
                    <PackageReference Include="Microsoft.VisualStudio.Web.CodeGeneration.Design" Version="8.0.5" />
                  </ItemGroup>

                </Project>
                """);
        }
    }
}
