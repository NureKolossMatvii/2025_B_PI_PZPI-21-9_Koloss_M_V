﻿using SharpCraftStudio.CodeGeneration.CommonFilesGenerator.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.DataSelection.Interfaces;
using SharpCraftStudio.CodeGeneration.Converters.EntityFrameworkModels.ProjectToStringConverters.Interfaces;
using SharpCraftStudio.CodeGeneration.FileSystemModels;
using SharpCraftStudio.CodeGeneration.Models;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CommonFilesGenerator
{
    internal class DatabaseFolderGenerator : IDatabaseFolderGenerator
    {
        private readonly IEFCoreModelsFolderConverter _contentConverter;
        private readonly IDbContextFileGenerator _dbContextFileGenerator;
        private readonly IDataSelectionParametersGenerator _selectionParametersGenerator;
        private readonly ISortingEnumGenerator _sortingEnumGenerator;

        public DatabaseFolderGenerator(IEFCoreModelsFolderConverter contentConverter, IDbContextFileGenerator dbContextFileGenerator, IDataSelectionParametersGenerator selectionParametersGenerator, ISortingEnumGenerator sortingEnumGenerator)
        {
            _contentConverter = contentConverter;
            _dbContextFileGenerator = dbContextFileGenerator;
            _selectionParametersGenerator = selectionParametersGenerator;
            _sortingEnumGenerator = sortingEnumGenerator;
        }

        public ProjectFolderInfo ConvertToFolder(ProjectConfigurationDto projectConfiguration)
        {
            var selectionSortParameters = projectConfiguration.Diagram.Tables
                .Select(c => _selectionParametersGenerator.GenerateForTable(projectConfiguration, c.TableId))
                .Select(c => c.FirstOrDefault(c => c is MethodDataSelectionSortParameter))
                .Where(c => c is not null)
                .Select(c => c as MethodDataSelectionSortParameter);

            var folder = new ProjectFolderInfo("Database");
            var modelsFolder = _contentConverter.ConvertToFolder(projectConfiguration);
            foreach ( var parameter in selectionSortParameters )
            {
                modelsFolder.AddItem(_sortingEnumGenerator.Generate(parameter, projectConfiguration.Name));
            }

            folder.AddItem(modelsFolder);
            folder.AddItem(_dbContextFileGenerator.Generate(projectConfiguration.Name, projectConfiguration.Diagram));

            return folder;
        }
    }
}
