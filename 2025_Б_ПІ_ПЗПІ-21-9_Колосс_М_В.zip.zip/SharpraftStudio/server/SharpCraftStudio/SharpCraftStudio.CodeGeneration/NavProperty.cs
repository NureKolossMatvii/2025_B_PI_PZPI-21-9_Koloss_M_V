﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration
{
    internal static class NavProperty
    {
        public static string GetName(string otherTableName)
        {
            return otherTableName + "NavProperty";
        }
    }
}
