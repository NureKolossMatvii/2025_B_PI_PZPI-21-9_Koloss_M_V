﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration
{
    internal class NamespaceNames
    {

        public static string GetEFCoreModelsNamespace(string projectName)
            => JoinNamespaceName(FormatProjectNamespace(projectName), "Database.Models");

        public static string GetEFCoreContextNamespace(string projectName)
            => JoinNamespaceName(FormatProjectNamespace(projectName), "Database");

        public static string GetControllersNamespace(string projectName)
            => JoinNamespaceName(FormatProjectNamespace(projectName), "Controllers");

        public static string GetViewModelsNamespace(string projectName)
            => JoinNamespaceName(FormatProjectNamespace(projectName), "ViewModels");

        private static string FormatProjectNamespace(string projectName)
            => projectName.Replace(" ", "");
        private static string JoinNamespaceName(string left, string right)
            => $"{left}.{right}";
    }
}
