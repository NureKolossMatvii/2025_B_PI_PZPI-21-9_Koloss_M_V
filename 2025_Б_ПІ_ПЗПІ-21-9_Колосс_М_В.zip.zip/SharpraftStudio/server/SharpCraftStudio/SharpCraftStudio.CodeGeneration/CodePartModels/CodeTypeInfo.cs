﻿using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CodePartModels
{
    internal class CodeTypeInfo(
        string Name,
        AccessModifier AccessModifier,
        CodeAttribute[] Attributes
        )
    {
        public string Name { get; } = Name;
        public AccessModifier AccessModifier { get; } = AccessModifier;
        public CodeAttribute[] Attributes { get; } = Attributes;
    }
}
