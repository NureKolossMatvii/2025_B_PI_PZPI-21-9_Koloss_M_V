﻿using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CodePartModels
{
    internal record CodeMethodInfo(
        string MethodName,
        string ReturnType,
        AccessModifier AccessModifier,
        ExecutionProcessModifier ExecutionProcessModifier,
        string Code)
    {
        public List<CodeParameterInfo> Parameters { get; } = new();

        public List<CodeAttribute> Attributes { get; } = new();

        public CodeMethodInfo AddParameter(CodeParameterInfo parameter)
        {
            Parameters.Add(parameter);
            return this;
        }


        public CodeMethodInfo AddAttribute(CodeAttribute attribute)
        {
            Attributes.Add(attribute);
            return this;
        }
    }
}
