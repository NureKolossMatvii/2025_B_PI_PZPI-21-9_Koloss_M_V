﻿using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CodePartModels
{
    internal class CodeDataTypeInfo : CodeTypeInfo
    {
        public CodeDataTypeInfo(string Name, AccessModifier AccessModifier, CodeAttribute[] Attributes, string[] implementedInterfaces, string[] genericArgs) : base(Name, AccessModifier, Attributes)
        {
            ImplementedInterfaces = implementedInterfaces;
            GenericArgs = genericArgs;
        }

        public string[] ImplementedInterfaces { get; }
        public string[] GenericArgs { get; }
    }
}
