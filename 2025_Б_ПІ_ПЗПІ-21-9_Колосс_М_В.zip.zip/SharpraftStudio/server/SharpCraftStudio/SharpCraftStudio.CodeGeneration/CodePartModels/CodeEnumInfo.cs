﻿using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CodePartModels
{
    internal class CodeEnumInfo : CodeTypeInfo
    {
        public CodeEnumInfo(string Name, AccessModifier AccessModifier) : base(Name, AccessModifier, [])
        {
        }

        public List<string> Items {  get; set; } = new List<string>();
    }
}
