﻿using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CodePartModels
{
    internal record CodeDataInfo(
        string Name,
        AccessModifier AccessModifier,
        string TypeName,
        DataInfoTypeModifier DataInfoTypeModifier,
        List<CodeAttribute> Attributes
        )
    {
    }
}
