﻿using SharpCraftStudio.CodeGeneration.MemberModifiers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CodePartModels
{
    internal class CodeClassInfo : CodeDataTypeInfo
    {
        public CodeClassInfo(
            string Name,
            AccessModifier AccessModifier,
            CodeDataInfo[] DataInfos,
            CodeMethodInfo[] MethodInfos,
            string? BaseClassName,
            string[] ImplementedInterfaces,
            CodeAttribute[] Attributes,
            string[] Constractors,
            string[] GenericArgs
        ) : base(Name, AccessModifier, Attributes, GenericArgs, ImplementedInterfaces)
        {
            this.BaseClassName = BaseClassName;
            this.Constractors = Constractors;
            this.MethodInfos = MethodInfos;
            this.DataInfos = DataInfos;
        }

        public CodeDataInfo[] DataInfos { get; private set; }
        public CodeMethodInfo[] MethodInfos { get; private set; }
        public string? BaseClassName { get; private set; }
        public string[] Constractors { get; }
    }
}
