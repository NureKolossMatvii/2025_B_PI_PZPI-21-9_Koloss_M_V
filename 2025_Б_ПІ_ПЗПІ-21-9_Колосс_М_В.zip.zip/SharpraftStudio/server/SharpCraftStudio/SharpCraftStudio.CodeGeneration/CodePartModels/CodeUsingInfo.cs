﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CodePartModels
{
    internal record struct CodeUsingInfo(string AssemblyName)
    {
        public readonly static CodeUsingInfo SYSTEM = new CodeUsingInfo("System");
        public readonly static CodeUsingInfo SYSTEM_COLLECTIONS_GENERIC = new CodeUsingInfo("System.Collections.Generic");
        public readonly static CodeUsingInfo SYSTEM_LINQ = new CodeUsingInfo("System.Linq");
        public readonly static CodeUsingInfo SYSTEM_TASKS = new CodeUsingInfo("System.Threading.Tasks");
        public readonly static CodeUsingInfo ASPNETCORE_MVC = new CodeUsingInfo("Microsoft.AspNetCore.Mvc");
        public readonly static CodeUsingInfo ASPNETCORE_MVC_RENDERING = new CodeUsingInfo("Microsoft.AspNetCore.Mvc.Rendering");
        public readonly static CodeUsingInfo ENTITY_FRAMEWORK_CORE = new CodeUsingInfo("Microsoft.EntityFrameworkCore");
        public readonly static CodeUsingInfo DATAANATATIONS = new CodeUsingInfo("System.ComponentModel.DataAnnotations");
        public readonly static CodeUsingInfo DATAANATATIONS_SCHEMA = new CodeUsingInfo("System.ComponentModel.DataAnnotations.Schema");
    }
}
