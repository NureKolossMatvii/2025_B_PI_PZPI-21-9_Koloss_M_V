﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CodePartModels
{
    internal static class CodePartSymbols
    {
        public const string SEMICOLON = ";";
        public const string NEXT_LINE = "\n";
        public const string OPEN_BRACE = "{";
        public const string CLOSE_BRACE = "}";
    }
}
