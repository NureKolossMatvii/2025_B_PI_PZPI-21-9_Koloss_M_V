﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.CodePartModels
{
    internal record CodeParameterInfo(string Type, string Name, bool Nullable = false)
    {
    }
}
