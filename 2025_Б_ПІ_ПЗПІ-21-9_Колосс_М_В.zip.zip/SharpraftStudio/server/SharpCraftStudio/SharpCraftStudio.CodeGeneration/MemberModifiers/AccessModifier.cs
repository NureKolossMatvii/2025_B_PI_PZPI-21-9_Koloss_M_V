﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.MemberModifiers
{
    internal enum AccessModifier
    {
        Public,
        Protected,
        Private,
        Internal,
    }

    internal static class AccessModifierExtensions
    {
        internal static string ConvertToString(this AccessModifier accessModifier)
        {
            if(accessModifier == AccessModifier.Public)
            {
                return "public";
            }

            if(accessModifier == AccessModifier.Protected)
            {
                return "protected";
            }

            if(accessModifier == AccessModifier.Private)
            {
                return "private";
            }

            if(accessModifier == AccessModifier.Internal)
            {
                return "internal";
            }

            throw new NotImplementedException();
        }
    }
}
