﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.FileSystemModels
{
    public enum FileExtension
    {
        Sln,
        CSProj,
        CS,
        Json,
        CSHtml,
        Css,
    }

    public static class FileExtensionExtensions
    {
        public static string GetExtension(this FileExtension extension)
        {
            switch (extension)
            {
                case FileExtension.CSProj:
                    return "csproj";
                case FileExtension.Sln:
                    return "sln";
                case FileExtension.CS:
                    return "cs";
                case FileExtension.Json:
                    return "json";
                case FileExtension.CSHtml:
                    return "cshtml";
                case FileExtension.Css:
                    return "css";
            }

            throw new NotImplementedException();
        }
    }
}
