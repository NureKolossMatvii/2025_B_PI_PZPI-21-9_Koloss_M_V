﻿using SharpCraftStudio.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.FileSystemModels
{
    public class ProjectFileInfo(string Name, FileExtension Extension, string Content) : IFolderItem, IIgnoreInjection
    {
        public void AddToZip(ZipArchive archive, string folderPath = "")
        {
            var filePath = string.IsNullOrEmpty(folderPath) ? $"{Name}.{Extension.GetExtension()}" : $"{folderPath}/{Name}.{Extension.GetExtension()}";

            var entry = archive.CreateEntry(filePath);
            using (var entryStream = entry.Open())
            using (var writer = new StreamWriter(entryStream))
            {
                writer.Write(Content);
            }
        }
    }
}
