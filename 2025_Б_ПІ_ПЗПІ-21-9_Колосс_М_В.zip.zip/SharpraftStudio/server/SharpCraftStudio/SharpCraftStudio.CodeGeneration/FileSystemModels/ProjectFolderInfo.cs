﻿using SharpCraftStudio.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.IO.Compression;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration.FileSystemModels
{
    public class ProjectFolderInfo : IFolderItem, IIgnoreInjection
    {
        private readonly string _name;
        private readonly List<IFolderItem> _items = new();

        public ProjectFolderInfo(string name)
        {
            _name = name;
        }

        public ProjectFolderInfo AddItem(IFolderItem item)
        {
            _items.Add(item);
            return this;
        }

        public void AddToZip(ZipArchive archive, string parentPath = "")
        {
            var folderPath = string.IsNullOrEmpty(parentPath) ? _name : $"{parentPath}/{_name}";

            foreach (var item in _items)
            {
                item.AddToZip(archive, folderPath);
            }
        }
    }
}
