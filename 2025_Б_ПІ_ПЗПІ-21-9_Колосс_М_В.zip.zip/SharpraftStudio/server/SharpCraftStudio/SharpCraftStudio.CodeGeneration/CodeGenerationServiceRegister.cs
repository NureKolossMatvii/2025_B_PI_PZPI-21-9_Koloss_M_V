﻿using Microsoft.Extensions.DependencyInjection;
using SharpCraftStudio.CodeGeneration.CodePartModels;
using SharpCraftStudio.Core.Interfaces;
using System;
using System.Linq;
using System.Reflection;

namespace SharpCraftStudio.CodeGeneration
{
    public class CodeGenerationServiceRegister
    {
        public static void Register(IServiceCollection services)
        {
            var assembly = Assembly.GetExecutingAssembly();

            var typesToRegister = assembly.GetTypes()
                .Where(type => type.IsClass &&
                               !type.IsAbstract &&
                               type.GetInterfaces().Any(c => !c.IsGenericType || c.GetGenericTypeDefinition() != typeof(IEquatable<>)) &&
                               type.GetInterface(nameof(IIgnoreInjection)) == null)
                .Select(type => new
                {
                    Implementation = type,
                    Interface = type.GetInterfaces().FirstOrDefault()
                })
                .Where(x => x.Interface != null)
                .ToArray();

            foreach (var typePair in typesToRegister)
            {
                services.AddScoped(typePair.Interface, typePair.Implementation);
            }
        }
    }
}
