﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.CodeGeneration
{
    internal static class GlobalClassNames
    {
        public const string DBCONTEXT_CLASSNAME = "DatabaseContext";
    }
}
