﻿namespace SharpCraftStudio.Core
{
    public static class OperationResultFactory
    {
        public static OperationResult<TResult> Successed<TResult>(TResult result)
        {
            if (result == null)
            {
                throw new ArgumentNullException(nameof(result));
            }

            return new OperationResult<TResult>(true, result, null);
        }

        public static OperationResult Successed()
        {
            return new OperationResult(true, null);
        }

        public static OperationResult<TResult> Failured<TResult>(Dictionary<string, string[]>? errors)
        {
            if (errors == null)
            {
                throw new ArgumentNullException(nameof(errors));
            }

            return new OperationResult<TResult>(false, default, errors);
        }

        public static OperationResult FailuredWithGeneralError(string error)
        {
            if (error == null)
            {
                throw new ArgumentNullException(nameof(error));
            }

            return new OperationResult(false, new Dictionary<string, string[]>()
            {
                { "GeneralError", new string[] { error } }
            });
        }

        public static OperationResult<TResult> FailuredWithGeneralError<TResult>(string error)
        {
            if (error == null)
            {
                throw new ArgumentNullException(nameof(error));
            }

            return new OperationResult<TResult>(false, default, new Dictionary<string, string[]>()
            {
                { "GeneralError", new string[] { error } }
            });
        }
    }
}
