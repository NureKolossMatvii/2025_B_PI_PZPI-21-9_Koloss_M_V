﻿namespace SharpCraftStudio.Core
{
    public record OperationResult<TResult>(bool Success, TResult? Result, Dictionary<string, string[]>? Errors)
    {
    }

    public record OperationResult(bool Success, Dictionary<string, string[]>? Errors)
    {
    }
}
