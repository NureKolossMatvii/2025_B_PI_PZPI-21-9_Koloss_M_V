﻿using Microsoft.EntityFrameworkCore;
using SharpCraftStudio.Data.Models;
using System.Linq.Expressions;

namespace SharpCraftStudio.Core.Interfaces
{
    public interface IBaseRepository<TEntity, TKey, TDbContext>
        where TEntity : class, IEntity
        where TDbContext : DbContext
    {
        Task CreateAsync(TEntity entity);

        Task UpdateAsync(TEntity entity);

        Task RemoveAsync(TEntity entity);

        Task RemoveAsync(IEnumerable<TEntity> entities);

        Task<TEntity> GetAsync(TKey id);

        Task<List<TEntity>> GetAllWithConditionAsync(Expression<Func<TEntity, bool>> condition);

        Task<List<TEntity>> GetAllAsync();
    }
}
