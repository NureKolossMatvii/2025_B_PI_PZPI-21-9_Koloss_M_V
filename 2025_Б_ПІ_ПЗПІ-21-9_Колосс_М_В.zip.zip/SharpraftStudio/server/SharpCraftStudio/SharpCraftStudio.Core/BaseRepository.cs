﻿using Amazon.Auth.AccessControlPolicy;
using Microsoft.EntityFrameworkCore;
using SharpCraftStudio.Core.Interfaces;
using SharpCraftStudio.Data;
using SharpCraftStudio.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Core
{
    public abstract class BaseRepository<TEntity, TKey, TDbContext> : IBaseRepository<TEntity, TKey, TDbContext>
        where TEntity : class, IEntity
        where TDbContext : DbContext
    {
        public readonly IAppDbContext<TDbContext> _db;

        public BaseRepository(IAppDbContext<TDbContext> db)
        {
            _db = db;
        }

        public async Task CreateAsync(TEntity entity)
        {
            _db.GetSet<TEntity>().Add(entity);
            await _db.SaveChangesAsync();
        }


        public async Task RemoveAsync(TEntity entity)
        {
            _db.GetSet<TEntity>().Remove(entity);
            await _db.SaveChangesAsync();
        }

        public async Task UpdateAsync(TEntity entity)
        {
            _db.GetSet<TEntity>().Update(entity);
            await _db.SaveChangesAsync();
        }

        public virtual async Task<List<TEntity>> GetAllWithConditionAsync(Expression<Func<TEntity, bool>> condition)
        {
            return await _db.GetSet<TEntity>().Where(condition).ToListAsync();
        }

        public virtual async Task<TEntity> GetAsync(TKey id)
        {
            return await _db.GetSet<TEntity>().FindAsync(id);
        }

        public async Task RemoveAsync(IEnumerable<TEntity> entities)
        {
            _db.GetSet<TEntity>().RemoveRange(entities);
            await _db.SaveChangesAsync();
        }

        public async virtual Task<List<TEntity>> GetAllAsync()
        {
            return await _db.GetSet<TEntity>().ToListAsync();
        }
    }
}
