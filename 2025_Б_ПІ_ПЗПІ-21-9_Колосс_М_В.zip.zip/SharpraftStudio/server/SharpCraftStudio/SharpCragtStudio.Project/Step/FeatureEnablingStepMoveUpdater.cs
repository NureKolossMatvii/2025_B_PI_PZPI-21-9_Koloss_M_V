﻿using AutoMapper;
using SharpCraftStudio.Data.Models.Project;
using SharpCraftStudio.Project.Step.Interfaces;

namespace SharpCraftStudio.Project.Step
{
    internal class FeatureEnablingStepMoveUpdater : IStepMoveUpdater
    {
        public void OnStepMove(ProjectConfiguration projectConfiguration, IMapper _)
        {
            /*var authEnabled = projectConfiguration.EnabledFeatures.AuthorizationEnabled;
            if (authEnabled)
            {
                var table = new UMLTable()
                {
                    TableId = Guid.NewGuid(),
                    Name = projectConfiguration.EnabledFeatures.UserTableName,
                    Operations = new UMLTableOperations()
                    {
                        ColumnCreationAvailable = true,
                        NameChangeEnabled = false,
                        RemoveEnabled = false,
                    },
                    Position = new(0, 0),
                    Columns = new()
                    {
                        new UMLTableColumn()
                        {
                            DataType = UMLColumnDataType.String,
                            IsPrimaryKey = true,
                            Name = "Login",
                            TableColumnId = Guid.NewGuid(),
                            Operations = new()
                            {
                                DataTypeChangeAvailable = false,
                                NameChangeEnabled = false,
                                RemoveEnabled = false,
                                RestrictionChangeAvailable = false,
                            }
                        },
                        new UMLTableColumn()
                        {
                            DataType = UMLColumnDataType.String,
                            IsPrimaryKey = false,
                            Name = "Password",
                            TableColumnId = Guid.NewGuid(),
                            Operations = new()
                            {
                                DataTypeChangeAvailable = false,
                                NameChangeEnabled = false,
                                RemoveEnabled = false,
                                RestrictionChangeAvailable = false,
                            }
                        },
                    }
                };

                projectConfiguration.Diagram = new UMLDiagram()
                {
                    Tables = new List<UMLTable>() { table },
                };
            }*/
        }
    }
}
