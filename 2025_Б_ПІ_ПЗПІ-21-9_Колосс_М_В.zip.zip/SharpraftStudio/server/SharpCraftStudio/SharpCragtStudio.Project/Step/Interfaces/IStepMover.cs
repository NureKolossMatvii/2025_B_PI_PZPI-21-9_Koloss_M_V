﻿using AutoMapper;
using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models.Project;

namespace SharpCraftStudio.Project.Step.Interfaces
{
    internal interface IStepMover
    {
        ProjectCreationStep CreationStep { get; }

        OperationResult TryMoveToNextStep(ProjectConfiguration projectConfiguration, IMapper mapper);
    }
}
