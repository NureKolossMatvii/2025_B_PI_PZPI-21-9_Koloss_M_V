﻿using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models.Project;
using SharpCraftStudio.Project.Step.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Step
{
    internal class EmptyStepMoveValidator : IStepMoveValidator
    {
        public OperationResult Validate(ProjectConfiguration projectConfiguration)
        {
            return OperationResultFactory.Successed();
        }
    }
}
