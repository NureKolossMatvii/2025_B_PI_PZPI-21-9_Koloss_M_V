﻿using Microsoft.Extensions.DependencyInjection;
using SharpCraftStudio.Data.Models.Project;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Interfaces.Repositories;
using SharpCraftStudio.Project.Repositories;
using SharpCraftStudio.Project.Services;
using SharpCraftStudio.Project.Step;
using SharpCraftStudio.Project.Step.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project
{
    public static class ProjectServiceRegister
    {
        public static void Register(IServiceCollection services)
        {
            services.AddScoped<IProjectService, ProjectService>();
            services.AddScoped<IColorTemplatesService, ColorTemplatesService>();
            services.AddScoped<IUMLDiagramService, UMLDiagramService>();
            services.AddScoped<IProjectConfigurationRepository, ProjectConfigurationRepository>();
            services.AddScoped<IColorTemplatesRepository, ColorTemplatesRepository>();
            services.AddScoped<IProjectStepMoveService, ProjectStepMoveService>();


            services.AddSingleton<IDefaultValidationConfigExtractor, DefaultValidationConfigExtractor>();
            services.AddSingleton<IDefaultViewConfigExtractor, DefaultViewConfigExtractor>();

            services.AddScoped<IViewConfigService, ViewConfigService>();

            var emptyStepMoveValidator = new EmptyStepMoveValidator();
            var stepConfigBuilder = new StepMoversConfigurationBuilder();

            stepConfigBuilder
                .AddNextStep(ProjectCreationStep.FeaturesEnabling, emptyStepMoveValidator, new FeatureEnablingStepMoveUpdater())
                .AddNextStep(ProjectCreationStep.UmlCreation, emptyStepMoveValidator, new UmlCreationStepMoveUpdater(new DefaultViewConfigExtractor()))
                .AddNextStep(ProjectCreationStep.TableViewConfiguration, emptyStepMoveValidator, new TableViewConfigurationStepMoveUpdater(new DefaultValidationConfigExtractor()))
                .AddNextStep(ProjectCreationStep.ValidationEnabling, emptyStepMoveValidator)
                .AddNextStep(ProjectCreationStep.ColorsSelection, emptyStepMoveValidator)
                .AddNextStep(ProjectCreationStep.Receiving, emptyStepMoveValidator);

            var config = stepConfigBuilder.Build();
            services.AddSingleton(config);
        }
    }
}
