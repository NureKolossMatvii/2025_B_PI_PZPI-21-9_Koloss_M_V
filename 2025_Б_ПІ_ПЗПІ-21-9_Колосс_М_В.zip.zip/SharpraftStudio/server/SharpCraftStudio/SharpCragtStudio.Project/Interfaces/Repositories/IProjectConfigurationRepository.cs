﻿using SharpCraftStudio.Core.Interfaces;
using SharpCraftStudio.Data;
using SharpCraftStudio.Data.Models.Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Interfaces.Repositories
{
    public interface IProjectConfigurationRepository : IBaseRepository<ProjectConfiguration, Guid, AppMongoDbContext>
    {
    }
}
