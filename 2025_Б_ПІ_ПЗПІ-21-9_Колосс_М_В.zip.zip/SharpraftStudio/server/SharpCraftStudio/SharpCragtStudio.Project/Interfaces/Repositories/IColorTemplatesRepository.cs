﻿using SharpCraftStudio.Core.Interfaces;
using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SharpCraftStudio.Data.Models.Project.ColorTemplates;

namespace SharpCraftStudio.Project.Interfaces.Repositories
{
    internal interface IColorTemplatesRepository : IBaseRepository<ColorTemplate, Guid, AppMongoDbContext>
    {
    }
}
