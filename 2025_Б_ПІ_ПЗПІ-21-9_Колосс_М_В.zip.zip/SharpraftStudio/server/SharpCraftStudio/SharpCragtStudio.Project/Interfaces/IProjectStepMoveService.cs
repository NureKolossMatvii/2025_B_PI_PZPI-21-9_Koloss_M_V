﻿using SharpCraftStudio.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Interfaces
{
    public interface IProjectStepMoveService
    {
        Task<OperationResult> MoveToNextStepAsync(Guid projectId, string userName);
    }
}
