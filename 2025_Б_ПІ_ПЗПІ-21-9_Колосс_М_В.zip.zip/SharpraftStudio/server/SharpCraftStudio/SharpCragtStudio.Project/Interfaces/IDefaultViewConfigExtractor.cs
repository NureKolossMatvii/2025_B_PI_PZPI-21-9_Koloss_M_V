﻿using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Project.Models.UML;

namespace SharpCraftStudio.Project.Interfaces
{
    public interface IDefaultViewConfigExtractor
    {
        ViewConfigDto Extract(UMLDiagramDto diagram);
    }
}
