﻿using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Interfaces
{
    public interface IViewConfigService
    {
        Task<OperationResult<ViewConfigDto>> GetViewConfigAsync(Guid projectConfigurationId);

        Task<OperationResult> SetViewConfigAsync(ViewConfigDto viewConfig, Guid projectConfigurationId);

        Task<OperationResult> SetDefaultViewConfigAsync(Guid projectConfigurationId);
    }
}
