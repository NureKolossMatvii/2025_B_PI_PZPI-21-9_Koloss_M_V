﻿using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models.Project.Validation;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Interfaces
{
    public interface IProjectService
    {
        Task<ProjectConfigurationDto?> GetByIdForUserAsync(Guid id, string userName);

        Task<OperationResult<ProjectConfigurationDto>> GetResultAsync(Guid id, string userName);

        Task<List<ProjectConfigurationDto>> GetForUserAsync(string userName);

        Task<OperationResult> CreateAsync(ProjectCreationDto projectCreationDto, string userName);

        Task<OperationResult> DeleteAsync(Guid id, string userName);

        Task<OperationResult> SaveEnabledFeaturesAsync(SetupEnabledFeaturesDto enabledFeaturesDto, string userName);

        Task<OperationResult> SaveValidation(Guid projectId, ValidationConfig validationConfig, string userName);

        Task<OperationResult> SaveColorTemplate(Guid projectId, Guid templateId, string userName);
    }
}
