﻿using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models.Project.ColorTemplates;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Interfaces
{
    public interface IColorTemplatesService
    {
        Task<ColorTemplate> GetAsync(Guid id);

        Task<List<ColorTemplate>> GetAllAsync();

        Task<OperationResult> AddAsync(ColorTemplate template);

        Task<OperationResult> RemoveAsync(Guid id);

        Task<OperationResult> EditAsync(ColorTemplate template);
    }
}
