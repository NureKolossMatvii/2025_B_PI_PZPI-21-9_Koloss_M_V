﻿using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Data.Models.Project.Validation;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Interfaces
{
    public interface IDefaultValidationConfigExtractor
    {
        ValidationConfig Extract(UMLDiagram diagram);
    }
}
