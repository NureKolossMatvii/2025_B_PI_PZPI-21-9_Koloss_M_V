﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Models.UML
{
    public class UMLDiagramDto
    {
        public List<UMLTableDto> Tables { get; set; }

        public List<UMLTableConnectionDto> Connections { get; set; }
    }
}
