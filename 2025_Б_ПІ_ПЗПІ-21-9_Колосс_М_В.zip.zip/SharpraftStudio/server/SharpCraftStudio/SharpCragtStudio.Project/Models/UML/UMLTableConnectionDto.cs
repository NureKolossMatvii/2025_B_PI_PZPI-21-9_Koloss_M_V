﻿using SharpCraftStudio.Data.Models.Project.UML;

namespace SharpCraftStudio.Project.Models.UML
{
    public class UMLTableConnectionDto
    {
        public Guid TableConnectionId { get; set; }

        public Guid LeftTableId { get; set; }

        public Guid RightTableId { get; set; }

        public Guid ForeignKeyColumnId { get; set; }

        public UMLConnectionType ConnectionType { get; set; }

        public UMLTableDto GetAnotherTable(UMLTableDto target, List<UMLTableDto> tables)
        {
            if(target.TableId == LeftTableId)
            {
                return tables.First(c => c.TableId == RightTableId);
            }

            if(target.TableId == RightTableId)
            {
                return tables.First(c => c.TableId == LeftTableId);
            }

            throw new InvalidOperationException();
        }

        public bool IsForTableWithId(Guid tableId)
        {
            return LeftTableId == tableId || RightTableId == tableId;
        }
    }
}
