﻿namespace SharpCraftStudio.Project.Models.UML
{
    public class UMLDiagramSaveDto
    {
        public Guid ProjectId { get; set; }

        public List<UMLTableDto> Tables { get; set; }

        public List<UMLTableConnectionDto> Connections { get; set; }
    }
}
