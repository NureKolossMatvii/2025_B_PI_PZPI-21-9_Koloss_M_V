﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Models.UML.Operations
{
    public class UMLOperationsBaseDto
    {
        public bool RemoveEnabled { get; set; } = true;
        public bool NameChangeEnabled { get; set; } = true;
    }
}
