﻿using SharpCraftStudio.Project.Models.UML.Operations;
using SharpCraftStudio.Data.Models.Project;

namespace SharpCraftStudio.Project.Models.UML
{
    public class UMLTableDto
    {
        public Guid TableId { get; set; }

        public string Name { get; set; }

        public Position Position { get; set; }

        public UMLTableOperationsDto Operations { get; set; }

        public List<UMLTableColumnDto> Columns { get; set; }

        public Guid LabelColumnTableId { get; set; }
    }
}
