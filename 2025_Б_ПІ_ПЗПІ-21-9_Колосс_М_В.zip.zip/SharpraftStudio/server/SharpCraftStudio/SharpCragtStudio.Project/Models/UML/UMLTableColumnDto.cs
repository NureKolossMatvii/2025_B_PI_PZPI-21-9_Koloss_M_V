﻿using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Project.Models.UML.Operations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Models.UML
{
    public class UMLTableColumnDto
    {
        public Guid TableColumnId { get; set; }

        public string Name { get; set; }

        public bool IsForeignKey { get; set; }

        public bool IsPrimaryKey { get; set; }

        public UMLTableColumnOperationsDto Operations { get; set; }

        public UMLColumnDataType DataType { get; set; }
    }
}
