﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Models
{
    public class ProjectCreationDto
    {
        public Guid ProjectConfigurationId { get; set; }

        public string Name {  get; set; }
    }
}
