﻿using SharpCraftStudio.Project.Models.TableView;

namespace SharpCraftStudio.Data.Models
{
    public class ViewConfigDto
    {
        public List<TableViewConfigDto> TableViewConfigs { get; set; } = new();
    }
}
