﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Models
{
    public class SetupEnabledFeaturesDto
    {
        public Guid ProjectId { get; set; }

        public bool AuthorizationEnabled { get; set; }

        public string UserTableName { get; set; }
    }
}
