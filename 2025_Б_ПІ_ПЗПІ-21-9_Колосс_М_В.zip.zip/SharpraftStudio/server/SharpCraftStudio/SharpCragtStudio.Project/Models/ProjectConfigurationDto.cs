﻿using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Project.Models.UML;
using SharpCraftStudio.Data.Models.Project.Validation;
using SharpCraftStudio.Data.Models.Project;

namespace SharpCraftStudio.Project.Models
{
    public class ProjectConfigurationDto
    {
        public Guid ProjectConfigurationId { get; set; }

        public string Name { get; set; }

        public DateTime CreationDate { get; set; }

        public ProjectCreationStep Step { get; set; }

        public Guid? ColorTemplateId { get; set; }

        public EnabledFeatures? EnabledFeatures { get; set; } = new();

        public UMLDiagramDto? Diagram { get; set; } = new();

        public ViewConfigDto ViewConfig { get; set; } = new();

        public ValidationConfig ValidationConfig { get; set; } = new();
    }
}
