﻿using SharpCraftStudio.Data.Models.Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Models
{
    public class UpdateProjectStepDto
    {
        public Guid ProjectId { get; set; }

        public ProjectCreationStep Step { get; set; }
    }
}
