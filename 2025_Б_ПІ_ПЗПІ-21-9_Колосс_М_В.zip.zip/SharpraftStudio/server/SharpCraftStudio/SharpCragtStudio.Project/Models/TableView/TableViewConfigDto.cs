﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Models.TableView
{
    public class TableViewConfigDto
    {
        public Guid TableViewConfigurationId { get; set; }
        public Guid UMLTableId { get; set; }
        public string Label { get; set; }

        public List<ColumnViewConfigDto> ColumnViewConfigs { get; set; } = new();

        public string GetTypeName()
        {
            return Label.Replace(" ", "") + "ViewModel";
        }
    }
}
