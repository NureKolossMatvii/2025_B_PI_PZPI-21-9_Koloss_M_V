﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Models.TableView
{
    public class ColumnViewConfigDto
    {
        public Guid ColumnViewConfigurationId { get; set; }
        public Guid UMLColumnId { get; set; }

        public string Label { get; set; }
        public DatasetSelectorRulesDto DatasetSelectorRules { get; set; }

        public string GetViewModelPropertyName()
        {
            return Label.Replace(" ", "");
        }
    }
}
