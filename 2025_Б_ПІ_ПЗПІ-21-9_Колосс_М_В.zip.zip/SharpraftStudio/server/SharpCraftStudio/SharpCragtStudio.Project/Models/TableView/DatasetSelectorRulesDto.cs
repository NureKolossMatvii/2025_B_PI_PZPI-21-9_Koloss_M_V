﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Models.TableView
{
    public class DatasetSelectorRulesDto
    {
        public bool SortingEnabled { get; set; }
        public bool SearchingEnabled { get; set; }
        public bool FilteringEnabled { get; set; }
    }
}
