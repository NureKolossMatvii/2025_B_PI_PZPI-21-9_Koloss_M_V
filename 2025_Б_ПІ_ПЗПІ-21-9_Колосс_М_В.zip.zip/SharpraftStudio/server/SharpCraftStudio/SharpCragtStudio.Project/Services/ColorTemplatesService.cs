﻿using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models.Project.ColorTemplates;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Services
{
    internal class ColorTemplatesService : IColorTemplatesService
    {
        private readonly IColorTemplatesRepository _repository;

        public ColorTemplatesService(IColorTemplatesRepository repository)
        {
            _repository = repository;
        }

        public async Task<OperationResult> AddAsync(ColorTemplate template)
        {
            await _repository.CreateAsync(template);
            return OperationResultFactory.Successed();
        }

        public async Task<OperationResult> EditAsync(ColorTemplate template)
        {
            await _repository.UpdateAsync(template);

            return OperationResultFactory.Successed();
        }

        public async Task<List<ColorTemplate>> GetAllAsync()
        {
            return await _repository.GetAllAsync();
        }

        public async Task<ColorTemplate> GetAsync(Guid id)
        {
            return await _repository.GetAsync(id);
        }

        public async Task<OperationResult> RemoveAsync(Guid id)
        {

            var template = await GetAsync(id);
            await _repository.RemoveAsync(template);
            return OperationResultFactory.Successed();
        }
    }
}
