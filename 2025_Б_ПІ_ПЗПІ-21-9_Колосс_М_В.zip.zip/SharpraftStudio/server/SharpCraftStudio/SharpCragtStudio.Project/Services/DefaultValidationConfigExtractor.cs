﻿using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Data.Models.Project.Validation;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Services
{
    internal class DefaultValidationConfigExtractor : IDefaultValidationConfigExtractor
    {
        public ValidationConfig Extract(UMLDiagram diagram)
        {
            var tableValidationConfigs = new List<TableValidationConfig>();

            foreach (var table in diagram.Tables)
            {
                var columnConfigs = new List<ColumnValidationConfig>();

                foreach (var column in table.Columns)
                {
                    if (column.IsPrimaryKey)
                        continue;

                    columnConfigs.Add(new ColumnValidationConfig()
                    {
                        ColumnValidationConfigurationId = Guid.NewGuid(),
                        UmlColumnId = column.TableColumnId,
                        Validation = [
                            new Validation()
                            {
                                Type = ValidationType.Required,
                                Message = $"Field {column.Name} is required"
                            }
                        ]
                    });
                }

                tableValidationConfigs.Add(new TableValidationConfig()
                {
                    ColumnValidationConfigs = columnConfigs,
                    TableValidationConfigurationId = Guid.NewGuid(),
                    UmlTableId = table.TableId
                });
            }

            var validationConfig = new ValidationConfig()
            {
                TableValidationConfigs = tableValidationConfigs,
            };

            return validationConfig;
        }
    }
}
