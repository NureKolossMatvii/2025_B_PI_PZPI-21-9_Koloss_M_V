﻿using AutoMapper;
using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Data.Models.Project;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Interfaces.Repositories;
using SharpCraftStudio.Project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Services
{
    internal class ViewConfigService : IViewConfigService
    {
        private readonly IProjectConfigurationRepository _projectConfigurationRepository;
        private readonly IDefaultViewConfigExtractor _defaultViewConfigExtractor;
        private readonly IMapper _mapper;

        public ViewConfigService(IProjectConfigurationRepository projectConfigurationRepository, IDefaultViewConfigExtractor defaultViewConfigExtractor, IMapper mapper)
        {
            _projectConfigurationRepository = projectConfigurationRepository;
            _defaultViewConfigExtractor = defaultViewConfigExtractor;
            _mapper = mapper;
        }

        public async Task<OperationResult<ViewConfigDto>> GetViewConfigAsync(Guid projectConfigurationId)
        {
            var project = await _projectConfigurationRepository.GetAsync(projectConfigurationId);
            return OperationResultFactory.Successed(_mapper.Map<ViewConfigDto>(project.ViewConfig));
        }

        public async Task<OperationResult> SetDefaultViewConfigAsync(Guid projectConfigurationId)
        {
            var project = await _projectConfigurationRepository.GetAsync(projectConfigurationId);
            var projectDto = _mapper.Map<ProjectConfigurationDto>(project);

            var defaultViewConfig = _defaultViewConfigExtractor.Extract(projectDto.Diagram!);

            project.ViewConfig = _mapper.Map<ViewConfig>(defaultViewConfig);

            await _projectConfigurationRepository.UpdateAsync(project);

            return OperationResultFactory.Successed();
        }

        public async Task<OperationResult> SetViewConfigAsync(ViewConfigDto viewConfig, Guid projectConfigurationId)
        {
            var project = await _projectConfigurationRepository.GetAsync(projectConfigurationId);
            project.ViewConfig = _mapper.Map<ViewConfig>(viewConfig);

            await _projectConfigurationRepository.UpdateAsync(project);

            return OperationResultFactory.Successed();
        }
    }
}
