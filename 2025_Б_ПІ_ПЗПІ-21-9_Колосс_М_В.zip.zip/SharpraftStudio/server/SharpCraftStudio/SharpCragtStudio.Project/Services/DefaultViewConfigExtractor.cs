﻿using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Models.TableView;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SharpCraftStudio.Project.Services
{
    internal class DefaultViewConfigExtractor : IDefaultViewConfigExtractor
    {
        public ViewConfigDto Extract(UMLDiagramDto diagram)
        {
            var viewConfigDto = InitializeViewConfigDto();

            foreach (var table in diagram.Tables)
            {
                var tableViewConfig = CreateTableViewConfig(table, diagram);
                viewConfigDto.TableViewConfigs.Add(tableViewConfig);
            }

            return viewConfigDto;
        }

        private ViewConfigDto InitializeViewConfigDto()
        {
            return new ViewConfigDto
            {
                TableViewConfigs = new List<TableViewConfigDto>()
            };
        }

        private TableViewConfigDto CreateTableViewConfig(UMLTableDto table, UMLDiagramDto diagram)
        {
            var tableViewConfig = new TableViewConfigDto
            {
                Label = table.Name,
                ColumnViewConfigs = new List<ColumnViewConfigDto>(),
                TableViewConfigurationId = Guid.NewGuid(),
                UMLTableId = table.TableId
            };

            foreach (var column in table.Columns)
            {
                if (column.IsForeignKey)
                {
                    var foreignKeyConfig = CreateForeignKeyConfig(column, table, diagram);
                    tableViewConfig.ColumnViewConfigs.Add(foreignKeyConfig);
                }
                else
                {
                    var simpleColumnConfig = CreateSimpleColumnConfig(column);
                    tableViewConfig.ColumnViewConfigs.Add(simpleColumnConfig);
                }
            }

            return tableViewConfig;
        }

        private ColumnViewConfigDto CreateSimpleColumnConfig(UMLTableColumnDto column)
        {
            return new ColumnViewConfigDto
            {
                DatasetSelectorRules = new (),
                ColumnViewConfigurationId = Guid.NewGuid(),
                Label = column.Name,
                UMLColumnId = column.TableColumnId
            };
        }

        private ColumnViewConfigDto CreateForeignKeyConfig(UMLTableColumnDto column, UMLTableDto table, UMLDiagramDto diagram)
        {
            var connection = diagram.Connections.First(c => c.ForeignKeyColumnId == column.TableColumnId);
            var anotherTable = connection.GetAnotherTable(table, diagram.Tables);
            var columnId = anotherTable.LabelColumnTableId;

            return new ColumnViewConfigDto
            {
                DatasetSelectorRules = new (),
                ColumnViewConfigurationId = Guid.NewGuid(),
                Label = anotherTable.Name,
                UMLColumnId = columnId
            };
        }
    }
}