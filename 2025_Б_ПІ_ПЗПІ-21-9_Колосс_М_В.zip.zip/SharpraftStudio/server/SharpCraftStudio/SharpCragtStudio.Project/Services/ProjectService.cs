﻿using Microsoft.AspNetCore.Identity;
using SharpCraftStudio.Core;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Models;
using AutoMapper;
using SharpCraftStudio.Project.Interfaces.Repositories;
using SharpCraftStudio.Data.Models.Project.Validation;
using SharpCraftStudio.Data.Models.Project;

namespace SharpCraftStudio.Project.Services
{
    internal class ProjectService : IProjectService
    {
        private readonly IProjectConfigurationRepository _projectRepository;
        private UserManager<User> _userManager;
        private IMapper _mapper;

        public ProjectService(IProjectConfigurationRepository projectRepository, UserManager<User> userManager, IMapper mapper)
        {
            _projectRepository = projectRepository;
            _userManager = userManager;
            _mapper = mapper;
        }

        public async Task<ProjectConfigurationDto?> GetByIdForUserAsync(Guid id, string userName)
        {
            var project = await _projectRepository.GetAsync(id);

            if (project == null || project.OwnerUserName != userName)
            {
                return null;
            }

            return _mapper.Map<ProjectConfigurationDto>(project);
        }

        public async Task<List<ProjectConfigurationDto>> GetForUserAsync(string userName)
        {
            var projects = await _projectRepository.GetAllWithConditionAsync(c => c.OwnerUserName == userName);

            return _mapper.Map<List<ProjectConfigurationDto>>(projects);
        }

        public async Task<OperationResult> SaveEnabledFeaturesAsync(SetupEnabledFeaturesDto enabledFeaturesDto, string userName)
        {
            var user = await _userManager.FindByNameAsync(userName);

            if (user == null)
            {
                return OperationResultFactory.FailuredWithGeneralError("Invalid user name.");
            }

            var project = await _projectRepository.GetAsync(enabledFeaturesDto.ProjectId);
            var enabledFeatures = _mapper.Map<EnabledFeatures>(enabledFeaturesDto);

            if (project != null)
            {
                if (project.OwnerUserName != userName)
                {
                    return OperationResultFactory.FailuredWithGeneralError("User havent permissions.");
                }

                if (project.Step != ProjectCreationStep.FeaturesEnabling)
                {
                    return OperationResultFactory.FailuredWithGeneralError("Project step isnt features enabling");
                }

                project.EnabledFeatures = enabledFeatures;
                await _projectRepository.UpdateAsync(project);
                return OperationResultFactory.Successed();
            }

            return OperationResultFactory.FailuredWithGeneralError("Project doestn exist.");
        }

        public async Task<OperationResult> CreateAsync(ProjectCreationDto projectCreationDto, string userName)
        {
            var user = await _userManager.FindByNameAsync(userName);

            if (user == null)
            {
                return OperationResultFactory.FailuredWithGeneralError("Invalid user name.");
            }

            var projectInDb = await _projectRepository.GetAsync(projectCreationDto.ProjectConfigurationId);

            if (projectInDb != null)
            {
                return OperationResultFactory.FailuredWithGeneralError("Project with same if already exist");
            }

            var project = new ProjectConfiguration()
            {
                ProjectConfigurationId = projectCreationDto.ProjectConfigurationId,
                CreationDate = DateTime.Now,
                Name = projectCreationDto.Name,
                OwnerUserName = user.UserName,
            };

            await _projectRepository.CreateAsync(project);

            return OperationResultFactory.Successed();
        }

        public async Task<OperationResult> DeleteAsync(Guid id, string userName)
        {
            var user = await _userManager.FindByNameAsync(userName);

            if (user == null)
            {
                return OperationResultFactory.FailuredWithGeneralError("Invalid user name.");
            }

            var projectInDb = await _projectRepository.GetAsync(id);

            if (projectInDb == null || projectInDb.OwnerUserName != user.UserName)
            {
                return OperationResultFactory.FailuredWithGeneralError("Project doesnt exist");
            }

            await _projectRepository.RemoveAsync(projectInDb);

            return OperationResultFactory.Successed();
        }

        public async Task<OperationResult> SaveValidation(Guid projectId, ValidationConfig validationConfig, string userName)
        {
            var user = await _userManager.FindByNameAsync(userName);

            if (user == null)
            {
                return OperationResultFactory.FailuredWithGeneralError("Invalid user name.");
            }

            var project = await _projectRepository.GetAsync(projectId);

            if (project != null)
            {
                if (project.OwnerUserName != userName)
                {
                    return OperationResultFactory.FailuredWithGeneralError("User havent permissions.");
                }

                if (project.Step != ProjectCreationStep.ValidationEnabling)
                {
                    return OperationResultFactory.FailuredWithGeneralError("Project step isnt validation enabling");
                }

                project.ValidationConfig = validationConfig;
                await _projectRepository.UpdateAsync(project);
                return OperationResultFactory.Successed();
            }

            return OperationResultFactory.FailuredWithGeneralError("Project doestn exist.");
        }

        public async Task<OperationResult> SaveColorTemplate(Guid projectId, Guid templateId, string userName)
        {
            var user = await _userManager.FindByNameAsync(userName);

            if (user == null)
            {
                return OperationResultFactory.FailuredWithGeneralError("Invalid user name.");
            }

            var project = await _projectRepository.GetAsync(projectId);

            if (project != null)
            {
                if (project.OwnerUserName != userName)
                {
                    return OperationResultFactory.FailuredWithGeneralError("User havent permissions.");
                }

                if (project.Step != ProjectCreationStep.ColorsSelection)
                {
                    return OperationResultFactory.FailuredWithGeneralError("Project step isnt colors selection");
                }

                project.ColorTemplateId = templateId;
                await _projectRepository.UpdateAsync(project);
                return OperationResultFactory.Successed();
            }

            return OperationResultFactory.FailuredWithGeneralError("Project doestn exist.");
        }

        public async Task<OperationResult<ProjectConfigurationDto>> GetResultAsync(Guid id, string userName)
        {
            var user = await _userManager.FindByNameAsync(userName);

            if (user == null)
            {
                return OperationResultFactory.FailuredWithGeneralError<ProjectConfigurationDto>("Invalid user name.");
            }

            var project = await _projectRepository.GetAsync(id);

            if (project != null)
            {
                if (project.OwnerUserName != userName)
                {
                    return OperationResultFactory.FailuredWithGeneralError<ProjectConfigurationDto>("User havent permissions.");
                }

                if (project.Step != ProjectCreationStep.Receiving)
                {
                    return OperationResultFactory.FailuredWithGeneralError<ProjectConfigurationDto>("Project step isnt Receiving");
                }

                return OperationResultFactory.Successed(_mapper.Map<ProjectConfigurationDto>(project));
            }

            return OperationResultFactory.FailuredWithGeneralError<ProjectConfigurationDto>("Project doestn exist.");
        }
    }
}
