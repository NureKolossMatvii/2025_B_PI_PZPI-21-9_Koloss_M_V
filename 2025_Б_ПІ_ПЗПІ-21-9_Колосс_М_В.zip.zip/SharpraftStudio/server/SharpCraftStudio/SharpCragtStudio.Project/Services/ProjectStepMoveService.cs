﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models.Project;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Interfaces.Repositories;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Step.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Services
{
    internal class ProjectStepMoveService : IProjectStepMoveService
    {
        private readonly IStepMoversConfiguration _moversConfiguration;
        private readonly UserManager<User> _userManager;
        private readonly IProjectConfigurationRepository _projectRepository;
        private readonly IMapper _mapper;

        public ProjectStepMoveService(IStepMoversConfiguration moversConfiguration, UserManager<User> userManager, IProjectConfigurationRepository projectRepository, IMapper mapper)
        {
            _moversConfiguration = moversConfiguration;
            _userManager = userManager;
            _projectRepository = projectRepository;
            _mapper = mapper;
        }

        public async Task<OperationResult> MoveToNextStepAsync(Guid projectId, string userName)
        {
            var user = await _userManager.FindByNameAsync(userName);

            if (user == null)
            {
                return OperationResultFactory.FailuredWithGeneralError("Invalid user name.");
            }

            var project = await _projectRepository.GetAsync(projectId);

            if (project != null)
            {
                if (project.OwnerUserName != userName)
                {
                    return OperationResultFactory.FailuredWithGeneralError("User havent permissions.");
                }

                var mover = _moversConfiguration.GetStepMover(project.Step);
                var result = mover.TryMoveToNextStep(project, _mapper);
                if (result.Success)
                {
                    await _projectRepository.UpdateAsync(project);
                }

                return result;
            }

            return OperationResultFactory.FailuredWithGeneralError("Project doestn exist.");
        }
    }
}
