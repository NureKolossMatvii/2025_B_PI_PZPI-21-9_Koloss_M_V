﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models.Project;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Project.Interfaces;
using SharpCraftStudio.Project.Interfaces.Repositories;
using SharpCraftStudio.Project.Models.UML;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Project.Services
{
    internal class UMLDiagramService : IUMLDiagramService
    {
        private readonly IMapper _mapper;
        private readonly IProjectConfigurationRepository _projectRepository;
        private UserManager<User> _userManager;

        public UMLDiagramService(IMapper mapper, IProjectConfigurationRepository projectRepository, UserManager<User> userManager)
        {
            _mapper = mapper;
            _projectRepository = projectRepository;
            _userManager = userManager;
        }

        public async Task<OperationResult> SaveAsync(UMLDiagramSaveDto diagram, string userName)
        {
            var user = await _userManager.FindByNameAsync(userName);

            if (user == null)
            {
                return OperationResultFactory.FailuredWithGeneralError("Invalid user name.");
            }

            var project = await _projectRepository.GetAsync(diagram.ProjectId);
            var newDiagram = _mapper.Map<UMLDiagram>(diagram);

            if (project != null)
            {
                if (project.OwnerUserName != userName)
                {
                    return OperationResultFactory.FailuredWithGeneralError("User havent permissions.");
                }

                if(project.Step != ProjectCreationStep.UmlCreation)
                {
                    return OperationResultFactory.FailuredWithGeneralError("Project step isnt uml creation");
                }

                project.Diagram = newDiagram;
                await _projectRepository.UpdateAsync(project);
                return OperationResultFactory.Successed();
            }
            
            return OperationResultFactory.FailuredWithGeneralError("Project doestn exist.");
        }
    }
}
