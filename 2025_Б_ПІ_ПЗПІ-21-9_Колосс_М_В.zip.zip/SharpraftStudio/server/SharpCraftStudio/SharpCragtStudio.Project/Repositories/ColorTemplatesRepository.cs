﻿using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using SharpCraftStudio.Project.Interfaces.Repositories;
using SharpCraftStudio.Data.Models.Project.ColorTemplates;

namespace SharpCraftStudio.Project.Repositories
{
    internal class ColorTemplatesRepository : BaseRepository<ColorTemplate, Guid, AppMongoDbContext>, IColorTemplatesRepository
    {
        public ColorTemplatesRepository(IAppDbContext<AppMongoDbContext> db) : base(db)
        {
        }

        public override async Task<List<ColorTemplate>> GetAllWithConditionAsync(Expression<Func<ColorTemplate, bool>> condition)
        {
            return await _db.GetSet<ColorTemplate>().ToListAsync();
        }

        public override async Task<ColorTemplate> GetAsync(Guid id)
        {
            return await _db.GetSet<ColorTemplate>()
                .FirstOrDefaultAsync(c => c.ColorTemplateId == id);
        }
    }
}
