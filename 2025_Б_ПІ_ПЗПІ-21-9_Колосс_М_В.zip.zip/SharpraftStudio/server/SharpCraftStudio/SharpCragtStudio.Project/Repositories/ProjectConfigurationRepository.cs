﻿using Microsoft.EntityFrameworkCore;
using SharpCraftStudio.Core;
using SharpCraftStudio.Data;
using SharpCraftStudio.Data.Models.Project;
using SharpCraftStudio.Project.Interfaces.Repositories;
using System.Linq.Expressions;

namespace SharpCraftStudio.Project.Repositories
{
    internal class ProjectConfigurationRepository : BaseRepository<ProjectConfiguration, Guid, AppMongoDbContext>, IProjectConfigurationRepository
    {
        public ProjectConfigurationRepository(IAppDbContext<AppMongoDbContext> db) : base(db)
        {
        }

        public override async Task<List<ProjectConfiguration>> GetAllWithConditionAsync(Expression<Func<ProjectConfiguration, bool>> condition)
        {
            return await _db.GetSet<ProjectConfiguration>().Where(condition).ToListAsync();
        }

        public override Task<ProjectConfiguration> GetAsync(Guid id)
        {
            return _db.GetSet<ProjectConfiguration>()
                .Include(c => c.Diagram)
                .Include(c => c.EnabledFeatures)
                .Include(c => c.ViewConfig)
                .FirstOrDefaultAsync(c => c.ProjectConfigurationId == id);
        }
    }
}
