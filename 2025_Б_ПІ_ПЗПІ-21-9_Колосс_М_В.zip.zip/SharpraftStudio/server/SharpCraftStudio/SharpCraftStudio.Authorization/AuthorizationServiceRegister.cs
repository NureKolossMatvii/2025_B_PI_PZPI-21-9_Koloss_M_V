﻿using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;
using SharpCraftStudio.Authorization.Interfaces;
using SharpCraftStudio.Authorization.Services;
using SharpCraftStudio.Authorization.Validators;
using SharpCraftStudio.Core.Interfaces;

namespace SharpCraftStudio.Authorization
{
    public static class AuthorizationServiceRegister
    {
        public static void Register(IServiceCollection services)
        {
            services.AddScoped<IUserRegisterDtoValidator, UserRegisterDtoValidator>();
            services.AddSingleton<IJwtService, JwtService>();
            services.AddScoped<IUserRegister, UserRegisterService>();
            services.AddScoped<IDefaultDataInitializer, DefaultAuthorizeDataInitializeService>();
            services.AddScoped<ISignInService, SignInService>();
            services.Configure<IdentityOptions>(options =>
            {
                options.Password.RequireDigit = false;
                options.Password.RequireLowercase = false;
                options.Password.RequireUppercase = false;
                options.Password.RequireNonAlphanumeric = false;
                options.Password.RequiredLength = 1;
            });
        }
    }
}
