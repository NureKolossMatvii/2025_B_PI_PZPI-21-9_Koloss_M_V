﻿namespace SharpCraftStudio.Authorization.Models
{
    public record UserRegisterDto(string Login, string Password, string ConfirmPassword)
    {
    }
}
