﻿namespace SharpCraftStudio.Authorization.Models
{
    public static class Roles
    {
        public const string CREATOR = "Creator";
        public const string ADMIN = "Admin";
    }
}
