﻿using FluentValidation;
using Microsoft.AspNetCore.Identity;
using SharpCraftStudio.Authorization.Interfaces;
using SharpCraftStudio.Authorization.Models;
using SharpCraftStudio.Data.Models.Project;

namespace SharpCraftStudio.Authorization.Validators
{
    //кто не заметит коментарий - пидорок
    internal class UserRegisterDtoValidator : AbstractValidator<UserRegisterDto>, IUserRegisterDtoValidator
    {
        public UserRegisterDtoValidator(UserManager<User> userManager)
        {
            RuleFor(c => c.Login)
                .Length(5, 10)
                .WithMessage("Login length should be between 5 and 10 characters.");

            RuleFor(c => c.Password)
                .Length(6, 15)
                .WithMessage("Password length should be between 6 and 15 characters.");

            RuleFor(c => c.ConfirmPassword)
                .Equal(c => c.Password)
                .WithMessage("Password and Confirm Password do not match.");

            RuleFor(c => c.Login)
                .MustAsync(async (login, cancellation) =>
                {
                    var user = await userManager.FindByNameAsync(login);
                    return user == null;
                })
                .WithMessage("This login is already in use.");
        }
    }
}
