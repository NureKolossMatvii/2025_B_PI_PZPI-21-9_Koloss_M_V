﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using SharpCraftStudio.Authorization.Interfaces;
using SharpCraftStudio.Authorization.Models;
using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models.Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Authorization.Services
{
    internal class SignInService : ISignInService
    {
        private readonly SignInManager<User> _signInManager;
        private readonly IJwtService _jwtService;
        private readonly UserManager<User> _userManager;

        public SignInService(IJwtService jwtService, SignInManager<User> signInManager, UserManager<User> userManager)
        {
            _jwtService = jwtService;
            _signInManager = signInManager;
            _userManager = userManager;
        }

        public async Task<OperationResult<string>> SignIn(UserSignInDto userSignInDto)
        {
            var user = await _userManager.Users.FirstOrDefaultAsync(c => c.UserName == userSignInDto.Login);
            var userCanSignIn = await UserCanSignIn(user, userSignInDto.Password);

            if (userCanSignIn)
            {
                var userRoles = await _userManager.GetRolesAsync(user);
                var token = _jwtService.CreateToken(user.UserName, userRoles);
                return OperationResultFactory.Successed(token);
            }

            var errors = new Dictionary<string, string[]>
            {
                ["Password"] = new string[] { "Login or password entered incorrectly" }
            };

            return OperationResultFactory.Failured<string>(errors);
        }

        private async Task<bool> UserCanSignIn(User? user, string password)
        {
            if (user != null)
            {
                var signInResult = await _signInManager.CheckPasswordSignInAsync(user, password, false);
                return signInResult.Succeeded;
            }

            return false;
        }
    }
}
