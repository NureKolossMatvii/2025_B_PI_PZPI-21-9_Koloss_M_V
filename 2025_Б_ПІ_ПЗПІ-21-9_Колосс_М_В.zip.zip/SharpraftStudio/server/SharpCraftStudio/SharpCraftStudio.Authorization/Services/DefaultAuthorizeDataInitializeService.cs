﻿using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SharpCraftStudio.Authorization.Interfaces;
using SharpCraftStudio.Authorization.Models;
using SharpCraftStudio.Authorization.Validators;
using SharpCraftStudio.Core.Interfaces;
using SharpCraftStudio.Data.Models.Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Authorization.Services
{
    internal class DefaultAuthorizeDataInitializeService : IDefaultDataInitializer
    {
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<User> _userManager;

        public DefaultAuthorizeDataInitializeService(RoleManager<IdentityRole> roleManager, UserManager<User> userManager)
        {
            _roleManager = roleManager;
            _userManager = userManager;
        }

        public async Task InitializeAsync()
        {
            await InitializeRoles();
            await InitializeAdmin();
        }

        private async Task InitializeAdmin()
        {
            var existUsers = await _userManager.Users.ToArrayAsync();
            var adminLogin = "admin";
            var adminPassword = "123456";

            if (!existUsers.Any(c => c.UserName == adminLogin))
            {
                var user = new User() { UserName = adminLogin };
                await _userManager.CreateAsync(user, adminPassword);
                await _userManager.AddToRolesAsync(user, new string[] { Roles.CREATOR, Roles.ADMIN });
            }
        }

        private async Task InitializeRoles()
        {
            var existRoles = await _roleManager.Roles.ToArrayAsync();
            var allRoles = new string[] { Roles.CREATOR, Roles.ADMIN };

            foreach (var role in allRoles)
            {
                if (!existRoles.Any(c => c.Name == role))
                {
                    await _roleManager.CreateAsync(new IdentityRole() { Name = role });
                }
            }
        }
    }
}
