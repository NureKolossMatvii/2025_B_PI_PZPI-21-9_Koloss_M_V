﻿using AutoMapper;
using Microsoft.AspNetCore.Identity;
using SharpCraftStudio.Authorization.Interfaces;
using SharpCraftStudio.Authorization.Models;
using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models.Project;

namespace SharpCraftStudio.Authorization.Services
{
    internal class UserRegisterService : IUserRegister
    {
        private readonly UserManager<User> _userManager;
        private readonly IUserRegisterDtoValidator _validator;
        private readonly IMapper _mapper;
        private readonly IJwtService _jwtService;

        public UserRegisterService(UserManager<User> userManager, IUserRegisterDtoValidator validator, IMapper mapper, IJwtService jwtService)
        {
            _userManager = userManager;
            _validator = validator;
            _mapper = mapper;
            _jwtService = jwtService;
        }

        public async Task<OperationResult<string>> Register(UserRegisterDto userRegisterDto, CancellationToken cancellationToken = default)
        {
            var validationResult = await _validator.ValidateAsync(userRegisterDto, cancellationToken);

            if (validationResult.IsValid) {
                var user = new User() { UserName = userRegisterDto.Login };
                await _userManager.CreateAsync(user, userRegisterDto.Password);
                await _userManager.AddToRoleAsync(user, Roles.CREATOR);

                var token = _jwtService.CreateToken(user.UserName, [Roles.CREATOR]);
                return OperationResultFactory.Successed(token);
            }

            var errors = _mapper.Map<Dictionary<string, string[]>>(validationResult);

            return OperationResultFactory.Failured<string>(errors);
        }
    }
}
