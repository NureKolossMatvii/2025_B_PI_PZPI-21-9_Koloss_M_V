﻿using SharpCraftStudio.Authorization.Models;
using SharpCraftStudio.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.Authorization.Interfaces
{
    public interface ISignInService
    {
        Task<OperationResult<string>> SignIn(UserSignInDto userSignInDto);
    }
}
