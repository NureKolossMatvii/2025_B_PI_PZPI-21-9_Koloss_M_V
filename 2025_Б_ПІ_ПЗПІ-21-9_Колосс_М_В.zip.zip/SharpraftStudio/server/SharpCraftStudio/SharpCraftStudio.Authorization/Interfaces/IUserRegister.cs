﻿using SharpCraftStudio.Authorization.Models;
using SharpCraftStudio.Core;

namespace SharpCraftStudio.Authorization.Interfaces
{
    public interface IUserRegister
    {
        Task<OperationResult<string>> Register(UserRegisterDto userRegisterDto, CancellationToken cancellationToken = default);
    }
}
