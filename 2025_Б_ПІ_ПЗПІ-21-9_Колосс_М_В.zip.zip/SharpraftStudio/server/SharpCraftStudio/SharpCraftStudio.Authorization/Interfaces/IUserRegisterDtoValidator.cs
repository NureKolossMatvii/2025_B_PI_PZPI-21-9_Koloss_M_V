﻿using FluentValidation.Results;
using SharpCraftStudio.Authorization.Models;

namespace SharpCraftStudio.Authorization.Interfaces
{
    internal interface IUserRegisterDtoValidator
    {
        public Task<ValidationResult> ValidateAsync(UserRegisterDto instance, CancellationToken cancellationToken = default);
    }
}
