﻿using Microsoft.Extensions.DependencyInjection;
using SharpCraftStudio.ClientConfiguration.Interfaces;
using SharpCraftStudio.ClientConfiguration.Repositories;
using SharpCraftStudio.ClientConfiguration.Services;
using SharpCraftStudio.Data.Models.Project;

namespace SharpCraftStudio.ClientConfiguration
{
    public static class ClientConfigurationServiceRegister
    {
        public static void Register(IServiceCollection services)
        {
            services.AddScoped<IClientTextInfoRepository, ClientTextInfoRepository>();
            services.AddScoped<IClientTextInfoService, ClientLabelInfoService>();
        }
    }
}
