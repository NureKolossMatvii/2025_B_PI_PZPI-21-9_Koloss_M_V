﻿using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models.ClientConfiguration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.ClientConfiguration.Interfaces
{
    public interface IClientTextInfoService
    {
        Task<OperationResult<List<ClientTextInfoItem>>> GetAllAsync();

        Task<OperationResult> AddOrUpdateAsync(ClientTextInfoItem item);

        Task<OperationResult> RemoveAsync(string key);
    }
}
