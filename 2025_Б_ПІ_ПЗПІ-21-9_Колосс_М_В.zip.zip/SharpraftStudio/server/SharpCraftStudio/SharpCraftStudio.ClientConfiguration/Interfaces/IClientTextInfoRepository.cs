﻿using SharpCraftStudio.Core.Interfaces;
using SharpCraftStudio.Data;
using SharpCraftStudio.Data.Models.ClientConfiguration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.ClientConfiguration.Interfaces
{
    public interface IClientTextInfoRepository : IBaseRepository<ClientTextInfoItem, string, AppMongoDbContext>
    {
    }
}
