﻿using SharpCraftStudio.ClientConfiguration.Interfaces;
using SharpCraftStudio.Core;
using SharpCraftStudio.Data;
using SharpCraftStudio.Data.Models.ClientConfiguration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.ClientConfiguration.Repositories
{
    internal class ClientTextInfoRepository : BaseRepository<ClientTextInfoItem, string, AppMongoDbContext>, IClientTextInfoRepository
    {
        public ClientTextInfoRepository(IAppDbContext<AppMongoDbContext> db) : base(db)
        {
        }
    }
}
