﻿using SharpCraftStudio.ClientConfiguration.Interfaces;
using SharpCraftStudio.Core;
using SharpCraftStudio.Data.Models.ClientConfiguration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SharpCraftStudio.ClientConfiguration.Services
{
    internal class ClientLabelInfoService : IClientTextInfoService
    {
        private readonly IClientTextInfoRepository _clientLabelInfoRepository;

        public ClientLabelInfoService(IClientTextInfoRepository clientLabelInfoRepository)
        {
            _clientLabelInfoRepository = clientLabelInfoRepository;
        }

        public async Task<OperationResult<List<ClientTextInfoItem>>> GetAllAsync()
        {
            var result = await _clientLabelInfoRepository.GetAllAsync();
            return OperationResultFactory.Successed(result);
        }

        public async Task<OperationResult> AddOrUpdateAsync(ClientTextInfoItem item)
        {
            var fromDb = await _clientLabelInfoRepository.GetAsync(item.Key);

            if(fromDb is not null)
            {
                fromDb.RuLabel = item.RuLabel;
                fromDb.EngLabel = item.EngLabel;

                return await UpdateAsync(fromDb);
            }

            await _clientLabelInfoRepository.CreateAsync(item);

            return OperationResultFactory.Successed();
        }

        public async Task<OperationResult> RemoveAsync(string key)
        {
            var item = await _clientLabelInfoRepository.GetAsync(key);

            if(item is null)
            {
                return OperationResultFactory.FailuredWithGeneralError($"Item with key {item.Key} does not exist");
            }

            await _clientLabelInfoRepository.RemoveAsync(item);

            return OperationResultFactory.Successed();
        }

        private async Task<OperationResult> UpdateAsync(ClientTextInfoItem item)
        {
            await _clientLabelInfoRepository.UpdateAsync(item);

            return OperationResultFactory.Successed();
        }

    }
}
