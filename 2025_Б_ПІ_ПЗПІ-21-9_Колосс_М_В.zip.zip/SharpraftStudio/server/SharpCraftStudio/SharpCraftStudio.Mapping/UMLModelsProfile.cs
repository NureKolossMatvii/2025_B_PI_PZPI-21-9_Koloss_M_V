﻿using AutoMapper;
using SharpCraftStudio.Data.Models.Project.UML;
using SharpCraftStudio.Data.Models.Project.UML.Operations;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.UML;
using SharpCraftStudio.Project.Models.UML.Operations;

namespace SharpCraftStudio.Mapping
{
    internal class UMLModelsProfile : Profile
    {
        public UMLModelsProfile()
        {
            CreateMap<UMLDiagram, UMLDiagramSaveDto>().ReverseMap();
            CreateMap<UMLDiagramSaveDto, UMLDiagram>();
            CreateMap<UMLDiagramDto, UMLDiagram>().ReverseMap();
            CreateMap<UMLTable, UMLTableDto>().ReverseMap();    
            CreateMap<UMLTableColumn, UMLTableColumnDto>().ReverseMap();
            CreateMap<UMLTableConnection, UMLTableConnectionDto>().ReverseMap();
            CreateMap<UMLTableOperations, UMLTableOperationsDto>().ReverseMap();
            CreateMap<UMLTableColumnOperations, UMLTableColumnOperationsDto>().ReverseMap(); 
        }
    }
}
