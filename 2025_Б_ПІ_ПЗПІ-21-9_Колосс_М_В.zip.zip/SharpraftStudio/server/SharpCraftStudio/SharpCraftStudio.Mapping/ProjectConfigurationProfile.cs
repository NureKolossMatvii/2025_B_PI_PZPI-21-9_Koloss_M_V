﻿using AutoMapper;
using SharpCraftStudio.Data.Models;
using SharpCraftStudio.Project.Models;
using SharpCraftStudio.Project.Models.TableView;
using SharpCraftStudio.Data.Models.Project.TableView;
using SharpCraftStudio.Data.Models.Project;

namespace SharpCraftStudio.Mapping
{
    internal class ProjectConfigurationProfile : Profile
    {
        public ProjectConfigurationProfile()
        {
            CreateMap<ProjectConfiguration, ProjectConfigurationDto>().ReverseMap();
            CreateMap<EnabledFeatures, SetupEnabledFeaturesDto>().ReverseMap();
            CreateMap<ViewConfig, ViewConfigDto>().ReverseMap();
            CreateMap<ColumnViewConfig, ColumnViewConfigDto>().ReverseMap();
            CreateMap<DatasetSelectorRules, DatasetSelectorRulesDto>().ReverseMap();
            CreateMap<TableViewConfig, TableViewConfigDto>().ReverseMap();
        }
    }
}
