﻿using AutoMapper;
using FluentValidation.Results;

namespace SharpCraftStudio.Mapping
{
    internal class ValidationResultToDictionaryProfile : Profile
    {
        public ValidationResultToDictionaryProfile()
        {
            CreateMap<ValidationResult, Dictionary<string, string[]>>()
                .ConvertUsing(validationResult => validationResult.Errors
                    .GroupBy(error => error.PropertyName, error => error.ErrorMessage)
                    .ToDictionary(group => group.Key, group => group.ToArray())
                );
        }
    }
}
