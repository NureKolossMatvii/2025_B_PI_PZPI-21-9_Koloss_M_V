﻿using Microsoft.Extensions.DependencyInjection;

namespace SharpCraftStudio.Mapping
{
    public static class MappingServiceRegister
    {
        public static void Register(IServiceCollection services)
        {
            services.AddAutoMapper(typeof(MappingServiceRegister).Assembly);
        }
    }
}
